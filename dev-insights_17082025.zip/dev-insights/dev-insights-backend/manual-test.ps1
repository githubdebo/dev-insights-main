# Azure AD Token Endpoint Manual Testing Script
# Run this in PowerShell to test the endpoint

Write-Host "🧪 Manual Testing Guide for Azure AD Token Endpoint" -ForegroundColor Cyan
Write-Host "=================================================" -ForegroundColor Cyan
Write-Host ""

# Test 1: Check if endpoint exists
Write-Host "1️⃣  Testing endpoint availability..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:3001/api" -UseBasicParsing
    Write-Host "✅ API is accessible" -ForegroundColor Green
    Write-Host "Available endpoints:" -ForegroundColor White
    $response.Content | ConvertFrom-Json | Select-Object -ExpandProperty endpoints | Format-List
} catch {
    Write-Host "❌ API not accessible: $($_.Exception.Message)" -ForegroundColor Red
    exit
}

Write-Host ""

# Test 2: Missing required fields
Write-Host "2️⃣  Testing validation (missing required fields)..." -ForegroundColor Yellow
$invalidRequest = @{
    clientId = "test-client-id"
    # Missing clientSecret, tenantId, scope, and grantType
} | ConvertTo-Json

try {
    $response = Invoke-WebRequest -Uri "http://localhost:3001/api/azure/token" -Method POST -Body $invalidRequest -ContentType "application/json" -UseBasicParsing
    Write-Host "❌ Unexpected success" -ForegroundColor Red
} catch {
    $statusCode = $_.Exception.Response.StatusCode.value__
    Write-Host "✅ Validation working - Status Code: $statusCode" -ForegroundColor Green
    
    # Try to get error details
    try {
        $errorContent = $_.Exception.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($errorContent)
        $errorBody = $reader.ReadToEnd()
        $errorJson = $errorBody | ConvertFrom-Json
        Write-Host "Error: $($errorJson.error)" -ForegroundColor White
        Write-Host "Error Code: $($errorJson.errorCode)" -ForegroundColor White
    } catch {
        Write-Host "Could not parse error response" -ForegroundColor Yellow
    }
}

Write-Host ""

# Test 3: Valid format but fake credentials
Write-Host "3️⃣  Testing with valid format but fake credentials..." -ForegroundColor Yellow
$validFormatRequest = @{
    clientId = "fake-client-id-12345"
    clientSecret = "fake-client-secret-67890"
    tenantId = "fake-tenant-id-abcde"
    scope = "https://graph.microsoft.com/.default"
    grantType = "client_credentials"
} | ConvertTo-Json

Write-Host "Request Body:" -ForegroundColor White
Write-Host $validFormatRequest -ForegroundColor Gray

try {
    $response = Invoke-WebRequest -Uri "http://localhost:3001/api/azure/token" -Method POST -Body $validFormatRequest -ContentType "application/json" -UseBasicParsing
    Write-Host "❌ Unexpected success with fake credentials" -ForegroundColor Red
    Write-Host $response.Content -ForegroundColor White
} catch {
    $statusCode = $_.Exception.Response.StatusCode.value__
    Write-Host "✅ Correctly rejected fake credentials - Status Code: $statusCode" -ForegroundColor Green
    
    # Try to get error details
    try {
        $errorContent = $_.Exception.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($errorContent)
        $errorBody = $reader.ReadToEnd()
        $errorJson = $errorBody | ConvertFrom-Json
        Write-Host ""
        Write-Host "Response Structure:" -ForegroundColor White
        Write-Host "  success: $($errorJson.success)" -ForegroundColor Gray
        Write-Host "  error: $($errorJson.error)" -ForegroundColor Gray
        Write-Host "  errorCode: $($errorJson.errorCode)" -ForegroundColor Gray
        Write-Host "  timestamp: $($errorJson.timestamp)" -ForegroundColor Gray
        Write-Host "  duration: $($errorJson.duration)ms" -ForegroundColor Gray
    } catch {
        Write-Host "Could not parse error response" -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "🎉 Manual testing complete!" -ForegroundColor Green
Write-Host ""
Write-Host "📋 To test with real Azure AD credentials:" -ForegroundColor Cyan
Write-Host "Replace the fake values in Test 3 with your actual:" -ForegroundColor White
Write-Host "  - clientId: Your Azure App Registration Client ID" -ForegroundColor Gray
Write-Host "  - clientSecret: Your Azure App Registration Client Secret" -ForegroundColor Gray
Write-Host "  - tenantId: Your Azure AD Tenant ID" -ForegroundColor Gray
