# Dev Insights Backend

A Node.js TypeScript backend API using Express.js for the Dev Insights application.

## Features

- 🚀 Express.js with TypeScript
- 🔒 Security middleware (Helmet, CORS)
- 📝 Request logging with Morgan
- 🛡️ Error handling middleware
- 📋 Environment configuration with dotenv
- 🎯 ESLint for code quality
- 🔄 Hot reload with nodemon

## Quick Start

### Prerequisites

- Node.js (v18 or higher)
- npm or yarn

### Installation

1. Install dependencies:
```bash
npm install
```

2. Start development server:
```bash
npm run dev
```

3. Build for production:
```bash
npm run build
npm start
```

## Scripts

- `npm run dev` - Start development server with hot reload
- `npm run build` - Build TypeScript to JavaScript
- `npm run start` - Start production server
- `npm run lint` - Run ESLint
- `npm run lint:fix` - Fix ESLint errors automatically

## API Endpoints

### Health Check
- `GET /health` - Server health status

### API Info
- `GET /api` - API information and available endpoints

### Users
- `GET /api/users` - Get all users
- `GET /api/users/:id` - Get user by ID
- `POST /api/users` - Create new user

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/register` - User registration

## Environment Variables

Create a `.env` file in the root directory:

```env
PORT=3000
NODE_ENV=development
```

## Project Structure

```
src/
├── middleware/
│   ├── errorHandler.ts    # Global error handling
│   └── notFound.ts        # 404 handler
├── routes/
│   ├── api.ts            # Main API router
│   ├── auth.ts           # Authentication routes
│   └── users.ts          # User routes
└── index.ts              # Application entry point
```

## Development

The server will automatically restart when you make changes to the code. The API will be available at `http://localhost:3000`.

## Production Deployment

1. Build the application:
```bash
npm run build
```

2. Set environment variables for production
3. Start the server:
```bash
npm start
```

## License

MIT
