import { Router, Request, Response } from 'express';
import https from 'https';
import { URL, URLSearchParams } from 'url';

const router = Router();

interface AzureTokenRequest {
  clientId: string;
  clientSecret: string;
  tenantId: string;
  scope: string;
  grantType: string;
}

interface AzureTokenResponse {
  access_token?: string;
  token_type?: string;
  expires_in?: number;
  error?: string;
  error_description?: string;
  error_codes?: number[];
  timestamp?: string;
  trace_id?: string;
  correlation_id?: string;
}

interface ApiResponse {
  success: boolean;
  access_token?: string;
  token_type?: string;
  expires_in?: number;
  error?: string;
  errorCode?: string;
  details?: any;
  timestamp: string;
  duration: number;
}

// Utility function to mask sensitive data for logging
function maskSensitiveData(data: any): any {
  const masked = { ...data };
  if (masked.clientSecret) {
    masked.clientSecret = masked.clientSecret.substring(0, 4) + '****';
  }
  return masked;
}

// Utility function to make HTTPS request with timeout
function makeHttpsRequest(
  hostname: string,
  path: string,
  method: string,
  headers: Record<string, string>,
  body: string,
  timeout: number = 30000
): Promise<{ statusCode: number; data: string }> {
  return new Promise((resolve, reject) => {
    const options = {
      hostname,
      path,
      method,
      headers,
      timeout
    };

    const req = https.request(options, (res) => {
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        resolve({
          statusCode: res.statusCode || 500,
          data
        });
      });
    });

    req.on('error', (error) => {
      reject(error);
    });

    req.on('timeout', () => {
      req.destroy();
      reject(new Error('Request timeout'));
    });

    if (body) {
      req.write(body);
    }
    
    req.end();
  });
}

// POST /api/azure/token - Get Azure AD access token
router.post('/token', async (req: Request, res: Response): Promise<void> => {
  const startTime = Date.now();
  const timestamp = new Date().toISOString();
  
  try {
    const {
      clientId,
      clientSecret,
      tenantId,
      scope,
      grantType
    }: AzureTokenRequest = req.body;

    // Validate required fields
    if (!clientId || !clientSecret || !tenantId || !scope || !grantType) {
      const duration = Date.now() - startTime;
      console.log(`[Azure Token] Validation failed - Missing required fields:`, {
        hasClientId: !!clientId,
        hasClientSecret: !!clientSecret,
        hasTenantId: !!tenantId,
        hasScope: !!scope,
        hasGrantType: !!grantType,
        timestamp,
        duration
      });

      res.status(400).json({
        success: false,
        error: 'Missing required fields',
        errorCode: 'validation_error',
        details: {
          message: 'clientId, clientSecret, tenantId, scope, and grantType are required',
          missingFields: [
            !clientId && 'clientId',
            !clientSecret && 'clientSecret',
            !tenantId && 'tenantId',
            !scope && 'scope',
            !grantType && 'grantType'
          ].filter(Boolean)
        },
        timestamp,
        duration
      } as ApiResponse);
      return;
    }

    // Log request (with masked sensitive data)
    console.log(`[Azure Token] Request initiated:`, {
      ...maskSensitiveData({ clientId, clientSecret, tenantId, scope, grantType }),
      timestamp
    });

    // Prepare Azure AD token request
    const tokenParams = new URLSearchParams({
      client_id: clientId,
      client_secret: clientSecret,
      scope: scope,
      grant_type: grantType
    });

    const tokenUrl = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`;
    const url = new URL(tokenUrl);
    
    const headers = {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Content-Length': Buffer.byteLength(tokenParams.toString()).toString(),
      'User-Agent': 'Dev-Insights-Backend/1.0.0'
    };

    // Make request to Azure AD
    console.log(`[Azure Token] Making request to Azure AD for tenant: ${tenantId}`);
    
    const azureResponse = await makeHttpsRequest(
      url.hostname,
      url.pathname,
      'POST',
      headers,
      tokenParams.toString(),
      30000 // 30 second timeout
    );

    const duration = Date.now() - startTime;

    // Parse Azure AD response
    let azureData: AzureTokenResponse;
    try {
      azureData = JSON.parse(azureResponse.data);
    } catch (parseError) {
      console.error(`[Azure Token] JSON parse error:`, {
        error: parseError,
        rawResponse: azureResponse.data.substring(0, 500),
        timestamp,
        duration
      });

      res.status(502).json({
        success: false,
        error: 'Invalid response from Azure AD',
        errorCode: 'parse_error',
        details: { message: 'Failed to parse Azure AD response' },
        timestamp,
        duration
      } as ApiResponse);
      return;
    }

    // Handle successful response
    if (azureResponse.statusCode === 200 && azureData.access_token) {
      console.log(`[Azure Token] Success:`, {
        tenantId,
        tokenType: azureData.token_type,
        expiresIn: azureData.expires_in,
        timestamp,
        duration
      });

      res.status(200).json({
        success: true,
        access_token: azureData.access_token,
        token_type: azureData.token_type || 'Bearer',
        expires_in: azureData.expires_in || 3599,
        // Include any additional fields from Azure AD response
        ...(azureData.timestamp && { azureTimestamp: azureData.timestamp }),
        ...(azureData.trace_id && { traceId: azureData.trace_id }),
        ...(azureData.correlation_id && { correlationId: azureData.correlation_id }),
        timestamp,
        duration
      } as ApiResponse);
      return;
    }

    // Handle Azure AD errors
    console.error(`[Azure Token] Azure AD error:`, {
      statusCode: azureResponse.statusCode,
      error: azureData.error,
      errorDescription: azureData.error_description,
      errorCodes: azureData.error_codes,
      tenantId,
      timestamp,
      duration
    });

    res.status(azureResponse.statusCode).json({
      success: false,
      error: azureData.error_description || azureData.error || 'Unknown Azure AD error',
      errorCode: azureData.error || 'unknown_error',
      details: {
        statusCode: azureResponse.statusCode,
        error: azureData.error,
        error_description: azureData.error_description,
        error_codes: azureData.error_codes,
        trace_id: azureData.trace_id,
        correlation_id: azureData.correlation_id
      },
      timestamp,
      duration
    } as ApiResponse);

  } catch (error: any) {
    const duration = Date.now() - startTime;
    
    // Handle different types of errors
    if (error.message === 'Request timeout') {
      console.error(`[Azure Token] Request timeout:`, {
        error: error.message,
        timestamp,
        duration
      });

      res.status(408).json({
        success: false,
        error: 'Request timeout - Azure AD did not respond within 30 seconds',
        errorCode: 'timeout_error',
        details: { message: error.message },
        timestamp,
        duration
      } as ApiResponse);
      return;
    }

    // Network or other errors
    console.error(`[Azure Token] Unexpected error:`, {
      error: error.message,
      stack: error.stack,
      timestamp,
      duration
    });

    res.status(500).json({
      success: false,
      error: 'Internal server error while communicating with Azure AD',
      errorCode: 'network_error',
      details: { 
        message: error.message,
        type: error.constructor.name 
      },
      timestamp,
      duration
    } as ApiResponse);
  }
});

export default router;
