import { Router, Request, Response } from 'express';
import userRoutes from './users';
import authRoutes from './auth';
import azureRoutes from './azure';

const router = Router();

// API version and info
router.get('/', (req: Request, res: Response): void => {
  res.json({
    message: 'Dev Insights API',
    version: '1.0.0',
    status: 'active',
    endpoints: {
      health: '/health',
      users: '/api/users',
      auth: '/api/auth',
      azure: '/api/azure'
    }
  });
});

// Route modules
router.use('/users', userRoutes);
router.use('/auth', authRoutes);
router.use('/azure', azureRoutes);

export default router;
