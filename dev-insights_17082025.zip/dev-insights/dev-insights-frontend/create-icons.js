// Create simple PNG icons for the browser extension
import { createCanvas } from 'canvas';
import fs from 'fs';
import path from 'path';

// Create 16x16 icon
function create16x16Icon() {
  const canvas = createCanvas(16, 16);
  const ctx = canvas.getContext('2d');
  
  // Blue background
  ctx.fillStyle = '#3B82F6';
  ctx.fillRect(0, 0, 16, 16);
  
  // White "D" text
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 12px Arial';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('D', 8, 8);
  
  return canvas.toBuffer('image/png');
}

// Create 48x48 icon
function create48x48Icon() {
  const canvas = createCanvas(48, 48);
  const ctx = canvas.getContext('2d');
  
  // Gradient background
  const gradient = ctx.createLinearGradient(0, 0, 48, 48);
  gradient.addColorStop(0, '#3B82F6');
  gradient.addColorStop(1, '#1E40AF');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, 48, 48);
  
  // Border
  ctx.strokeStyle = '#1E40AF';
  ctx.lineWidth = 2;
  ctx.strokeRect(1, 1, 46, 46);
  
  // White "DEV" text
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 14px Arial';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('DEV', 24, 24);
  
  return canvas.toBuffer('image/png');
}

// Create 128x128 icon
function create128x128Icon() {
  const canvas = createCanvas(128, 128);
  const ctx = canvas.getContext('2d');
  
  // Gradient background
  const gradient = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
  gradient.addColorStop(0, '#3B82F6');
  gradient.addColorStop(1, '#1E40AF');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, 128, 128);
  
  // Code pattern background
  ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
  ctx.font = '10px monospace';
  for (let i = 0; i < 128; i += 20) {
    for (let j = 0; j < 128; j += 20) {
      ctx.fillText('<>', i, j);
    }
  }
  
  // Main circle
  ctx.beginPath();
  ctx.arc(64, 64, 50, 0, 2 * Math.PI);
  ctx.fillStyle = 'rgba(30, 64, 175, 0.8)';
  ctx.fill();
  
  // White "DEV" text
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 24px Arial';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('DEV', 64, 64);
  
  return canvas.toBuffer('image/png');
}

// Create icons and save to public directory
try {
  const publicDir = './public';
  const distDir = './dist';
  
  // Create icons
  const icon16 = create16x16Icon();
  const icon48 = create48x48Icon();
  const icon128 = create128x128Icon();
  
  // Save to public directory
  fs.writeFileSync(path.join(publicDir, 'icon16.png'), icon16);
  fs.writeFileSync(path.join(publicDir, 'icon48.png'), icon48);
  fs.writeFileSync(path.join(publicDir, 'icon128.png'), icon128);
  
  // Save to dist directory
  fs.writeFileSync(path.join(distDir, 'icon16.png'), icon16);
  fs.writeFileSync(path.join(distDir, 'icon48.png'), icon48);
  fs.writeFileSync(path.join(distDir, 'icon128.png'), icon128);
  
  console.log('Icons created successfully!');
} catch (error) {
  console.error('Error creating icons:', error);
}