// Injected script to capture network requests and error context
(function() {
  'use strict';

  // Error Context Capture
  function captureErrorContext(type, error, additionalData = {}) {
    try {
      const currentPageUrl = window.location.href;
      const errorUrl = error.filename || error.url;
      
      const errorData = {
        type: type,
        message: error.message || error.toString(),
        stack: error.stack,
        // Only include url if it's different from the current page (i.e., for JS files, API calls, etc.)
        ...(errorUrl && errorUrl !== currentPageUrl ? { url: errorUrl } : {}),
        lineNumber: error.lineno,
        columnNumber: error.colno,
        source: error.source,
        timestamp: Date.now(),
        userAgent: navigator.userAgent,
        pageUrl: currentPageUrl,
        environmentInfo: {
          viewport: `${window.innerWidth}x${window.innerHeight}`,
          cookiesEnabled: navigator.cookieEnabled,
          onlineStatus: navigator.onLine,
          referrer: document.referrer
        },
        ...additionalData
      };

      window.postMessage({
        type: 'ERROR_CONTEXT',
        data: errorData
      }, '*');
    } catch (e) {
      console.error('Failed to capture error context:', e);
    }
  }

  // Capture JavaScript errors
  window.addEventListener('error', (event) => {
    captureErrorContext('javascript', event.error || {
      message: event.message,
      filename: event.filename,
      lineno: event.lineno,
      colno: event.colno
    });
  });

  // Capture unhandled promise rejections
  window.addEventListener('unhandledrejection', (event) => {
    const error = event.reason instanceof Error ? event.reason : new Error(event.reason);
    captureErrorContext('unhandled-promise', error);
  });

  // Capture console errors
  const originalConsole = {
    error: console.error,
    warn: console.warn,
    log: console.log,
    info: console.info,
    debug: console.debug
  };

  // Override console.error to capture errors
  console.error = function(...args) {
    // Call original console.error first
    originalConsole.error.apply(console, args);
    
    // Capture as error context
    const message = args.map(arg => 
      typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg)
    ).join(' ');
    
    captureErrorContext('console-error', {
      message: `Console Error: ${message}`,
      stack: new Error().stack
    });
  };

  // Override console.warn to capture warnings (optional)
  console.warn = function(...args) {
    // Call original console.warn first
    originalConsole.warn.apply(console, args);
    
    // Capture as error context if it looks like an error
    const message = args.map(arg => 
      typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg)
    ).join(' ');
    
    // Only capture warnings that contain error-like keywords
    if (message.toLowerCase().includes('error') || 
        message.toLowerCase().includes('failed') || 
        message.toLowerCase().includes('exception')) {
      captureErrorContext('console-warning', {
        message: `Console Warning: ${message}`,
        stack: new Error().stack
      });
    }
  };

  // Override XMLHttpRequest
  const originalXHR = window.XMLHttpRequest;
  function XMLHttpRequestProxy() {
    const xhr = new originalXHR();
    const originalOpen = xhr.open;
    const originalSend = xhr.send;
    const originalSetRequestHeader = xhr.setRequestHeader;
    
    let requestHeaders = {};

    xhr.open = function(...args) {
      this._method = args[0];
      this._url = args[1];
      // Resolve relative URLs to absolute URLs
      this._resolvedUrl = this._url.startsWith('http') ? this._url : new URL(this._url, window.location.origin).href;
      requestHeaders = {}; // Reset headers for new request
      return originalOpen.apply(this, args);
    };

    xhr.setRequestHeader = function(name, value) {
      requestHeaders[name] = value;
      return originalSetRequestHeader.apply(this, arguments);
    };

    xhr.send = function(...args) {
      const startTime = Date.now();
      const requestBody = args[0];
      const originalOnReadyStateChange = this.onreadystatechange;
      const originalOnError = this.onerror;
      
      // Capture network errors
      this.onerror = function(event) {
        captureErrorContext('network', new Error(`Network request failed: ${this._method} ${this._resolvedUrl}`), {
          networkDetails: {
            method: this._method,
            status: this.status,
            statusText: this.statusText,
            responseText: this.responseText || ''
          }
        });
        if (originalOnError) {
          return originalOnError.apply(this, arguments);
        }
      };
      
      this.onreadystatechange = function() {
        if (this.readyState === 4) {
          let responseBody = this.responseText;
          
          // Capture HTTP error status codes as errors
          if (this.status >= 400) {
            captureErrorContext('network', new Error(`HTTP ${this.status}: ${this.statusText} - ${this._method} ${this._resolvedUrl}`), {
              networkDetails: {
                method: this._method,
                status: this.status,
                statusText: this.statusText,
                responseText: responseBody || ''
              }
            });
          }
          
          window.postMessage({
            type: 'NETWORK_REQUEST',
            data: {
              method: this._method,
              url: this._resolvedUrl, // Use resolved URL
              status: this.status,
              statusText: this.statusText,
              duration: Date.now() - startTime,
              timestamp: startTime,
              requestBody: requestBody,
              responseBody: responseBody,
              requestHeaders: requestHeaders
            }
          }, '*');
        }
        if (originalOnReadyStateChange) {
          return originalOnReadyStateChange.apply(this, arguments);
        }
      };
      return originalSend.apply(this, args);
    };

    return xhr;
  }

  // Override fetch
  const originalFetch = window.fetch;
  window.fetch = function(...args) {
    const startTime = Date.now();
    const url = typeof args[0] === 'string' ? args[0] : args[0]?.url;
    // Resolve relative URLs to absolute URLs
    const resolvedUrl = url.startsWith('http') ? url : new URL(url, window.location.origin).href;
    const method = args[1]?.method || 'GET';
    const requestBody = args[1]?.body;
    
    // Extract headers from fetch options
    const requestHeaders = {};
    if (args[1]?.headers) {
      if (args[1].headers instanceof Headers) {
        for (let [key, value] of args[1].headers.entries()) {
          requestHeaders[key] = value;
        }
      } else if (typeof args[1].headers === 'object') {
        Object.assign(requestHeaders, args[1].headers);
      }
    }
    
    return originalFetch.apply(this, args).then(async response => {
      let cloned = response.clone();
      let responseBody;
      try {
        responseBody = await cloned.text();
      } catch (e) {
        responseBody = '';
      }
      
      // Capture HTTP error status codes as errors
      if (response.status >= 400) {
        captureErrorContext('network', new Error(`HTTP ${response.status}: ${response.statusText} - ${method} ${resolvedUrl}`), {
          networkDetails: {
            method: method,
            status: response.status,
            statusText: response.statusText,
            responseText: responseBody || ''
          }
        });
      }
      
      window.postMessage({
        type: 'NETWORK_REQUEST',
        data: {
          method: method,
          url: resolvedUrl, // Use resolved URL
          status: response.status,
          statusText: response.statusText,
          duration: Date.now() - startTime,
          timestamp: startTime,
          requestBody: requestBody,
          responseBody: responseBody,
          requestHeaders: requestHeaders
        }
      }, '*');
      return response;
    }).catch(error => {
      // Capture network errors
      captureErrorContext('network', new Error(`Network request failed: ${method} ${resolvedUrl} - ${error.message}`), {
        networkDetails: {
          method: method,
          status: 0,
          statusText: error.message,
          responseText: ''
        }
      });
      
      window.postMessage({
        type: 'NETWORK_REQUEST',
        data: {
          method: method,
          url: resolvedUrl,
          status: 0,
          statusText: error.message,
          duration: Date.now() - startTime,
          timestamp: startTime,
          requestBody: requestBody,
          responseBody: '',
          requestHeaders: requestHeaders
        }
      }, '*');
      throw error;
    });
  };

  window.XMLHttpRequest = XMLHttpRequestProxy;

  // Enhanced journey recording with loading time tracking and page URL
  function recordJourney(type, value, element = null, additionalData = {}) {
    const journeyData = {
      type,
      value,
      element,
      timestamp: Date.now(),
      description: additionalData.description || value,
      pageUrl: window.location.href, // Always capture the current page URL
      pageTitle: document.title || 'Untitled', // Also capture page title for context
      ...additionalData
    };
    
    // Add performance timing if available
    if (type === 'url' && window.performance) {
      const navTiming = performance.getEntriesByType('navigation')[0];
      if (navTiming) {
        journeyData.loadTime = Math.round(navTiming.loadEventEnd - navTiming.loadEventStart);
        journeyData.domLoadTime = Math.round(navTiming.domContentLoadedEventEnd - navTiming.domContentLoadedEventStart);
        journeyData.fullLoadTime = Math.round(navTiming.loadEventEnd - navTiming.fetchStart);
        
        // Try to get page size from resource timing
        const resourceEntries = performance.getEntriesByType('resource');
        const totalSize = resourceEntries.reduce((sum, entry) => {
          return sum + (entry.transferSize || entry.encodedBodySize || 0);
        }, 0);
        if (totalSize > 0) {
          journeyData.size = totalSize;
        }
      }
    }
    
    window.postMessage({ type: 'DEV_INSIGHTS_JOURNEY', data: journeyData }, '*');
  }

  // Track performance for click events that might trigger navigation or content loading
  function trackClickPerformance(element, description) {
    const startTime = Date.now();
    
    // Create a promise to track loading completion
    return new Promise((resolve) => {
      // Set up observers for various completion events
      let resolved = false;
      
      const resolveOnce = (loadTime, additionalData = {}) => {
        if (!resolved) {
          resolved = true;
          resolve({ loadTime, ...additionalData });
        }
      };
      
      // Listen for navigation completion
      if (window.performance) {
        const checkNavigation = () => {
          const navEntries = performance.getEntriesByType('navigation');
          if (navEntries.length > 0) {
            const navTiming = navEntries[0];
            if (navTiming.loadEventEnd > 0) {
              resolveOnce(Date.now() - startTime, {
                domLoadTime: Math.round(navTiming.domContentLoadedEventEnd - navTiming.domContentLoadedEventStart),
                fullLoadTime: Math.round(navTiming.loadEventEnd - navTiming.fetchStart)
              });
              return;
            }
          }
          
          // If no navigation detected, resolve with basic timing
          setTimeout(() => resolveOnce(Date.now() - startTime), 100);
        };
        
        // Check after a short delay to allow for navigation to start
        setTimeout(checkNavigation, 50);
      } else {
        // Fallback timing
        setTimeout(() => resolveOnce(Date.now() - startTime), 100);
      }
      
      // Maximum wait time
      setTimeout(() => resolveOnce(Date.now() - startTime), 5000);
    });
  }

  // Track navigation (URL changes) - enhanced tracking for better sequence
  let lastRecordedUrl = window.location.href;
  let urlCheckInterval = null;
  let initialUrlRecorded = false; // Flag to prevent duplicate initial URL recording
  
  function recordUrlChange(source = 'unknown') {
    const currentUrl = window.location.href;
    
    // Skip if this is the initial load that should be handled separately
    if (!initialUrlRecorded && source !== 'initial') {
      console.log('Skipping URL change recording - initial URL not yet recorded');
      return;
    }
    
    // Patterns to ignore (automatic system navigation)
    const ignoredPatterns = [
      '/auth/',
      '/login',
      '/logout',
      'guestlogin',
      'redirect',
      'sso',
      'signin'
    ];
    
    // Check if this is an ignored URL
    const isIgnoredUrl = ignoredPatterns.some(pattern => currentUrl.toLowerCase().includes(pattern));
    
    // Check if it's just a root navigation (like going to home page)
    const isRootNavigation = currentUrl.endsWith('/') && currentUrl.split('/').length <= 4;
    
    // Only record if URL actually changed, is meaningful, and not too long
    if (currentUrl !== lastRecordedUrl && 
        !isIgnoredUrl && 
        !isRootNavigation &&
        currentUrl.length < 200) {
      
      const description = `Navigated to: ${currentUrl}`;
      recordJourney('url', currentUrl, JSON.stringify({ source, previousUrl: lastRecordedUrl }), {
        description: description,
        source: source
      });
      lastRecordedUrl = currentUrl;
      console.log('URL change recorded:', { from: lastRecordedUrl, to: currentUrl, source });
    }
  }
  
  // Detect page refresh/reload and clear journey data
  function detectPageRefresh() {
    // Check if this is a page refresh (not initial load from external navigation)
    const navigationEntries = performance.getEntriesByType('navigation');
    if (navigationEntries.length > 0) {
      const navEntry = navigationEntries[0];
      // Check if it's a reload type navigation
      if (navEntry.type === 'reload') {
        // Set marker for page refresh
        const refreshTime = Date.now();
        sessionStorage.setItem('devInsights_lastRefresh', refreshTime.toString());
        
        // Clear journey data for this tab immediately
        window.postMessage({ 
          type: 'DEV_INSIGHTS_CLEAR_JOURNEY',
          data: { reason: 'page_refresh', timestamp: refreshTime }
        }, '*');
        
        console.log('Page refresh detected - clearing journey data');
        
        // Reset the flag to allow new initial URL recording
        initialUrlRecorded = false;
        
        return true; // Indicate this was a refresh
      }
    }
    return false; // Not a refresh
  }

  // Check for page refresh immediately on script load
  let wasPageRefresh = false;
  try {
    wasPageRefresh = detectPageRefresh();
  } catch (e) {
    console.warn('Could not detect page refresh:', e);
  }

  // Also check on DOM ready if document is still loading
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      try {
        if (!wasPageRefresh) {
          wasPageRefresh = detectPageRefresh();
        }
      } catch (e) {
        console.warn('Could not detect page refresh on DOMContentLoaded:', e);
      }
    });
  }

  // Initial URL recording - always log the initial page load
  function recordInitialUrl() {
    // Prevent duplicate recordings
    if (initialUrlRecorded) {
      console.log('Initial URL already recorded, skipping duplicate');
      return;
    }
    
    const currentUrl = window.location.href;
    const description = `Page loaded: ${currentUrl}`;
    
    console.log('recordInitialUrl called for:', currentUrl);
    
    // Always record the initial URL regardless of patterns
    const journeyData = {
      type: 'url',
      value: currentUrl,
      element: JSON.stringify({ 
        source: 'initial_load',
        userAgent: navigator.userAgent,
        timestamp: Date.now(),
        isInitialLoad: true
      }),
      timestamp: Date.now(),
      description: description,
      pageUrl: currentUrl,
      pageTitle: document.title || 'Untitled',
      source: 'initial_load',
      isInitialLoad: true
    };
    
    // Add performance timing if available
    if (window.performance) {
      const navTiming = performance.getEntriesByType('navigation')[0];
      if (navTiming) {
        journeyData.loadTime = Math.round(navTiming.loadEventEnd - navTiming.loadEventStart);
        journeyData.domLoadTime = Math.round(navTiming.domContentLoadedEventEnd - navTiming.domContentLoadedEventStart);
        journeyData.fullLoadTime = Math.round(navTiming.loadEventEnd - navTiming.fetchStart);
        
        // Try to get page size from resource timing
        const resourceEntries = performance.getEntriesByType('resource');
        const totalSize = resourceEntries.reduce((sum, entry) => {
          return sum + (entry.transferSize || entry.encodedBodySize || 0);
        }, 0);
        if (totalSize > 0) {
          journeyData.size = totalSize;
        }
      }
    }
    
    console.log('Posting initial URL journey data:', journeyData);
    window.postMessage({ type: 'DEV_INSIGHTS_JOURNEY', data: journeyData }, '*');
    
    lastRecordedUrl = currentUrl;
    initialUrlRecorded = true; // Mark as recorded
    console.log('Initial URL recorded:', currentUrl);
  }

  // Record initial URL with single attempt to prevent duplicates
  console.log('Setting up initial URL recording...');
  console.log('Document ready state:', document.readyState);
  
  if (document.readyState === 'complete') {
    // Document is already fully loaded
    console.log('Document already complete, recording initial URL immediately');
    setTimeout(() => {
      recordInitialUrl();
    }, 50);
  } else if (document.readyState === 'interactive') {
    // DOM is ready but resources may still be loading
    console.log('Document interactive, recording initial URL with short delay');
    setTimeout(() => {
      recordInitialUrl();
    }, 100);
  } else {
    // Document is still loading, wait for DOMContentLoaded
    console.log('Document still loading, waiting for DOMContentLoaded');
    document.addEventListener('DOMContentLoaded', () => {
      console.log('DOMContentLoaded fired, recording initial URL');
      setTimeout(() => {
        recordInitialUrl();
      }, 50);
    });
  }
  
  // Listen for various navigation events
  window.addEventListener('popstate', () => {
    setTimeout(() => recordUrlChange('popstate'), 10);
  });
  
  // Listen for hashchange events (important for SPA navigation)
  window.addEventListener('hashchange', () => {
    setTimeout(() => recordUrlChange('hashchange'), 10);
  });
  
  // Use MutationObserver to detect URL changes from single-page applications
  let lastUrl = window.location.href;
  new MutationObserver(() => {
    const currentUrl = window.location.href;
    if (currentUrl !== lastUrl) {
      lastUrl = currentUrl;
      setTimeout(() => recordUrlChange('spa-navigation'), 50);
    }
  }).observe(document, { subtree: true, childList: true });
  
  // Periodically check for URL changes (fallback for missed changes)
  urlCheckInterval = setInterval(() => {
    if (window.location.href !== lastRecordedUrl) {
      recordUrlChange('periodic-check');
    }
  }, 500);
  
  // Override history methods to catch programmatic navigation
  const originalPushState = history.pushState;
  const originalReplaceState = history.replaceState;
  
  history.pushState = function(...args) {
    const result = originalPushState.apply(this, args);
    setTimeout(() => recordUrlChange('pushState'), 10);
    return result;
  };
  
  history.replaceState = function(...args) {
    const result = originalReplaceState.apply(this, args);
    setTimeout(() => recordUrlChange('replaceState'), 10);
    return result;
  };
  
  // Also track on focus in case user navigates via browser controls
  window.addEventListener('focus', () => {
    setTimeout(() => recordUrlChange('focus'), 50);
  });

  // Track clicks with detailed element info and improved sequencing
  document.addEventListener('click', (e) => {
    let target = e.target;
    if (target instanceof HTMLElement) {
      // Only track meaningful clicks - buttons, links, and interactive elements
      let elementType = target.tagName.toLowerCase();
      let desc = '';
      
      // Get meaningful text content - capture full text without truncation
      let text = '';
      
      // Try different methods to get the most comprehensive text content
      if (target.innerText && target.innerText.trim()) {
        text = target.innerText.trim();
      } else if (target.textContent && target.textContent.trim()) {
        text = target.textContent.trim();
      } else if (target.value && target.value.trim()) {
        text = target.value.trim();
      } else if (target.placeholder && target.placeholder.trim()) {
        text = target.placeholder.trim();
      } else if (target.title && target.title.trim()) {
        text = target.title.trim();
      } else if (target.alt && target.alt.trim()) {
        text = target.alt.trim();
      } else if (target.getAttribute('aria-label')) {
        text = target.getAttribute('aria-label').trim();
      }
      
      // For display purposes, create a shortened version but keep full text in element info
      let displayText = text;
      if (text.length > 100) {
        displayText = text.substring(0, 100) + '...';
      }
      
      // Check if this click will likely cause navigation
      let willNavigate = false;
      let navigationUrl = null;
      
      if (elementType === 'a' && target.href) {
        willNavigate = true;
        navigationUrl = target.href;
      } else if (target.onclick && target.onclick.toString().includes('location')) {
        willNavigate = true;
      }
      
      // Only track clicks on meaningful interactive elements
      if (elementType === 'button') {
        desc = displayText ? `Clicked button: "${displayText}"` : 'Clicked button';
      } else if (elementType === 'a') {
        desc = displayText ? `Clicked link: "${displayText}"` : 'Clicked link';
        if (navigationUrl) {
          desc += ` (leads to: ${navigationUrl})`;
        }
      } else if (elementType === 'input' && (target.type === 'button' || target.type === 'submit')) {
        desc = displayText ? `Clicked ${target.type}: "${displayText}"` : `Clicked ${target.type}`;
      } else if (elementType === 'select') {
        desc = displayText ? `Selected from dropdown: "${displayText}"` : 'Selected from dropdown';
      } else if (target.onclick || target.getAttribute('onclick') || target.classList.contains('clickable') || target.role === 'button') {
        // Only if it has click handlers or appears to be clickable
        if (displayText && displayText.length > 0) {
          desc = `Clicked: "${displayText}"`;
        } else {
          desc = `Clicked interactive element`;
        }
      } else {
        return; // Skip non-interactive elements
      }
      
      // Skip if description is empty or too generic
      if (!desc || desc.includes('undefined') || desc.includes('null')) {
        return;
      }
      
      let elementInfo = {
        tag: elementType,
        text: text || null, // Store the full text content
        displayText: displayText || null, // Store the truncated display version
        href: target.href || null,
        type: target.type || null,
        willNavigate: willNavigate,
        navigationUrl: navigationUrl,
        className: target.className || null,
        id: target.id || null
      };
      
      // If this might cause navigation or content loading, track performance and include in the same step
      if (willNavigate || target.onclick || target.getAttribute('onclick')) {
        // Record the click with performance tracking promise
        trackClickPerformance(target, desc).then((performanceData) => {
          // Update the description to include performance data if significant
          let enhancedDesc = desc;
          if (performanceData.loadTime > 100) {
            enhancedDesc += ` (Content loaded after click: ${performanceData.loadTime}ms)`;
          }
          
          const clickData = {
            description: enhancedDesc,
            willNavigate: willNavigate,
            loadTime: performanceData.loadTime,
            domLoadTime: performanceData.domLoadTime,
            fullLoadTime: performanceData.fullLoadTime
          };
          
          recordJourney('click', enhancedDesc, JSON.stringify(elementInfo), clickData);
        }).catch(() => {
          // If performance tracking fails, record the click without performance data
          const clickData = {
            description: desc,
            willNavigate: willNavigate
          };
          
          recordJourney('click', desc, JSON.stringify(elementInfo), clickData);
        });
      } else {
        // For non-navigation clicks, record immediately
        const clickData = {
          description: desc,
          willNavigate: willNavigate
        };
        
        recordJourney('click', desc, JSON.stringify(elementInfo), clickData);
      }
      
      // If this might cause navigation, record the current URL state
      if (willNavigate && navigationUrl) {
        // Add a slight delay to capture navigation after the click
        setTimeout(() => {
          recordUrlChange('click-navigation');
        }, 100);
      }
    }
  }, true);

  // Track input interactions - only when meaningful content is entered
  document.addEventListener('input', (e) => {
    let target = e.target;
    if (target instanceof HTMLElement && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
      // Only track if there's actual meaningful input
      const value = target.value.trim();
      if (value.length < 3) return; // Skip short inputs
      
      let desc = '';
      const inputType = target.type || 'text';
      const label = target.placeholder || target.name || target.getAttribute('aria-label') || 'field';
      
      if (target.tagName === 'TEXTAREA') {
        desc = `Entered text in ${label}`;
      } else {
        switch (inputType.toLowerCase()) {
          case 'email':
            desc = `Entered email in ${label}`;
            break;
          case 'password':
            desc = `Entered password in ${label}`;
            break;
          case 'search':
            desc = `Searched in ${label}`;
            break;
          case 'tel':
            desc = `Entered phone number in ${label}`;
            break;
          case 'number':
            desc = `Entered number in ${label}`;
            break;
          default:
            desc = `Entered text in ${label}`;
        }
      }
      
      recordJourney('input', desc, JSON.stringify({
        type: inputType,
        placeholder: target.placeholder || null,
        fieldName: target.name || null
      }), {
        description: desc,
        fieldType: inputType,
        fieldLabel: label
      });
    }
  }, true);

  // Track focus events - only for form fields
  document.addEventListener('focus', (e) => {
    let target = e.target;
    if (target instanceof HTMLElement && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT')) {
      const label = target.placeholder || target.name || target.getAttribute('aria-label') || 'field';
      let desc = `Focused on ${label}`;
      recordJourney('focus', desc, null, {
        description: desc,
        fieldType: target.type || target.tagName.toLowerCase(),
        fieldLabel: label
      });
    }
  }, true);

  // Skip scroll tracking as it's not useful for error reproduction
})();