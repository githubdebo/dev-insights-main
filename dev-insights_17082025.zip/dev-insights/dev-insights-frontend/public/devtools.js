// Create a DevTools panel that shows the same content as the popup
chrome.devtools.panels.create(
  'Dev Insights',
  '',
  'panel.html',
  function(panel) {
    console.log('Dev Insights DevTools panel created');
    
    // Optional: Add panel event listeners
    panel.onShown.addListener(function(window) {
      console.log('Dev Insights panel shown');
    });
    
    panel.onHidden.addListener(function() {
      console.log('Dev Insights panel hidden');
    });
  }
);
