// Content script for Developer Insights Extension
class DevInsightsContent {
  constructor() {
    this.injectPageScript();
    this.setupMessageListener();
  }

  injectPageScript() {
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('injected.js');
    script.onload = () => script.remove();
    (document.head || document.documentElement).appendChild(script);
    // Listen for messages from injected script
    window.addEventListener('message', (event) => {
      if (event.source !== window) return;
      if (event.data && event.data.type === 'NETWORK_REQUEST') {
        try {
          chrome.runtime.sendMessage({
            type: 'INJECTED_NETWORK_REQUEST',
            data: event.data.data
          });
        } catch (error) {
          // Ignore errors if extension context is invalidated
        }
      }
      // Listen for error context events
      if (event.data && event.data.type === 'ERROR_CONTEXT') {
        try {
          chrome.runtime.sendMessage({
            type: 'ERROR_CONTEXT',
            data: event.data.data
          });
        } catch (error) {
          // Ignore errors if extension context is invalidated
        }
      }
      // Listen for journey events (clicks, navigation)
      if (event.data && event.data.type === 'DEV_INSIGHTS_JOURNEY') {
        // Forward journey event to background, let background use sender.tab.id
        try {
          chrome.runtime.sendMessage({
            type: 'JOURNEY_EVENT',
            data: event.data.data
          });
        } catch (error) {
          // Ignore errors if extension context is invalidated
        }
      }
      // Listen for clear journey events (page refresh)
      if (event.data && event.data.type === 'DEV_INSIGHTS_CLEAR_JOURNEY') {
        try {
          chrome.runtime.sendMessage({
            type: 'CLEAR_JOURNEY_ON_REFRESH',
            data: event.data.data
          });
        } catch (error) {
          // Ignore errors if extension context is invalidated
        }
      }
    });
  }

  setupMessageListener() {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.type === 'TRIGGER_TEST_ERROR') {
        // Inject a script to trigger a console error on the page
        const script = document.createElement('script');
        script.textContent = `
          setTimeout(() => {
            console.error('Test console error from Developer Insights extension', {
              type: 'test-error',
              timestamp: new Date().toISOString(),
              source: 'DevInsights Extension Test'
            });
          }, 100);
        `;
        document.head.appendChild(script);
        script.remove();
        sendResponse({ success: true });
        return true;
      } else if (request.type === 'GET_JOURNEY') {
        chrome.runtime.sendMessage({ type: 'GET_TAB_ID' }, (tabResp) => {
          if (chrome.runtime.lastError) {
            sendResponse({ steps: [] });
            return;
          }
          const tabId = tabResp?.tabId || 'global';
          const key = `devInsightsJourney_${tabId}`;
          try {
            chrome.storage.local.get([key], (result) => {
              if (chrome.runtime.lastError) {
                sendResponse({ steps: [] });
              } else {
                sendResponse({ steps: result[key] || [] });
              }
            });
          } catch (error) {
            sendResponse({ steps: [] });
          }
        });
        return true;
      } else if (request.type === 'GET_TAB_ID') {
        try {
          chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (chrome.runtime.lastError) {
              sendResponse({ tabId: 'unknown' });
            } else {
              sendResponse({ tabId: tabs[0]?.id });
            }
          });
        } catch (error) {
          sendResponse({ tabId: 'unknown' });
        }
        return true;
      }
      return true;
    });
  }

}

// Initialize content script
new DevInsightsContent();