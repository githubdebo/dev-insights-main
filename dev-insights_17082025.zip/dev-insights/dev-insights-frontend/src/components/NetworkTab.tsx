import React, { useState, useEffect } from 'react';
import { RefreshCw, Download, Trash2, Clock, AlertCircle, CheckCircle, Activity, Copy, Eye, ChevronDown, ChevronRight } from 'lucide-react';

interface NetworkRequest {
  id: string;
  method: string;
  url: string;
  status: number | string;
  statusText?: string;
  timestamp: number;
  duration?: number;
  type?: string;
  requestBody?: any;
  responseBody?: any;
  requestHeaders?: Record<string, string>;
}

interface NetworkTabProps {
  tabId: number | null;
  type: 'api' | 'assets';
  displayedCalls: NetworkRequest[];
  setDisplayedCalls: React.Dispatch<React.SetStateAction<NetworkRequest[]>>;
}

// Categorize request performance based on duration
const getPerformanceInfo = (duration?: number) => {
  if (!duration || duration === 0) return { category: 'unknown', color: 'text-gray-400', icon: null, label: 'Unknown' };
  
  if (duration < 200) {
    return { category: 'fast', color: 'text-green-400', icon: '⚡', label: 'Fast' };
  } else if (duration < 1000) {
    return { category: 'normal', color: 'text-blue-400', icon: '⏱️', label: 'Normal' };
  } else if (duration < 3000) {
    return { category: 'slow', color: 'text-yellow-400', icon: '⚠️', label: 'Slow' };
  } else {
    return { category: 'very-slow', color: 'text-red-400', icon: '🐌', label: 'Very Slow' };
  }
};

// Format URL for display in the UI
const formatUrlForDisplay = (url: string): { displayUrl: string; fullUrl: string } => {
  try {
    const urlObj = new URL(url);
    const currentOrigin = window.location.origin;
    
    // If it's the same origin, show just the path and query
    if (urlObj.origin === currentOrigin) {
      return {
        displayUrl: urlObj.pathname + urlObj.search + urlObj.hash,
        fullUrl: url
      };
    }
    
    // If it's cross-origin, show the full URL but highlight the path
    return {
      displayUrl: url,
      fullUrl: url
    };
  } catch {
    // If URL parsing fails, return as-is
    return {
      displayUrl: url,
      fullUrl: url
    };
  }
};

export const NetworkTab: React.FC<NetworkTabProps> = ({ tabId, type, displayedCalls, setDisplayedCalls }) => {
  const [requests, setRequests] = useState<NetworkRequest[]>([]);
  const [apiCalls, setApiCalls] = useState<NetworkRequest[]>([]);
  const [otherCalls, setOtherCalls] = useState<NetworkRequest[]>([]);
  const [filter, setFilter] = useState('');
  const [performanceFilter, setPerformanceFilter] = useState('all');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState<NetworkRequest | null>(null);
  const [jsonViewerData, setJsonViewerData] = useState<{ data: any; title: string } | null>(null);
  const [expandedKeys, setExpandedKeys] = useState<Set<string>>(new Set());

  // Copy data to clipboard - optimized for DevTools context
  const copyToClipboard = async (text: string) => {
    // Create a larger, more visible textarea with the content
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.top = '50%';
    textarea.style.left = '50%';
    textarea.style.transform = 'translate(-50%, -50%)';
    textarea.style.width = '80vw';
    textarea.style.height = '70vh';
    textarea.style.maxWidth = '800px';
    textarea.style.maxHeight = '600px';
    textarea.style.minWidth = '500px';
    textarea.style.minHeight = '400px';
    textarea.style.zIndex = '10000';
    textarea.style.background = '#1f2937';
    textarea.style.color = '#e5e7eb';
    textarea.style.border = '2px solid #60a5fa';
    textarea.style.borderRadius = '8px';
    textarea.style.padding = '16px';
    textarea.style.fontSize = '14px';
    textarea.style.fontFamily = 'Consolas, Monaco, "Courier New", monospace';
    textarea.style.boxShadow = '0 20px 50px rgba(0, 0, 0, 0.8)';
    textarea.readOnly = true;
    textarea.style.resize = 'both';
    textarea.style.overflow = 'auto';
    
    // Create overlay background
    const overlay = document.createElement('div');
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.background = 'rgba(0, 0, 0, 0.8)';
    overlay.style.zIndex = '9999';
    
    document.body.appendChild(overlay);
    document.body.appendChild(textarea);
    textarea.focus();
    textarea.select();
    
    // Try to copy automatically
    try {
      document.execCommand('copy');
    } catch {
      // Silent failure - user can copy manually
    }
    
    // Remove elements when user clicks outside or presses escape
    const cleanup = () => {
      if (document.body.contains(textarea)) {
        document.body.removeChild(textarea);
      }
      if (document.body.contains(overlay)) {
        document.body.removeChild(overlay);
      }
      document.removeEventListener('click', cleanup);
      document.removeEventListener('keydown', escapeHandler);
    };
    
    const escapeHandler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        cleanup();
      }
    };
    
    // Close when clicking on overlay (but not textarea)
    overlay.addEventListener('click', cleanup);
    
    // Prevent clicks on the textarea from closing the modal
    textarea.addEventListener('click', (e) => {
      e.stopPropagation();
    });
    
    // Add keyboard listener
    document.addEventListener('keydown', escapeHandler);
  };

  // Format JSON data for display
  const formatJsonData = (data: any): string => {
    if (!data) return '';
    if (typeof data === 'string') {
      try {
        // Try to parse and reformat if it's a JSON string
        const parsed = JSON.parse(data);
        return JSON.stringify(parsed, null, 2);
      } catch {
        // If not JSON, return as-is
        return data;
      }
    }
    return JSON.stringify(data, null, 2);
  };

  const loadNetworkData = async () => {
    if (!tabId) return;
    
    setIsLoading(true);
    try {
      const response = await chrome.runtime.sendMessage({
        type: 'GET_NETWORK_DATA',
        tabId: tabId
      });
      setRequests(response.networkRequests || []);
    } catch (error) {
      console.error('Failed to load network data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const clearNetworkData = async () => {
    if (!tabId) return;
    try {
      await chrome.runtime.sendMessage({
        type: 'CLEAR_NETWORK_DATA',
        tabId: tabId
      });
      setRequests([]);
      setDisplayedCalls([]); // Also clear the persistent displayed calls for this tab
    } catch (error) {
      console.error('Failed to clear network data:', error);
    }
  };

  useEffect(() => {
    loadNetworkData();
    const interval = setInterval(loadNetworkData, 2000); // Refresh every 2 seconds
    return () => clearInterval(interval);
  }, [tabId]);

  // Group calls similar to ApiTesterTab - but consider all unique aspects
  useEffect(() => {
    // Helper function to create a comprehensive unique key for each request
    const createUniqueKey = (call: NetworkRequest) => {
      const url = call.url || '';
      const method = call.method || '';
      const requestBodyStr = JSON.stringify(call.requestBody || '');
      const headersStr = JSON.stringify(call.requestHeaders || {});
      
      // Parse URL to separate base URL from query parameters
      try {
        const urlObj = new URL(url);
        const baseUrl = `${urlObj.origin}${urlObj.pathname}`;
        const queryParams = urlObj.search;
        
        // Create unique key including method, base URL, query params, request body, and key headers
        return `${method}||${baseUrl}||${queryParams}||${requestBodyStr}||${headersStr}`;
      } catch {
        // Fallback for invalid URLs
        return `${method}||${url}||${requestBodyStr}||${headersStr}`;
      }
    };

    // Remove duplicates based on comprehensive uniqueness
    const removeDuplicates = (calls: NetworkRequest[]) => {
      const seen = new Map<string, NetworkRequest>();
      
      // Sort calls by timestamp first to process them chronologically
      const sortedCalls = [...calls].sort((a, b) => a.timestamp - b.timestamp);
      
      sortedCalls.forEach(call => {
        const key = createUniqueKey(call);
        
        if (!seen.has(key)) {
          // First occurrence - add it
          seen.set(key, call);
        } else {
          // Duplicate found - keep the one with more complete data
          const existing = seen.get(key)!;
          const existingDataSize = (existing.responseBody?.length || 0) + 
                                  (existing.requestBody?.length || 0) + 
                                  Object.keys(existing.requestHeaders || {}).length;
          const newDataSize = (call.responseBody?.length || 0) + 
                             (call.requestBody?.length || 0) + 
                             Object.keys(call.requestHeaders || {}).length;
          
          // Keep the request with more complete data, but if data is equal, keep the newer one
          if (newDataSize > existingDataSize || 
              (newDataSize === existingDataSize && call.timestamp > existing.timestamp)) {
            seen.set(key, call);
          }
        }
      });
      
      return Array.from(seen.values());
    };

    // Group calls with 'api' in URL
    const apiCallsFiltered = displayedCalls
      .filter(call => call.url.toLowerCase().includes('api'));
    const uniqueApiCalls = removeDuplicates(apiCallsFiltered)
      .sort((a, b) => b.timestamp - a.timestamp); // Sort by timestamp, newest first
    
    // Group all other calls
    const otherCallsFiltered = displayedCalls
      .filter(call => !call.url.toLowerCase().includes('api'));
    const uniqueOtherCalls = removeDuplicates(otherCallsFiltered)
      .sort((a, b) => b.timestamp - a.timestamp); // Sort by timestamp, newest first
    
    setApiCalls(uniqueApiCalls);
    setOtherCalls(uniqueOtherCalls);
  }, [displayedCalls]);

  // Enhanced deduplication that considers all request characteristics
  function dedupeRequests(requests: NetworkRequest[]) {
    const seen = new Map<string, NetworkRequest>();
    
    requests.forEach(req => {
      // Create comprehensive key including request body and key headers
      const requestBodyStr = JSON.stringify(req.requestBody || '');
      const headersStr = JSON.stringify(req.requestHeaders || {});
      
      try {
        const urlObj = new URL(req.url);
        const baseUrl = `${urlObj.origin}${urlObj.pathname}`;
        const queryParams = urlObj.search;
        const key = `${req.method}|${baseUrl}|${queryParams}|${requestBodyStr}|${headersStr}`;
        
        if (!seen.has(key)) {
          seen.set(key, req);
        } else {
          // Keep the request with more complete response data
          const existing = seen.get(key)!;
          const existingResponseSize = existing.responseBody?.length || 0;
          const newResponseSize = req.responseBody?.length || 0;
          
          if (newResponseSize > existingResponseSize) {
            seen.set(key, req);
          }
        }
      } catch {
        // Fallback for invalid URLs - use original logic with enhanced key
        const key = `${req.method}|${req.url}|${Math.round(req.timestamp)}|${requestBodyStr}`;
        if (!seen.has(key)) {
          seen.set(key, req);
        }
      }
    });
    
    return Array.from(seen.values());
  }
  function mergeRequests(requests: NetworkRequest[]) {
    const map = new Map();
    
    for (const req of requests) {
      // Create comprehensive key for merging
      const requestBodyStr = JSON.stringify(req.requestBody || '');
      const headersStr = JSON.stringify(req.requestHeaders || {});
      
      let key: string;
      try {
        const urlObj = new URL(req.url);
        const baseUrl = `${urlObj.origin}${urlObj.pathname}`;
        const queryParams = urlObj.search;
        key = `${req.method}|${baseUrl}|${queryParams}|${requestBodyStr}|${headersStr}`;
      } catch {
        // Fallback for invalid URLs
        key = `${req.method}|${req.url}|${Math.round(req.timestamp)}|${requestBodyStr}`;
      }
      
      if (!map.has(key)) {
        map.set(key, req);
      } else {
        const existing = map.get(key);
        const hasExistingBody = existing.requestBody || existing.responseBody;
        const hasNewBody = req.requestBody || req.responseBody;
        
        if (hasNewBody && !hasExistingBody) {
          map.set(key, { ...existing, ...req });
        } else if (hasNewBody && hasExistingBody) {
          const existingLen = (existing.responseBody?.length || 0) + (existing.requestBody?.length || 0);
          const newLen = (req.responseBody?.length || 0) + (req.requestBody?.length || 0);
          if (newLen > existingLen) {
            map.set(key, { ...existing, ...req });
          }
        }
      }
    }
    return Array.from(map.values());
  }

  // Update persistent displayedCalls (from props) - now considers all request characteristics
  useEffect(() => {
    let processedRequests = mergeRequests(dedupeRequests(requests));
    if (type === 'api') {
      processedRequests = processedRequests.filter(req => req.requestBody || req.responseBody);
    }
    
    // Create comprehensive keys for existing calls
    const createComprehensiveKey = (req: NetworkRequest) => {
      const requestBodyStr = JSON.stringify(req.requestBody || '');
      const headersStr = JSON.stringify(req.requestHeaders || {});
      
      try {
        const urlObj = new URL(req.url);
        const baseUrl = `${urlObj.origin}${urlObj.pathname}`;
        const queryParams = urlObj.search;
        return `${req.method}|${baseUrl}|${queryParams}|${requestBodyStr}|${headersStr}`;
      } catch {
        return `${req.method}|${req.url}|${Math.round(req.timestamp)}|${requestBodyStr}`;
      }
    };
    
    // Add new calls to persistent list, never remove
    const existingKeys = new Set(displayedCalls.map(req => createComprehensiveKey(req)));
    const newCalls = processedRequests.filter(req => !existingKeys.has(createComprehensiveKey(req)));
    
    if (newCalls.length > 0) {
      setDisplayedCalls(prev => [...prev, ...newCalls]);
    }
    // eslint-disable-next-line
  }, [requests, type]);

  // Filtering for display using grouped calls
  const filteredRequests = (() => {
    // Choose the appropriate call list based on type
    const sourceRequests = type === 'api' ? apiCalls : otherCalls;
    
    return sourceRequests.filter(req => {
      const url = req.url || '';
      const method = req.method || '';
      const matchesFilter = url.toLowerCase().includes(filter.toLowerCase()) ||
        method.toLowerCase().includes(filter.toLowerCase());
      
      // Performance filtering
      const perfInfo = getPerformanceInfo(req.duration);
      const matchesPerformance = performanceFilter === 'all' || perfInfo.category === performanceFilter;
      
      return matchesFilter && matchesPerformance;
    });
  })();

  const getStatusColor = (status: number | string) => {
    const statusNum = typeof status === 'string' ? parseInt(status) : status;
    if (statusNum >= 200 && statusNum < 300) return 'text-green-400';
    if (statusNum >= 300 && statusNum < 400) return 'text-yellow-400';
    if (statusNum >= 400) return 'text-red-400';
    return 'text-gray-400';
  };

  const getStatusIcon = (status: number | string) => {
    const statusNum = typeof status === 'string' ? parseInt(status) : status;
    if (statusNum >= 200 && statusNum < 300) return <CheckCircle size={14} className="text-green-400" />;
    if (statusNum >= 400) return <AlertCircle size={14} className="text-red-400" />;
    return <Clock size={14} className="text-gray-400" />;
  };

  // JSON viewer functionality
  const openJsonViewer = (data: any, title: string) => {
    setJsonViewerData({ data, title });
    setExpandedKeys(new Set()); // Reset expanded state when opening new viewer
  };

  const closeJsonViewer = () => {
    setJsonViewerData(null);
    setExpandedKeys(new Set()); // Reset expanded state when closing
  };

  // JSON Tree Component for hierarchical display
  const JsonTree = ({ data, level = 0 }: { data: any; level?: number }) => {
    const toggleExpanded = (key: string) => {
      const newExpanded = new Set(expandedKeys);
      if (newExpanded.has(key)) {
        newExpanded.delete(key);
      } else {
        newExpanded.add(key);
      }
      setExpandedKeys(newExpanded);
    };

    const renderValue = (value: any, key: string, path: string) => {
      const isExpanded = expandedKeys.has(path);
      const indent = level * 20;

      // Handle primitive values - show key: value
      if (value === null) {
        return (
          <div className="flex items-center" style={{ paddingLeft: `${indent}px` }}>
            <span className="text-blue-300">{key}:</span>
            <span className="text-gray-500 ml-2">null</span>
          </div>
        );
      }
      
      if (value === undefined) {
        return (
          <div className="flex items-center" style={{ paddingLeft: `${indent}px` }}>
            <span className="text-blue-300">{key}:</span>
            <span className="text-gray-500 ml-2">undefined</span>
          </div>
        );
      }
      
      if (typeof value === 'boolean') {
        return (
          <div className="flex items-center" style={{ paddingLeft: `${indent}px` }}>
            <span className="text-blue-300">{key}:</span>
            <span className="text-purple-400 ml-2">{value.toString()}</span>
          </div>
        );
      }
      
      if (typeof value === 'number') {
        return (
          <div className="flex items-center" style={{ paddingLeft: `${indent}px` }}>
            <span className="text-blue-300">{key}:</span>
            <span className="text-green-400 ml-2">{value}</span>
          </div>
        );
      }
      
      if (typeof value === 'string') {
        return (
          <div className="flex items-center" style={{ paddingLeft: `${indent}px` }}>
            <span className="text-blue-300">{key}:</span>
            <span className="text-yellow-400 ml-2">"{value}"</span>
          </div>
        );
      }

      if (Array.isArray(value)) {
        return (
          <div>
            <div 
              className="flex items-center cursor-pointer hover:bg-gray-700 p-1 rounded"
              onClick={() => toggleExpanded(path)}
              style={{ paddingLeft: `${indent}px` }}
            >
              {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
              <span className="text-blue-300 ml-1">{key}: Array[{value.length}]</span>
            </div>
            {isExpanded && (
              <div>
                {value.map((item, index) => (
                  <div key={index} style={{ paddingLeft: `${indent + 20}px` }}>
                    <JsonTree data={{ [`[${index}]`]: item }} level={level + 1} />
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      }

      if (typeof value === 'object') {
        const keys = Object.keys(value);
        return (
          <div>
            <div 
              className="flex items-center cursor-pointer hover:bg-gray-700 p-1 rounded"
              onClick={() => toggleExpanded(path)}
              style={{ paddingLeft: `${indent}px` }}
            >
              {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
              <span className="text-blue-300 ml-1">{key}: Object{`{${keys.length}}`}</span>
            </div>
            {isExpanded && (
              <div>
                {keys.map(objKey => (
                  <div key={objKey} style={{ paddingLeft: `${indent + 20}px` }}>
                    <JsonTree data={{ [objKey]: value[objKey] }} level={level + 1} />
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      }

      return <span>{String(value)}</span>;
    };

    if (typeof data === 'object' && data !== null) {
      return (
        <div>
          {Object.entries(data).map(([key, value]) => (
            <div key={key} className="mb-1">
              {renderValue(value, key, `${level}-${key}`)}
            </div>
          ))}
        </div>
      );
    }

    return <div className="text-gray-300">{JSON.stringify(data, null, 2)}</div>;
  };

  return (
    <div className="h-full flex flex-col">
      {/* Controls */}
      <div className="p-4 bg-gray-800 border-b border-gray-700">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            {/* Action Buttons - Icons Only */}
            <button
              onClick={loadNetworkData}
              disabled={isLoading}
              className="p-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded transition-colors"
              title="Refresh network data"
            >
              <RefreshCw size={16} className={isLoading ? 'animate-spin' : ''} />
            </button>
            <button
              onClick={clearNetworkData}
              className="p-2 bg-red-600 hover:bg-red-700 text-white rounded transition-colors"
              title="Clear network data"
            >
              <Trash2 size={16} />
            </button>
            {type === 'api' && (
              <button
                onClick={() => {
                  const dataStr = JSON.stringify(filteredRequests, null, 2);
                  const dataBlob = new Blob([dataStr], { type: 'application/json' });
                  const url = URL.createObjectURL(dataBlob);
                  const link = document.createElement('a');
                  link.href = url;
                  link.download = `api-requests-${Date.now()}.json`;
                  link.click();
                  URL.revokeObjectURL(url);
                }}
                className="p-2 bg-green-600 hover:bg-green-700 text-white rounded transition-colors"
                title="Export API requests"
              >
                <Download size={16} />
              </button>
            )}
            {type === 'assets' && (
              <button
                onClick={() => {
                  const dataStr = JSON.stringify(filteredRequests, null, 2);
                  const dataBlob = new Blob([dataStr], { type: 'application/json' });
                  const url = URL.createObjectURL(dataBlob);
                  const link = document.createElement('a');
                  link.href = url;
                  link.download = `asset-requests-${Date.now()}.json`;
                  link.click();
                  URL.revokeObjectURL(url);
                }}
                className="p-2 bg-green-600 hover:bg-green-700 text-white rounded transition-colors"
                title="Export asset requests"
              >
                <Download size={16} />
              </button>
            )}
            
            {/* Performance Filter Dropdown */}
            <div className="flex items-center space-x-2 ml-4">
              <select
                value={performanceFilter}
                onChange={(e) => setPerformanceFilter(e.target.value)}
                className="px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white text-sm focus:outline-none focus:border-blue-500"
                title="Filter by performance"
              >
                <option value="all">All Performance</option>
                <option value="fast">⚡ Fast (&lt;200ms)</option>
                <option value="normal">⏱️ Normal (200ms-1s)</option>
                <option value="slow">⚠️ Slow (1s-3s)</option>
                <option value="very-slow">🐌 Very Slow (&gt;3s)</option>
                <option value="unknown">❓ Unknown</option>
              </select>
              
              {/* Performance Summary Icons */}
              {(apiCalls.length > 0 || otherCalls.length > 0) && (
                <div className="flex items-center space-x-2">
                  {(() => {
                    const requestsWithDuration = type === 'api' ? apiCalls : otherCalls;
                    const fastCalls = requestsWithDuration.filter(req => {
                      const perfInfo = getPerformanceInfo(req.duration);
                      return perfInfo.category === 'fast';
                    }).length;
                    const normalCalls = requestsWithDuration.filter(req => {
                      const perfInfo = getPerformanceInfo(req.duration);
                      return perfInfo.category === 'normal';
                    }).length;
                    const slowCalls = requestsWithDuration.filter(req => {
                      const perfInfo = getPerformanceInfo(req.duration);
                      return perfInfo.category === 'slow';
                    }).length;
                    const verySlowCalls = requestsWithDuration.filter(req => {
                      const perfInfo = getPerformanceInfo(req.duration);
                      return perfInfo.category === 'very-slow';
                    }).length;
                    
                    return (
                      <>
                        {fastCalls > 0 && <span className="text-green-400 text-sm" title={`Fast calls: ${fastCalls}`}>⚡ {fastCalls}</span>}
                        {normalCalls > 0 && <span className="text-blue-400 text-sm" title={`Normal calls: ${normalCalls}`}>⏱️ {normalCalls}</span>}
                        {slowCalls > 0 && <span className="text-yellow-400 text-sm" title={`Slow calls: ${slowCalls}`}>⚠️ {slowCalls}</span>}
                        {verySlowCalls > 0 && <span className="text-red-400 text-sm" title={`Very slow calls: ${verySlowCalls}`}>🐌 {verySlowCalls}</span>}
                      </>
                    );
                  })()}
                </div>
              )}
            </div>
          </div>
          
          <div className="text-sm text-gray-400">
            {filteredRequests.length} requests
          </div>
        </div>
        
        <div className="space-y-3">
          <input
            type="text"
            placeholder="Filter requests by URL or method..."
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
          />
        </div>
      </div>

      {/* Request List */}
      <div className="flex-1 overflow-y-auto relative">
        {filteredRequests.length === 0 ? (
          <div className="flex items-center justify-center h-full text-gray-400">
            <div className="text-center">
              <Activity size={48} className="mx-auto mb-4 opacity-50" />
              <p>No network requests captured yet</p>
              <p className="text-sm mt-1">Navigate the page to see network activity</p>
            </div>
          </div>
        ) : (
          <div className="divide-y divide-gray-700">
            {filteredRequests.map((request, index) => (
              <React.Fragment key={`${request.id}-${index}`}>
                <div
                  className={`p-3 hover:bg-gray-800 transition-colors cursor-pointer ${selectedRequest?.id === request.id ? 'bg-gray-800' : ''}`}
                  onClick={() => setSelectedRequest(selectedRequest?.id === request.id ? null : request)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(request.status)}
                      <span className="font-mono text-sm font-semibold text-blue-400">
                        {request.method}
                      </span>
                      <span className={`font-mono text-sm ${getStatusColor(request.status)}`}>
                        {request.status}
                      </span>
                      {request.duration && (
                        <>
                          <span className="text-xs text-gray-400">
                            {request.duration.toFixed(0)}ms
                          </span>
                          {(() => {
                            const perfInfo = getPerformanceInfo(request.duration);
                            return perfInfo.icon ? (
                              <span 
                                className={`text-xs ${perfInfo.color}`} 
                                title={`${perfInfo.label} (${request.duration.toFixed(0)}ms)`}
                              >
                                {perfInfo.icon}
                              </span>
                            ) : null;
                          })()}
                        </>
                      )}
                      
                      {type === 'assets' && request.responseBody && (
                        <span className="text-xs text-green-400 ml-2">
                          {typeof request.responseBody === 'string'
                            ? `${new Blob([request.responseBody]).size} bytes`
                            : `${JSON.stringify(request.responseBody).length} bytes`}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="text-sm text-gray-300 break-all" title={request.url}>
                    {formatUrlForDisplay(request.url).displayUrl}
                  </div>
                  
                  {/* Show request body preview if available */}
                  {request.requestBody && (
                    <div className="text-xs text-blue-300 mt-1 bg-blue-900 bg-opacity-20 px-2 py-1 rounded">
                      <span className="font-semibold">Body: </span>
                      {typeof request.requestBody === 'string' 
                        ? request.requestBody.length > 50 
                          ? `${request.requestBody.substring(0, 50)}...`
                          : request.requestBody
                        : JSON.stringify(request.requestBody).length > 50
                          ? `${JSON.stringify(request.requestBody).substring(0, 50)}...`
                          : JSON.stringify(request.requestBody)
                      }
                    </div>
                  )}
                  
                  {/* Show query parameters if available */}
                  {(() => {
                    try {
                      const urlObj = new URL(request.url);
                      if (urlObj.search) {
                        const params = new URLSearchParams(urlObj.search);
                        const paramEntries = Array.from(params.entries());
                        if (paramEntries.length > 0) {
                          return (
                            <div className="text-xs text-green-300 mt-1 bg-green-900 bg-opacity-20 px-2 py-1 rounded">
                              <span className="font-semibold">Params: </span>
                              {paramEntries.slice(0, 2).map(([key, value]) => 
                                `${key}=${value.length > 20 ? value.substring(0, 20) + '...' : value}`
                              ).join(', ')}
                              {paramEntries.length > 2 && ` +${paramEntries.length - 2} more`}
                            </div>
                          );
                        }
                      }
                      return null;
                    } catch {
                      return null;
                    }
                  })()}
                  {request.statusText && (
                    <div className="text-xs text-gray-400 mt-1">
                      {request.statusText}
                    </div>
                  )}
                </div>
                {selectedRequest?.id === request.id && (
                  <div className="bg-gray-400 border-t border-b border-gray-500 p-4 text-sm shadow-lg">
                    <button
                      className="absolute right-8 mt-1 text-gray-700 hover:text-red-500 text-lg font-bold transition-colors"
                      onClick={() => setSelectedRequest(null)}
                      aria-label="Close details"
                    >
                      ×
                    </button>
                    <div className="mb-4 pr-8">
                      <span className="font-semibold text-indigo-800 bg-indigo-100 px-2 py-1 rounded text-xs">{selectedRequest?.method}</span>
                      <span className="ml-3 text-gray-900 break-all font-medium">{selectedRequest?.url}</span>
                    </div>
                    
                    {/* Request Headers */}
                    {selectedRequest?.requestHeaders && Object.keys(selectedRequest.requestHeaders).length > 0 && (
                      <div className="mb-4">
                        <div className="flex items-center justify-between mb-2">
                          <div className="font-semibold text-gray-800 bg-emerald-100 px-2 py-1 rounded text-xs">Request Headers</div>
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => openJsonViewer(selectedRequest.requestHeaders!, 'Request Headers')}
                              className="p-1 text-gray-700 hover:text-emerald-600 transition-colors"
                              title="View headers hierarchy"
                            >
                              <Eye size={12} />
                            </button>
                            <button
                              onClick={() => copyToClipboard(Object.entries(selectedRequest.requestHeaders!).map(([key, value]) => `${key}: ${value}`).join('\n'))}
                              className="p-1 text-gray-700 hover:text-blue-600 transition-colors"
                              title="Copy request headers"
                            >
                              <Copy size={12} />
                            </button>
                          </div>
                        </div>
                        <pre className="bg-gray-200 border border-gray-300 p-3 rounded-md text-gray-800 whitespace-pre-wrap break-all max-h-32 overflow-auto text-xs shadow-sm font-mono">
                          {Object.entries(selectedRequest.requestHeaders).map(([key, value]) => `${key}: ${value}`).join('\n')}
                        </pre>
                      </div>
                    )}
                    
                    {/* Request Body */}
                    <div className="mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="font-semibold text-gray-800 bg-blue-100 px-2 py-1 rounded text-xs">Request Body</div>
                        {selectedRequest?.requestBody && (
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => {
                                try {
                                  const parsedData = typeof selectedRequest.requestBody === 'string' 
                                    ? JSON.parse(selectedRequest.requestBody) 
                                    : selectedRequest.requestBody;
                                  openJsonViewer(parsedData, 'Request Body');
                                } catch {
                                  openJsonViewer(selectedRequest.requestBody, 'Request Body');
                                }
                              }}
                              className="p-1 text-gray-700 hover:text-emerald-600 transition-colors"
                              title="View JSON hierarchy"
                            >
                              <Eye size={12} />
                            </button>
                            <button
                              onClick={() => copyToClipboard(formatJsonData(selectedRequest.requestBody))}
                              className="p-1 text-gray-700 hover:text-blue-600 transition-colors"
                              title="Copy request body"
                            >
                              <Copy size={12} />
                            </button>
                          </div>
                        )}
                      </div>
                      <pre className="bg-gray-200 border border-gray-300 p-3 rounded-md text-gray-800 whitespace-pre-wrap break-all max-h-32 overflow-auto text-xs shadow-sm font-mono">
                        {selectedRequest?.requestBody
                          ? formatJsonData(selectedRequest.requestBody)
                          : 'No request body'}
                      </pre>
                    </div>
                    
                    {/* Response Body */}
                    <div className="mb-2">
                      <div className="flex items-center justify-between mb-2">
                        <div className="font-semibold text-gray-800 bg-amber-100 px-2 py-1 rounded text-xs">
                          {type === 'assets' ? 'Response Content' : 'Response'}
                        </div>
                        {selectedRequest?.responseBody && (
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => {
                                try {
                                  const parsedData = typeof selectedRequest.responseBody === 'string' 
                                    ? JSON.parse(selectedRequest.responseBody) 
                                    : selectedRequest.responseBody;
                                  openJsonViewer(parsedData, type === 'assets' ? 'Response Content' : 'Response Body');
                                } catch {
                                  openJsonViewer(selectedRequest.responseBody, type === 'assets' ? 'Response Content' : 'Response Body');
                                }
                              }}
                              className="p-1 text-gray-700 hover:text-emerald-600 transition-colors"
                              title="View JSON hierarchy"
                            >
                              <Eye size={12} />
                            </button>
                            <button
                              onClick={() => copyToClipboard(formatJsonData(selectedRequest.responseBody))}
                              className="p-1 text-gray-700 hover:text-blue-600 transition-colors"
                              title={type === 'assets' ? 'Copy response content' : 'Copy response body'}
                            >
                              <Copy size={12} />
                            </button>
                          </div>
                        )}
                      </div>
                      <pre className="bg-gray-200 border border-gray-300 p-3 rounded-md text-gray-800 whitespace-pre-wrap break-all max-h-32 overflow-auto text-xs shadow-sm font-mono">
                        {selectedRequest?.responseBody
                          ? formatJsonData(selectedRequest.responseBody)
                          : 'No response'}
                      </pre>
                    </div>
                  </div>
                )}
              </React.Fragment>
            ))}
          </div>
        )}
      </div>

      {/* JSON Viewer Modal */}
      {jsonViewerData && (
        <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50">
          <div className="bg-gray-900 border border-gray-600 rounded-lg max-w-4xl max-h-[90vh] w-[90vw] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-gray-600">
              <h3 className="text-lg font-semibold text-white">{jsonViewerData.title}</h3>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => copyToClipboard(JSON.stringify(jsonViewerData.data, null, 2))}
                  className="p-2 text-gray-400 hover:text-blue-400 transition-colors"
                  title="Copy JSON"
                >
                  <Copy size={16} />
                </button>
                <button
                  onClick={closeJsonViewer}
                  className="p-2 text-gray-400 hover:text-red-400 transition-colors"
                  title="Close"
                >
                  ✕
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-auto p-4">
              <div className="bg-gray-800 rounded p-4 font-mono text-sm">
                <JsonTree data={jsonViewerData.data} />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};