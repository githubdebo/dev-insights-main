import React, { useState, useEffect } from 'react';
import { Send, Copy, Download, RefreshCw, Plus, Trash2, ChevronDown, ChevronRight, RotateCcw, Eye, Undo2, X, Activity } from 'lucide-react';

interface NetworkRequest {
  id: string;
  method: string;
  url: string;
  status: number | string;
  statusText?: string;
  timestamp: number;
  duration?: number;
  type?: string;
  requestBody?: any;
  responseBody?: any;
  requestHeaders?: Record<string, string>;
}

interface ApiTest {
  id: string;
  url: string;
  method: string;
  headers: Record<string, string>;
  body: string;
  bodyHistory?: string[]; // Add history tracking for undo functionality
  response?: {
    status: number;
    statusText: string;
    headers: Record<string, string>;
    body: string;
    duration: number;
  };
  loading?: boolean;
}

interface ApiTesterTabProps {
  displayedCalls: NetworkRequest[];
  onRefresh?: () => void;
  importedRequest?: {
    url: string;
    method: string;
    headers: Array<{ key: string; value: string }>;
    body?: string;
    name?: string;
  } | null;
}

// Searchable Dropdown Component - moved outside to prevent re-creation
const SearchableDropdown: React.FC<{
  options: NetworkRequest[];
  filter: string;
  setFilter: (value: string) => void;
  onSelect: (call: NetworkRequest) => void;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  placeholder: string;
  borderColor: string;
  emptyMessage: string;
}> = ({ options, filter, setFilter, onSelect, isOpen, setIsOpen, placeholder, borderColor, emptyMessage }) => {
  const dropdownRef = React.useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [setIsOpen]);

  const formatCallOption = (call: NetworkRequest) => {
    const hasAuth = call.requestHeaders && 
      Object.keys(call.requestHeaders).some(key => 
        key.toLowerCase() === 'authorization' || key.toLowerCase() === 'x-api-key'
      );
    
    return `${call.method} - ${call.url.length > 80 ? `${call.url.substring(0, 80)}...` : call.url}${call.requestBody ? ' (with body)' : ''}${hasAuth ? ' 🔐' : ''}`;
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <div className="relative">
        <input
          type="text"
          value={filter}
          onChange={(e) => {
            setFilter(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          placeholder={placeholder}
          className={`w-full px-3 py-2 pr-10 bg-gray-700 border ${borderColor} rounded text-white placeholder-gray-400 focus:outline-none focus:border-opacity-100 text-sm`}
        />
        <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex items-center space-x-1">
          {filter && (
            <button
              onClick={() => {
                setFilter('');
                setIsOpen(false);
              }}
              className="text-gray-400 hover:text-white transition-colors"
              title="Clear search"
            >
              <X size={14} />
            </button>
          )}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <ChevronDown size={14} className={`transform transition-transform ${isOpen ? 'rotate-180' : ''}`} />
          </button>
        </div>
      </div>
      
      {isOpen && (
        <div className={`absolute z-50 w-full mt-1 bg-gray-700 border ${borderColor} rounded shadow-lg max-h-60 overflow-y-auto`}>
          {options.length === 0 ? (
            <div className="px-3 py-2 text-gray-400 text-sm">
              {emptyMessage}
            </div>
          ) : (
            options.map((call, index) => (
              <button
                key={index}
                onClick={() => onSelect(call)}
                className="w-full text-left px-3 py-2 text-sm text-white hover:bg-gray-600 transition-colors border-b border-gray-600 last:border-b-0"
              >
                {formatCallOption(call)}
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
};

export const ApiTesterTab: React.FC<ApiTesterTabProps> = ({ displayedCalls, onRefresh, importedRequest }) => {
  const [apiCalls, setApiCalls] = useState<NetworkRequest[]>([]);
  const [apiTests, setApiTests] = useState<ApiTest[]>([]);
  const [expandedTest, setExpandedTest] = useState<string | null>(null);
  const [jsonViewerData, setJsonViewerData] = useState<{ data: any; title: string } | null>(null);
  const [expandedKeys, setExpandedKeys] = useState<Set<string>>(new Set());
  const [apiCallsFilter, setApiCallsFilter] = useState<string>('');
  const [isApiDropdownOpen, setIsApiDropdownOpen] = useState<boolean>(false);
  const [collapsedResponseHeaders, setCollapsedResponseHeaders] = useState<Set<string>>(new Set());
  const [collapsedRequestHeaders, setCollapsedRequestHeaders] = useState<Set<string>>(new Set());

  // Toggle response headers collapse state
  const toggleResponseHeaders = (testId: string) => {
    setCollapsedResponseHeaders(prev => {
      const newSet = new Set(prev);
      if (newSet.has(testId)) {
        newSet.delete(testId);
      } else {
        newSet.add(testId);
      }
      return newSet;
    });
  };

  // Toggle request headers collapse state
  const toggleRequestHeaders = (testId: string) => {
    setCollapsedRequestHeaders(prev => {
      const newSet = new Set(prev);
      if (newSet.has(testId)) {
        newSet.delete(testId);
      } else {
        newSet.add(testId);
      }
      return newSet;
    });
  };

  // Extract and group API calls from captured network calls
  useEffect(() => {
    // Group calls with 'api' in URL
    const apiCallsFiltered = displayedCalls
      .filter(call => call.url.toLowerCase().includes('api'))
      .filter((call, index, self) => 
        self.findIndex(c => c.url === call.url && c.method === call.method) === index
      )
      .sort((a, b) => a.url.localeCompare(b.url));
    
    setApiCalls(apiCallsFiltered);
  }, [displayedCalls]);

  // Handle imported request from API Collections tab
  useEffect(() => {
    if (importedRequest) {
      const newTest: ApiTest = {
        id: Date.now().toString(),
        url: importedRequest.url,
        method: importedRequest.method,
        headers: importedRequest.headers.reduce((acc, h) => {
          acc[h.key] = h.value;
          return acc;
        }, {} as Record<string, string>),
        body: importedRequest.body || '',
        bodyHistory: [importedRequest.body || '']
      };
      
      setApiTests(prev => [newTest, ...prev]);
      setExpandedTest(newTest.id);
      setCollapsedRequestHeaders(new Set([newTest.id]));
    }
  }, [importedRequest]);

  // Filter API calls based on search text
  const filteredApiCalls = apiCalls.filter(call => 
    call.url.toLowerCase().includes(apiCallsFilter.toLowerCase()) ||
    call.method.toLowerCase().includes(apiCallsFilter.toLowerCase())
  );

  // Handle API dropdown selection
  const handleApiCallSelection = (call: NetworkRequest) => {
    createNewTestFromCall(call);
    setApiCallsFilter('');
    setIsApiDropdownOpen(false);
  };

  // Create a new API test from a captured call
  const createNewTestFromCall = (call: NetworkRequest) => {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };

    // If the captured call has request headers, include them (especially Authorization)
    if (call.requestHeaders) {
      Object.entries(call.requestHeaders).forEach(([key, value]) => {
        // Include Authorization header (Bearer token) and other important headers
        if (key.toLowerCase() === 'authorization' || 
            key.toLowerCase() === 'x-api-key' ||
            key.toLowerCase() === 'user-agent' ||
            key.toLowerCase() === 'referer' ||
            key.toLowerCase().startsWith('x-')) {
          headers[key] = value;
        }
      });
    }

    const newTest: ApiTest = {
      id: Date.now().toString(),
      url: call.url,
      method: call.method,
      headers,
      body: call.requestBody ? 
        (typeof call.requestBody === 'string' ? call.requestBody : JSON.stringify(call.requestBody, null, 2)) : 
        '',
      bodyHistory: []
    };
    // Replace the entire list with just this test
    setApiTests([newTest]);
    setExpandedTest(newTest.id);
    // Set headers to collapsed by default
    setCollapsedRequestHeaders(new Set([newTest.id]));
    setCollapsedResponseHeaders(new Set([newTest.id]));
  };

  // Create a new blank API test
  const createNewTest = () => {
    const newTest: ApiTest = {
      id: Date.now().toString(),
      url: '',
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: '',
      bodyHistory: []
    };
    // Replace the entire list with just this test
    setApiTests([newTest]);
    setExpandedTest(newTest.id);
    // Set headers to collapsed by default
    setCollapsedRequestHeaders(new Set([newTest.id]));
    setCollapsedResponseHeaders(new Set([newTest.id]));
  };

  // Update an API test
  const updateTest = (id: string, updates: Partial<ApiTest>) => {
    setApiTests(prev => prev.map(test => {
      if (test.id === id) {
        const updatedTest = { ...test, ...updates };
        
        // Track body history for undo functionality
        if (updates.body !== undefined && updates.body !== test.body) {
          const currentHistory = test.bodyHistory || [];
          // Add to history if:
          // 1. Significant change in length (more than 3 characters difference)
          // 2. Or content is fundamentally different (not just whitespace)
          // 3. Or previous body was empty and new one isn't
          const shouldTrack = 
            Math.abs(updates.body.length - test.body.length) > 3 ||
            updates.body.trim() !== test.body.trim() ||
            (test.body.trim() === '' && updates.body.trim() !== '') ||
            (test.body.trim() !== '' && updates.body.trim() === '');
            
          if (shouldTrack && currentHistory[currentHistory.length - 1] !== test.body) {
            updatedTest.bodyHistory = [...currentHistory, test.body].slice(-10); // Keep last 10 changes
          }
        }
        
        return updatedTest;
      }
      return test;
    }));
  };

  // Undo last body change
  const undoBodyChange = (id: string) => {
    setApiTests(prev => prev.map(test => {
      if (test.id === id && test.bodyHistory && test.bodyHistory.length > 0) {
        const history = [...test.bodyHistory];
        const previousBody = history.pop()!;
        return {
          ...test,
          body: previousBody,
          bodyHistory: history
        };
      }
      return test;
    }));
  };

  // Delete an API test
  // Execute an API test
  const executeTest = async (test: ApiTest) => {
    const requestId = `req_${Date.now()}_${Math.random().toString(36).substring(7)}`;
    console.log(`[${requestId}] Starting API test for:`, test.url);
    
    updateTest(test.id, { loading: true });
    const startTime = Date.now();
    
    try {
      const headers: Record<string, string> = {};
      
      // Parse headers
      Object.entries(test.headers).forEach(([key, value]) => {
        if (key.trim() && value.trim()) {
          headers[key.trim()] = value.trim();
        }
      });

      // Add cache-busting headers to prevent request caching (only if not already set by user)
      if (!headers['Cache-Control'] && !headers['cache-control']) {
        headers['Cache-Control'] = 'no-cache, no-store, must-revalidate';
      }
      if (!headers['Pragma'] && !headers['pragma']) {
        headers['Pragma'] = 'no-cache';
      }
      if (!headers['Expires'] && !headers['expires']) {
        headers['Expires'] = '0';
      }
      
      // Add additional cache-busting headers
      if (!headers['If-Modified-Since'] && !headers['if-modified-since']) {
        headers['If-Modified-Since'] = '0';
      }
      if (!headers['If-None-Match'] && !headers['if-none-match']) {
        headers['If-None-Match'] = '*';
      }

      const requestOptions: RequestInit = {
        method: test.method,
        headers,
        mode: 'cors',
        cache: 'no-cache',
        credentials: 'include', // Include credentials to handle auth cookies
        redirect: 'follow'
      };

      // Add body for non-GET requests
      if (test.method !== 'GET' && test.body.trim()) {
        requestOptions.body = test.body;
      }

      // Add cache-busting timestamp to URL to ensure fresh requests
      let finalUrl: string;
      try {
        const url = new URL(test.url);
        url.searchParams.set('_t', Date.now().toString());
        url.searchParams.set('_r', Math.random().toString(36).substring(7));
        finalUrl = url.toString();
      } catch (error) {
        // If URL construction fails, append query parameters manually
        const separator = test.url.includes('?') ? '&' : '?';
        finalUrl = `${test.url}${separator}_t=${Date.now()}&_r=${Math.random().toString(36).substring(7)}`;
      }

      console.log(`[${requestId}] Making API request to:`, finalUrl);
      console.log(`[${requestId}] Request options:`, { ...requestOptions, headers: { ...headers } });

      // Create a timeout promise
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('Request timeout after 30 seconds')), 30000);
      });

      // Race between fetch and timeout
      const response = await Promise.race([
        fetch(finalUrl, requestOptions),
        timeoutPromise
      ]) as Response;
      
      const duration = Date.now() - startTime;
      
      console.log(`[${requestId}] Response received:`, {
        status: response.status,
        statusText: response.statusText,
        headers: Object.fromEntries([...response.headers.entries()]),
        url: response.url,
        duration: `${duration}ms`,
        ok: response.ok,
        redirected: response.redirected,
        type: response.type
      });
      
      // Get response headers
      const responseHeaders: Record<string, string> = {};
      response.headers.forEach((value, key) => {
        responseHeaders[key] = value;
      });

      // Clone response for reading body (since response can only be read once)
      const responseClone = response.clone();

      // Get response body with better error handling
      const contentType = response.headers.get('content-type') || '';
      let responseBody: string;
      
      try {
        if (contentType.includes('application/json')) {
          try {
            const jsonData = await responseClone.json();
            responseBody = JSON.stringify(jsonData, null, 2);
          } catch (jsonError) {
            console.warn(`[${requestId}] Failed to parse JSON response, falling back to text:`, jsonError);
            responseBody = await response.clone().text();
          }
        } else {
          responseBody = await responseClone.text();
        }
      } catch (bodyError) {
        console.warn(`[${requestId}] Failed to read response body:`, bodyError);
        responseBody = `Error reading response body: ${bodyError instanceof Error ? bodyError.message : 'Unknown error'}`;
      }

      // Check if response was successful
      if (!response.ok) {
        console.warn(`[${requestId}] API request failed with status ${response.status}: ${response.statusText}`);
      }

      updateTest(test.id, {
        loading: false,
        response: {
          status: response.status,
          statusText: response.statusText || `HTTP ${response.status}`,
          headers: responseHeaders,
          body: responseBody,
          duration
        }
      });

      console.log(`[${requestId}] API test completed successfully`);

    } catch (error) {
      const duration = Date.now() - startTime;
      console.error(`[${requestId}] API test failed:`, error);
      
      let errorMessage = 'Unknown error';
      let errorDetails = '';
      
      if (error instanceof TypeError && error.message.includes('Failed to fetch')) {
        errorMessage = 'Network Error - CORS or connectivity issue';
        errorDetails = 'This could be due to:\n' +
                      '• CORS policy blocking the request\n' +
                      '• Network connectivity issues\n' +
                      '• Invalid URL or server not responding\n' +
                      '• Firewall or security software blocking the request';
      } else if (error instanceof TypeError) {
        errorMessage = `Type Error: ${error.message}`;
      } else if (error instanceof Error && error.message.includes('timeout')) {
        errorMessage = 'Request Timeout';
        errorDetails = 'The request took longer than 30 seconds to complete';
      } else {
        errorMessage = error instanceof Error ? error.message : String(error);
      }

      updateTest(test.id, {
        loading: false,
        response: {
          status: 0,
          statusText: errorMessage,
          headers: {},
          body: errorDetails ? `${errorMessage}\n\n${errorDetails}` : errorMessage,
          duration
        }
      });
    }
  };

  // Copy response to clipboard - optimized for DevTools context
  const copyToClipboard = async (text: string) => {
    // Create a larger, more visible textarea with the content
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.top = '50%';
    textarea.style.left = '50%';
    textarea.style.transform = 'translate(-50%, -50%)';
    textarea.style.width = '80vw';
    textarea.style.height = '70vh';
    textarea.style.maxWidth = '800px';
    textarea.style.maxHeight = '600px';
    textarea.style.minWidth = '500px';
    textarea.style.minHeight = '400px';
    textarea.style.zIndex = '10000';
    textarea.style.background = '#1f2937';
    textarea.style.color = '#e5e7eb';
    textarea.style.border = '2px solid #60a5fa';
    textarea.style.borderRadius = '8px';
    textarea.style.padding = '16px';
    textarea.style.fontSize = '14px';
    textarea.style.fontFamily = 'Consolas, Monaco, "Courier New", monospace';
    textarea.style.boxShadow = '0 20px 50px rgba(0, 0, 0, 0.8)';
    textarea.readOnly = true;
    textarea.style.resize = 'both';
    textarea.style.overflow = 'auto';
    
    // Create overlay background
    const overlay = document.createElement('div');
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.background = 'rgba(0, 0, 0, 0.8)';
    overlay.style.zIndex = '9999';
    
    document.body.appendChild(overlay);
    document.body.appendChild(textarea);
    textarea.focus();
    textarea.select();
    
    // Try to copy automatically
    try {
      document.execCommand('copy');
    } catch {
      // Silent failure - user can copy manually
    }
    
    // Remove elements when user clicks outside or presses escape
    const cleanup = () => {
      if (document.body.contains(textarea)) {
        document.body.removeChild(textarea);
      }
      if (document.body.contains(overlay)) {
        document.body.removeChild(overlay);
      }
      document.removeEventListener('click', cleanup);
      document.removeEventListener('keydown', escapeHandler);
    };
    
    const escapeHandler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        cleanup();
      }
    };
    
    // Close when clicking on overlay (but not textarea)
    overlay.addEventListener('click', cleanup);
    
    // Prevent clicks on the textarea from closing the modal
    textarea.addEventListener('click', (e) => {
      e.stopPropagation();
    });
    
    // Add keyboard listener
    document.addEventListener('keydown', escapeHandler);
  };

  // Format JSON data for display
  const formatJsonData = (data: any): string => {
    if (!data) return '';
    if (typeof data === 'string') {
      try {
        // Try to parse and reformat if it's a JSON string
        const parsed = JSON.parse(data);
        return JSON.stringify(parsed, null, 2);
      } catch {
        // If not JSON, return as-is
        return data;
      }
    }
    return JSON.stringify(data, null, 2);
  };

  // Export test results
  const exportResults = () => {
    const dataStr = JSON.stringify(apiTests, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `api-tests-${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const getStatusColor = (status: number) => {
    if (status >= 200 && status < 300) return 'text-green-400';
    if (status >= 300 && status < 400) return 'text-yellow-400';
    if (status >= 400) return 'text-red-400';
    return 'text-gray-400';
  };

  // JSON viewer functionality
  const openJsonViewer = (data: any, title: string) => {
    setJsonViewerData({ data, title });
    setExpandedKeys(new Set()); // Reset expanded state when opening new viewer
  };

  const closeJsonViewer = () => {
    setJsonViewerData(null);
    setExpandedKeys(new Set()); // Reset expanded state when closing
  };

  // JSON Tree Component for hierarchical display
  const JsonTree = ({ data, level = 0 }: { data: any; level?: number }) => {
    const toggleExpanded = (key: string) => {
      const newExpanded = new Set(expandedKeys);
      if (newExpanded.has(key)) {
        newExpanded.delete(key);
      } else {
        newExpanded.add(key);
      }
      setExpandedKeys(newExpanded);
    };

    const renderValue = (value: any, key: string, path: string) => {
      const isExpanded = expandedKeys.has(path);
      const indent = level * 20;

      // Handle primitive values - show key: value
      if (value === null) {
        return (
          <div className="flex items-center" style={{ paddingLeft: `${indent}px` }}>
            <span className="text-blue-300">{key}:</span>
            <span className="text-gray-500 ml-2">null</span>
          </div>
        );
      }
      
      if (value === undefined) {
        return (
          <div className="flex items-center" style={{ paddingLeft: `${indent}px` }}>
            <span className="text-blue-300">{key}:</span>
            <span className="text-gray-500 ml-2">undefined</span>
          </div>
        );
      }
      
      if (typeof value === 'boolean') {
        return (
          <div className="flex items-center" style={{ paddingLeft: `${indent}px` }}>
            <span className="text-blue-300">{key}:</span>
            <span className="text-purple-400 ml-2">{value.toString()}</span>
          </div>
        );
      }
      
      if (typeof value === 'number') {
        return (
          <div className="flex items-center" style={{ paddingLeft: `${indent}px` }}>
            <span className="text-blue-300">{key}:</span>
            <span className="text-green-400 ml-2">{value}</span>
          </div>
        );
      }
      
      if (typeof value === 'string') {
        return (
          <div className="flex items-center" style={{ paddingLeft: `${indent}px` }}>
            <span className="text-blue-300">{key}:</span>
            <span className="text-yellow-400 ml-2">"{value}"</span>
          </div>
        );
      }

      if (Array.isArray(value)) {
        return (
          <div>
            <div 
              className="flex items-center cursor-pointer hover:bg-gray-700 p-1 rounded"
              onClick={() => toggleExpanded(path)}
              style={{ paddingLeft: `${indent}px` }}
            >
              {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
              <span className="text-blue-300 ml-1">{key}: Array[{value.length}]</span>
            </div>
            {isExpanded && (
              <div>
                {value.map((item, index) => (
                  <div key={index} style={{ paddingLeft: `${indent + 20}px` }}>
                    <JsonTree data={{ [`[${index}]`]: item }} level={level + 1} />
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      }

      if (typeof value === 'object') {
        const keys = Object.keys(value);
        return (
          <div>
            <div 
              className="flex items-center cursor-pointer hover:bg-gray-700 p-1 rounded"
              onClick={() => toggleExpanded(path)}
              style={{ paddingLeft: `${indent}px` }}
            >
              {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
              <span className="text-blue-300 ml-1">{key}: Object{`{${keys.length}}`}</span>
            </div>
            {isExpanded && (
              <div>
                {keys.map(objKey => (
                  <div key={objKey} style={{ paddingLeft: `${indent + 20}px` }}>
                    <JsonTree data={{ [objKey]: value[objKey] }} level={level + 1} />
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      }

      return (
        <div className="flex items-center" style={{ paddingLeft: `${indent}px` }}>
          <span className="text-blue-300">{key}:</span>
          <span className="text-gray-300 ml-2">{String(value)}</span>
        </div>
      );
    };

    if (typeof data === 'object' && data !== null) {
      return (
        <div>
          {Object.entries(data).map(([key, value]) => (
            <div key={key} className="mb-1">
              {renderValue(value, key, `${level}-${key}`)}
            </div>
          ))}
        </div>
      );
    }

    return <div className="text-gray-300">{JSON.stringify(data, null, 2)}</div>;
  };

  return (
    <div className="h-full flex flex-col">
      {/* Captured API Calls Groups */}
      <div className="p-4 bg-gray-800 border-b border-gray-700">
        <div className="flex items-center justify-between gap-4">
          {/* Dropdown Section */}
          <div className="flex-1">
            {apiCalls.length > 0 && (
              <SearchableDropdown
                options={filteredApiCalls}
                filter={apiCallsFilter}
                setFilter={setApiCallsFilter}
                onSelect={handleApiCallSelection}
                isOpen={isApiDropdownOpen}
                setIsOpen={setIsApiDropdownOpen}
                placeholder="Search and select an API call to test..."
                borderColor="border-green-500/30 focus:border-green-500"
                emptyMessage="No matching API calls found. Try adjusting your search."
              />
            )}
          </div>
          
          {/* API Calls Notification Badge */}
          {apiCalls.length > 0 && (
            <div className="relative flex-shrink-0">
              <Activity size={20} className="text-blue-400" />
              <span className="absolute -top-0.5 -right-2 bg-blue-500 text-white text-[10px] rounded-full min-w-[14px] h-[14px] flex items-center justify-center font-bold leading-none">
                {apiCalls.length}
              </span>
            </div>
          )}
          
          {/* Action Buttons */}
          <div className="flex space-x-2 flex-shrink-0">
            {onRefresh && (
              <button
                onClick={onRefresh}
                className="p-2 bg-gray-600 hover:bg-gray-700 text-white rounded transition-colors"
                title="Refresh captured API calls"
              >
                <RotateCcw size={16} />
              </button>
            )}
            <button
              onClick={() => createNewTest()}
              className="p-2 bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors"
              title="Create new API test"
            >
              <Plus size={16} />
            </button>
            <button
              onClick={exportResults}
              className="p-2 bg-green-600 hover:bg-green-700 text-white rounded transition-colors"
              title="Export test results"
            >
              <Download size={16} />
            </button>
          </div>
        </div>
      </div>

      {/* Test List */}
      <div className="flex-1 overflow-y-auto">
        {apiTests.length === 0 ? (
          <div className="flex items-center justify-center h-full text-gray-400">
            <div className="text-center">
              <Send size={48} className="mx-auto mb-4 opacity-50" />
              <p>No API tests created yet</p>
              <p className="text-sm mt-1">Create a test to start testing API endpoints</p>
            </div>
          </div>
        ) : (
          <div className="divide-y divide-gray-700">
            {apiTests.map((test) => (
              <div 
                key={test.id} 
                className={`p-4 ${expandedTest === test.id ? 'bg-gray-800 border-l-4 border-blue-500' : ''}`}
              >
                {/* Test Header */}
                <div className="flex items-center justify-between mb-3">
                  <button
                    onClick={() => {
                      // Ensure only one test is expanded at a time
                      if (expandedTest === test.id) {
                        setExpandedTest(null); // Collapse current test
                      } else {
                        setExpandedTest(test.id); // Expand this test (automatically collapses others)
                      }
                    }}
                    className="flex items-start space-x-2 text-left flex-1 min-w-0"
                  >
                    <div className="flex-shrink-0 mt-0.5">
                      {expandedTest === test.id ? (
                        <ChevronDown size={16} className="text-gray-400" />
                      ) : (
                        <ChevronRight size={16} className="text-gray-400" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2 mb-1">
                        <span className="font-mono text-sm font-semibold text-blue-400 flex-shrink-0">
                          {test.method}
                        </span>
                        {test.response && (
                          <span className={`font-mono text-sm flex-shrink-0 ${getStatusColor(test.response.status)}`}>
                            {test.response.status}
                          </span>
                        )}
                      </div>
                      <div className="text-sm text-gray-300 break-all">
                        {test.url || 'No URL set'}
                      </div>
                    </div>
                  </button>
                  <div className="flex items-center space-x-2 flex-shrink-0 ml-2">
                    <button
                      onClick={() => executeTest(test)}
                      disabled={test.loading || !test.url}
                      className="p-2 bg-green-600 hover:bg-green-700 disabled:opacity-50 text-white rounded transition-colors"
                      title={test.loading ? "Sending request..." : "Send API request"}
                    >
                      {test.loading ? (
                        <RefreshCw size={16} className="animate-spin" />
                      ) : (
                        <Send size={16} />
                      )}
                    </button>
                  </div>
                </div>

                {/* Expanded Test Details */}
                {expandedTest === test.id && (
                  <div className="space-y-4 bg-gray-900 p-4 rounded border border-gray-700">
                    {/* URL and Method */}
                    <div className="grid grid-cols-4 gap-3">
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1">
                          Method
                        </label>
                        <select
                          value={test.method}
                          onChange={(e) => updateTest(test.id, { method: e.target.value })}
                          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:border-blue-500"
                        >
                          <option value="GET">GET</option>
                          <option value="POST">POST</option>
                          <option value="PUT">PUT</option>
                          <option value="PATCH">PATCH</option>
                          <option value="DELETE">DELETE</option>
                        </select>
                      </div>
                      <div className="col-span-3">
                        <label className="block text-sm font-medium text-gray-300 mb-1">
                          URL
                        </label>
                        <input
                          type="text"
                          value={test.url}
                          onChange={(e) => updateTest(test.id, { url: e.target.value })}
                          placeholder="Enter API endpoint URL..."
                          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                        />
                      </div>
                    </div>

                    {/* Headers */}
                    <div className="bg-gray-400 border border-gray-500 rounded p-3">
                      <div className="flex items-center justify-between mb-2">
                        <button
                          onClick={() => toggleRequestHeaders(test.id)}
                          className="flex items-center gap-1 font-semibold text-gray-800 bg-emerald-100 px-2 py-1 rounded text-xs hover:bg-emerald-200 transition-colors"
                        >
                          {collapsedRequestHeaders.has(test.id) ? (
                            <ChevronRight size={14} />
                          ) : (
                            <ChevronDown size={14} />
                          )}
                          Request Headers
                        </button>
                      </div>
                      {!collapsedRequestHeaders.has(test.id) && (
                        <div className="space-y-2">
                          {Object.entries(test.headers).map(([key, value], index) => (
                            <div key={index} className="grid grid-cols-2 gap-2">
                              <input
                                type="text"
                                value={key}
                                onChange={(e) => {
                                  const newHeaders = { ...test.headers };
                                  delete newHeaders[key];
                                  newHeaders[e.target.value] = value;
                                  updateTest(test.id, { headers: newHeaders });
                                }}
                                placeholder="Header name"
                                className="px-3 py-2 bg-gray-200 border border-gray-300 rounded text-gray-800 placeholder-gray-500 focus:outline-none focus:border-blue-500"
                              />
                              <div className="flex space-x-2">
                                <input
                                  type="text"
                                  value={value}
                                  onChange={(e) => {
                                    const newHeaders = { ...test.headers };
                                    newHeaders[key] = e.target.value;
                                    updateTest(test.id, { headers: newHeaders });
                                  }}
                                  placeholder="Header value"
                                  className="flex-1 px-3 py-2 bg-gray-200 border border-gray-300 rounded text-gray-800 placeholder-gray-500 focus:outline-none focus:border-blue-500"
                                />
                                <button
                                  onClick={() => {
                                    const newHeaders = { ...test.headers };
                                    delete newHeaders[key];
                                    updateTest(test.id, { headers: newHeaders });
                                  }}
                                  className="p-2 text-red-600 hover:text-red-500 transition-colors"
                                >
                                  <Trash2 size={14} />
                                </button>
                              </div>
                            </div>
                          ))}
                          <button
                            onClick={() => {
                              const newHeaders = { ...test.headers, '': '' };
                              updateTest(test.id, { headers: newHeaders });
                            }}
                            className="p-2 bg-gray-300 hover:bg-gray-200 text-gray-800 rounded transition-colors"
                            title="Add new header"
                          >
                            <Plus size={14} />
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Request Body */}
                    {test.method !== 'GET' && (
                      <div className="bg-gray-400 border border-gray-500 rounded p-3 shadow-lg">
                        <div className="flex items-center justify-between mb-2">
                          <div className="font-semibold text-gray-800 bg-blue-100 px-2 py-1 rounded text-xs">
                            Request Body
                            {test.bodyHistory && test.bodyHistory.length > 0 && (
                              <span className="text-xs text-gray-600 ml-2">
                                ({test.bodyHistory.length} change{test.bodyHistory.length !== 1 ? 's' : ''} available to undo)
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-1">
                            {test.bodyHistory && test.bodyHistory.length > 0 && (
                              <button
                                onClick={() => undoBodyChange(test.id)}
                                className="p-1 text-gray-700 hover:text-orange-600 transition-colors"
                                title={`Undo last change (Ctrl+Z) - ${test.bodyHistory.length} change${test.bodyHistory.length !== 1 ? 's' : ''} available`}
                              >
                                <Undo2 size={12} />
                              </button>
                            )}
                            <button
                              onClick={() => {
                                try {
                                  const parsedData = JSON.parse(test.body);
                                  openJsonViewer(parsedData, 'Request Body');
                                } catch {
                                  openJsonViewer(test.body, 'Request Body');
                                }
                              }}
                              className="p-1 text-gray-700 hover:text-emerald-600 transition-colors"
                              title="View JSON hierarchy"
                            >
                              <Eye size={12} />
                            </button>
                            <button
                              onClick={() => copyToClipboard(formatJsonData(test.body))}
                              className="p-1 text-gray-700 hover:text-blue-600 transition-colors"
                              title="Copy request body"
                            >
                              <Copy size={12} />
                            </button>
                          </div>
                        </div>
                        <textarea
                          value={test.body}
                          onChange={(e) => updateTest(test.id, { body: e.target.value })}
                          onKeyDown={(e) => {
                            // Ctrl+Z for undo
                            if (e.ctrlKey && e.key === 'z' && test.bodyHistory && test.bodyHistory.length > 0) {
                              e.preventDefault();
                              undoBodyChange(test.id);
                            }
                          }}
                          placeholder="Enter request body (JSON, form data, etc.)"
                          rows={4}
                          className="w-full px-3 py-2 bg-gray-200 border border-gray-300 rounded text-gray-800 placeholder-gray-500 focus:outline-none focus:border-blue-500 font-mono text-sm shadow-sm"
                        />
                      </div>
                    )}

                    {/* Response */}
                    {test.response && (
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <label className="block text-sm font-medium text-gray-300">
                            Response
                          </label>
                          <div className="flex items-center space-x-2">
                            <span className={`font-mono text-sm ${getStatusColor(test.response.status)}`}>
                              {test.response.status} {test.response.statusText}
                            </span>
                            <span className="text-xs text-gray-400">
                              {test.response.duration}ms
                            </span>
                          </div>
                        </div>
                        <div className="bg-gray-400 border border-gray-500 rounded shadow-lg">
                          {/* Response Headers */}
                          <div className="p-3 bg-gray-400 border-b border-gray-500">
                            <div className="flex items-center justify-between mb-1">
                              <button
                                onClick={() => toggleResponseHeaders(test.id)}
                                className="flex items-center gap-1 font-semibold text-gray-800 bg-emerald-100 px-2 py-1 rounded text-xs hover:bg-emerald-200 transition-colors"
                              >
                                {collapsedResponseHeaders.has(test.id) ? (
                                  <ChevronRight size={12} />
                                ) : (
                                  <ChevronDown size={12} />
                                )}
                                Response Headers
                              </button>
                              <div className="flex items-center gap-1">
                                <button
                                  onClick={() => openJsonViewer(test.response!.headers, 'Response Headers')}
                                  className="p-1 text-gray-700 hover:text-green-600 transition-colors"
                                  title="View headers hierarchy"
                                >
                                  <Eye size={12} />
                                </button>
                                <button
                                  onClick={() => copyToClipboard(Object.entries(test.response!.headers).map(([key, value]) => `${key}: ${value}`).join('\n'))}
                                  className="p-1 text-gray-700 hover:text-blue-600 transition-colors"
                                  title="Copy headers"
                                >
                                  <Copy size={12} />
                                </button>
                              </div>
                            </div>
                            {!collapsedResponseHeaders.has(test.id) && (
                              <pre className="text-xs text-gray-800 whitespace-pre-wrap bg-gray-200 border border-gray-300 p-2 rounded-md font-mono">
                                {Object.entries(test.response.headers).map(([key, value]) => `${key}: ${value}`).join('\n')}
                              </pre>
                            )}
                          </div>
                          
                          {/* Response Body */}
                          <div className="p-3 bg-gray-400">
                            <div className="flex items-center justify-between mb-2">
                              <div className="font-semibold text-gray-800 bg-amber-100 px-2 py-1 rounded text-xs">Response Body:</div>
                              <div className="flex items-center gap-1">
                                <button
                                  onClick={() => {
                                    try {
                                      const parsedData = typeof test.response!.body === 'string' 
                                        ? JSON.parse(test.response!.body) 
                                        : test.response!.body;
                                      openJsonViewer(parsedData, 'Response Body');
                                    } catch {
                                      openJsonViewer(test.response!.body, 'Response Body');
                                    }
                                  }}
                                  className="p-1 text-gray-700 hover:text-emerald-600 transition-colors"
                                  title="View JSON hierarchy"
                                >
                                  <Eye size={12} />
                                </button>
                                <button
                                  onClick={() => copyToClipboard(formatJsonData(test.response!.body))}
                                  className="p-1 text-gray-700 hover:text-blue-600 transition-colors"
                                  title="Copy response body"
                                >
                                  <Copy size={12} />
                                </button>
                              </div>
                            </div>
                            <pre className="bg-gray-200 border border-gray-300 p-3 rounded-md text-gray-800 whitespace-pre-wrap break-all max-h-40 overflow-auto text-xs shadow-sm font-mono">
                              {formatJsonData(test.response.body)}
                            </pre>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* JSON Viewer Modal */}
        {jsonViewerData && (
          <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50">
            <div className="bg-gray-900 border border-gray-600 rounded-lg max-w-4xl max-h-[90vh] w-[90vw] flex flex-col">
              <div className="flex items-center justify-between p-4 border-b border-gray-600">
                <h3 className="text-lg font-semibold text-white">{jsonViewerData.title}</h3>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => copyToClipboard(JSON.stringify(jsonViewerData.data, null, 2))}
                    className="p-2 text-gray-400 hover:text-blue-400 transition-colors"
                    title="Copy JSON"
                  >
                    <Copy size={16} />
                  </button>
                  <button
                    onClick={closeJsonViewer}
                    className="p-2 text-gray-400 hover:text-red-400 transition-colors"
                    title="Close"
                  >
                    ✕
                  </button>
                </div>
              </div>
              <div className="flex-1 overflow-auto p-4">
                <div className="bg-gray-800 rounded p-4 font-mono text-sm">
                  <JsonTree data={jsonViewerData.data} />
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
