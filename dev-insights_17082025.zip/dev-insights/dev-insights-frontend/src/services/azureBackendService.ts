class AzureBackendService {
  private backendUrl: string;

  constructor() {
    // Temporarily hardcode for debugging
    this.backendUrl = 'http://localhost:3001';
    
    console.log('[Azure Backend] Environment PROD:', import.meta.env.PROD);
    console.log('[Azure Backend] Configured backend URL:', this.backendUrl);
  }

  // Azure AD Token Request via Backend
  async getAzureToken(config: {
    clientId: string;
    clientSecret: string;
    tenantId: string;
    scope?: string;
    grantType?: string;
    resource?: string;
  }) {
    try {
      const requestUrl = `${this.backendUrl}/api/azure/token`;
      console.log('[Azure Backend] Making request to:', requestUrl);
      console.log('[Azure Backend] Backend URL:', this.backendUrl);
      
      const response = await fetch(requestUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          clientId: config.clientId,
          clientSecret: config.clientSecret,
          tenantId: config.tenantId,
          scope: config.scope || 'https://graph.microsoft.com/.default',
          grantType: config.grantType || 'client_credentials',
          resource: config.resource
        })
      });
      
      console.log('[Azure Backend] Response status:', response.status);
      console.log('[Azure Backend] Response headers:', Object.fromEntries(response.headers));

      // Check if the response is actually JSON
      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        throw new Error(`Backend server returned ${contentType || 'non-JSON'} response instead of JSON. Backend may not be running.`);
      }

      const data = await response.json();
      
      // Return the response in the same format as direct Azure AD
      if (data.success) {
        return {
          success: true,
          access_token: data.access_token,
          token_type: data.token_type,
          expires_in: data.expires_in,
          ext_expires_in: data.ext_expires_in,
          scope: data.scope,
          resource: data.resource,
          timestamp: data.timestamp,
          duration: data.duration,
          // Keep all original Azure AD fields
          ...data
        };
      } else {
        return {
          success: false,
          error: data.error,
          error_description: data.error,
          error_codes: data.details?.error_codes,
          timestamp: data.timestamp,
          duration: data.duration,
          correlation_id: data.details?.correlation_id,
          trace_id: data.details?.trace_id
        };
      }

    } catch (error) {
      console.error('Backend Azure request error:', error);
      
      // Provide more specific error messages
      let errorMessage = 'Unknown error';
      if (error instanceof TypeError && error.message.includes('fetch')) {
        errorMessage = 'Cannot connect to backend server. Backend may not be running.';
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }
      
      return {
        success: false,
        error: 'Failed to connect to backend server',
        error_description: errorMessage,
        timestamp: new Date().toISOString()
      };
    }
  }

  // Execute Postman Collection Request via Backend
  async executePostmanRequest(postmanRequest: any) {
    try {
      const response = await fetch(`${this.backendUrl}/api/postman/execute`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          request: postmanRequest
        })
      });

      const data = await response.json();
      return data;

    } catch (error) {
      console.error('Postman request error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        timestamp: new Date().toISOString()
      };
    }
  }

  // Generic Azure API Request via Backend
  async makeAzureApiRequest(config: {
    url: string;
    method?: string;
    headers?: Record<string, string>;
    data?: any;
    params?: Record<string, string>;
  }) {
    try {
      const response = await fetch(`${this.backendUrl}/api/azure/request`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(config)
      });

      const data = await response.json();
      return data;

    } catch (error) {
      console.error('Azure API request error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        timestamp: new Date().toISOString()
      };
    }
  }

  // Health check
  async checkBackendHealth() {
    try {
      const response = await fetch(`${this.backendUrl}/api/health`);
      const data = await response.json();
      return data;
    } catch (error) {
      return {
        status: 'error',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  // Check if a URL is an Azure AD token endpoint
  isAzureTokenEndpoint(url: string): boolean {
    const azureDomains = [
      'login.microsoftonline.com',
      'login.windows.net',
      'login.live.com'
    ];
    
    return azureDomains.some(domain => url.includes(domain)) && 
           url.includes('/oauth2/') && 
           url.includes('/token');
  }

  // Extract Azure AD configuration from a Postman request
  extractAzureConfigFromPostman(postmanRequest: any): {
    clientId: string;
    clientSecret: string;
    tenantId: string;
    scope?: string;
    grantType?: string;
  } | null {
    try {
      // Extract tenant ID from URL
      const url = typeof postmanRequest.url === 'string' 
        ? postmanRequest.url 
        : this.buildPostmanUrl(postmanRequest.url);
      
      const tenantMatch = url.match(/\/([a-f0-9-]{36})\//);
      if (!tenantMatch) return null;
      
      const tenantId = tenantMatch[1];
      
      // Extract form data
      const formData = postmanRequest.body?.formdata || [];
      const config: any = { tenantId };
      
      formData.forEach((field: any) => {
        if (field.type === 'text' && !field.disabled) {
          switch (field.key) {
            case 'client_id':
              config.clientId = field.value;
              break;
            case 'client_secret':
              config.clientSecret = field.value;
              break;
            case 'scope':
              config.scope = field.value;
              break;
            case 'grant_type':
              config.grantType = field.value;
              break;
          }
        }
      });
      
      return config.clientId && config.clientSecret ? config : null;
    } catch (error) {
      console.error('Failed to extract Azure config:', error);
      return null;
    }
  }

  private buildPostmanUrl(urlObj: any): string {
    if (typeof urlObj === 'string') return urlObj;
    
    const protocol = urlObj.protocol || 'https';
    const host = Array.isArray(urlObj.host) ? urlObj.host.join('.') : urlObj.host;
    const path = Array.isArray(urlObj.path) ? urlObj.path.join('/') : (urlObj.path || '');
    
    let url = `${protocol}://${host}`;
    if (path && !path.startsWith('/')) {
      url += '/';
    }
    url += path;
    
    return url;
  }
}

export default new AzureBackendService();
