# Journey Tab Export and Performance Tracking Features

## Ove#### Color-coded Types**: 
  - Blue: Navigation
  - Green: Clicks
  - Orange: Focus
  - Gra### Usage Instructions

### Exporting Journey Data
1. Navigate to the Journey Tab in Developer Insights
2. Interact with the webpage to generate journey steps (navigation and clicks)
3. Click "Export JSON" for detailed data analysis
4. Click "Export CSV" for spreadsheet analysis
5. Files are automatically downloaded with timestamp

Note: Input events (text entry, form filling) and focus events (field focusing) are automatically filtered out to focus on navigation flow and key interactions.

## Overview
The Journey Tab has been enhanced with comprehensive export functionality and detailed performance tracking to provide insights into user interactions and loading times.

## New Features

### 1. **Export Functionality**

#### JSON Export
- **Button**: "Export JSON"
- **Output**: Comprehensive journey data in JSON format
- **Includes**:
  - Export metadata (timestamp, tab URL, total steps, duration)
  - Detailed step information with timestamps
  - Element details for each interaction
  - Performance metrics (load times, content sizes)
  - Relative timing between steps

#### CSV Export
- **Button**: "Export CSV"
- **Output**: Spreadsheet-friendly format
- **Columns**:
  - Step number
  - ISO timestamp
  - Action type (url, click, input, focus)
  - Action description
  - Load time (ms)
  - DOM load time (ms)
  - Full load time (ms)
  - Content size (bytes)
  - Time since previous step (ms)

### 2. **Enhanced Performance Tracking**

#### Page Navigation Timing
- **Load Time**: Time for load event completion
- **DOM Load Time**: DOM content loaded duration
- **Full Load Time**: Complete page load from fetch start
- **Content Size**: Total size of resources loaded

#### Click Performance Tracking
- Tracks loading time for clicks that trigger navigation or content changes
- Identifies clicks that cause performance impact (>100ms)
- Records separate performance events for significant load operations

#### Detailed Element Information
- Element tag and type
- Associated text content
- Links and navigation URLs
- Interactive element properties
- Navigation triggers
- **Page context** (URL and title where interaction occurred)

#### Page Context Tracking
- **Page URL**: Captures the exact URL where each interaction occurred
- **Page Title**: Records the page title for better context
- **Cross-page Analysis**: Enables tracking user journeys across multiple pages
- **Multi-tab Support**: Distinguishes interactions on different pages/tabs

### 3. **Enhanced User Interface**

#### Improved Step Display
- **Card-based Layout**: Each step shown in a dedicated card
- **Color-coded Types**: 
  - Blue: Navigation
  - Green: Clicks
  - Gray: Other types
- **Performance Indicators**: Load times displayed prominently
- **Event Filtering**: Input and focus events are filtered out to focus on navigation and key interaction flows
- **Expandable Details**: Element details and full URLs in collapsible sections

#### Journey Summary
- Total step count
- Total journey duration
- Average time between steps
- Quick performance overview

#### Better Empty States
- Clear explanations when no data is available
- Indicators for refresh-related data clearing
- Helpful instructions for data collection

### 4. **Technical Implementation**

#### Enhanced Data Structure
```typescript
interface JourneyStep {
  type: 'url' | 'click' | 'input' | 'focus'; // Note: input and focus events are filtered out
  value: string;
  timestamp: number;
  element?: string; // JSON string containing element details
  loadTime?: number; // Time taken to load content after interaction
  domLoadTime?: number; // DOM content loaded time
  fullLoadTime?: number; // Complete page load time
  size?: number; // Content size if available
  description?: string; // Full description of the action
  pageUrl?: string; // URL of the page where the interaction occurred
  pageTitle?: string; // Title of the page where the interaction occurred
}
```

#### Performance Measurement
- Uses Navigation Timing API for accurate measurements
- Tracks resource loading times and sizes
- Monitors click-to-load performance
- Handles async operations and timeouts

#### Export Format Examples

**JSON Export Sample**:
```json
{
  "exportedAt": "2025-07-16T10:30:00.000Z",
  "tabUrl": "https://example.com",
  "totalSteps": 5,
  "totalDuration": 15420,
  "journey": [
    {
      "stepNumber": 1,
      "timestamp": "2025-07-16T10:29:45.580Z",
      "relativeTime": 0,
      "type": "url",
      "action": "Navigated to: https://example.com",
      "pageUrl": "https://example.com",
      "pageTitle": "Example Homepage",
      "loadTime": 850,
      "domLoadTime": 120,
      "fullLoadTime": 1200,
      "contentSize": 256000
    },
    {
      "stepNumber": 2,
      "timestamp": "2025-07-16T10:29:47.200Z",
      "relativeTime": 1620,
      "type": "click",
      "action": "Clicked button: Submit",
      "pageUrl": "https://example.com/form",
      "pageTitle": "Contact Form - Example",
      "loadTime": 320,
      "timeSincePreviousStep": 1620
    }
  ]
}
```

**CSV Export Sample**:
```csv
Step,Timestamp,Type,Action,Page URL,Page Title,Load Time (ms),DOM Load Time (ms),Full Load Time (ms),Content Size (bytes),Time Since Previous (ms)
1,2025-07-16T10:29:45.580Z,url,"Navigated to: https://example.com","https://example.com","Example Homepage",850,120,1200,256000,0
2,2025-07-16T10:29:47.200Z,click,"Clicked button: ""Submit""","https://example.com/form","Contact Form - Example",320,,,24000,1620
```

## Usage Instructions

### Exporting Journey Data
1. Navigate to the Journey Tab in Developer Insights
2. Interact with the webpage to generate journey steps
3. Click "Export JSON" for detailed data analysis
4. Click "Export CSV" for spreadsheet analysis
5. Files are automatically downloaded with timestamp

### Understanding Performance Data
- **Load Time**: How long content took to load after interaction
- **DOM Load Time**: Time for HTML parsing and DOM construction
- **Full Load Time**: Complete loading including all resources
- **Content Size**: Total bytes transferred
- **Time Since Previous**: Delay between user actions

### Best Practices
- Export data regularly for historical analysis
- Compare load times across different user flows
- Use CSV format for trend analysis in spreadsheets
- Use JSON format for detailed programmatic analysis
- Monitor performance impact of user interactions

## Benefits

1. **Performance Analysis**: Identify slow-loading interactions
2. **User Experience Insights**: Understand real user journey timing
3. **Data Portability**: Export for external analysis tools
4. **Historical Tracking**: Compare performance over time
5. **Debug Support**: Detailed interaction context for troubleshooting
6. **Compliance**: Audit trails for user interaction analysis
7. **Cross-page Analysis**: Track user flows across multiple pages and URLs
8. **Context Preservation**: Maintain page context for each interaction

## Technical Notes

- Performance data collection respects browser limitations
- Export functionality works offline
- Data is automatically formatted for readability
- Large journeys are handled efficiently
- Memory usage is optimized for long sessions
