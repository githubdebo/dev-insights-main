# Developer Insights Extension - Comprehensive Documentation

## Table of Contents
1. [Application Overview](#application-overview)
2. [Architecture & Components](#architecture--components)
3. [Data Flow & Communication](#data-flow--communication)
4. [User Journey & Navigation](#user-journey--navigation)
5. [Extension Lifecycle](#extension-lifecycle)
6. [Feature Deep Dive](#feature-deep-dive)
7. [Technical Implementation](#technical-implementation)
8. [Build & Deployment](#build--deployment)

---

## Application Overview

**Developer Insights** is a Chrome extension that provides comprehensive debugging and monitoring tools for web developers. It captures and analyzes:
- Network requests and API calls
- JavaScript errors and console messages
- User interactions and navigation flow
- Page screenshots with annotation capabilities
- Manual debugging logs with context

### Key Features
- **Real-time Network Monitoring**: Tracks all HTTP requests with detailed timing and response data
- **Error Context Capture**: Automatically captures JavaScript errors with reproduction steps
- **User Journey Tracking**: Records user interactions and navigation patterns
- **API Testing**: Built-in HTTP client for testing endpoints
- **Screenshot Annotations**: Capture and annotate page screenshots for bug reporting
- **Manual Logging**: Add contextual debug logs with automatic reproduction steps
- **Export Capabilities**: Export data to JSON and Word formats

---

## Architecture & Components

### 1. Extension Structure

```
developer-insights-main/
├── public/                     # Chrome extension files
│   ├── manifest.json          # Extension configuration
│   ├── background.js          # Service worker (main extension logic)
│   ├── content.js             # Content script (page interaction)
│   ├── injected.js            # Injected script (deep page monitoring)
│   ├── devtools.html          # DevTools panel entry point
│   ├── devtools.js            # DevTools integration
│   └── panel.html             # DevTools panel HTML
├── src/                       # React application source
│   ├── App.tsx                # Main application component
│   ├── main.tsx               # React app entry point
│   └── components/            # React components
│       ├── ErrorContextTab.tsx    # Error tracking & screenshots
│       ├── NetworkTab.tsx         # Network monitoring
│       ├── ApiTesterTab.tsx       # API testing tool
│       ├── JourneyTab.tsx         # User journey tracking
│       └── [other tabs]
└── dist/                      # Built files for production
```

### 2. Chrome Extension Components

#### **Manifest (manifest.json)**
- Defines extension permissions and capabilities
- Specifies content scripts, background scripts, and DevTools integration
- Permissions: `activeTab`, `storage`, `debugger`, `cookies`, `tabs`

#### **Background Script (background.js)**
- **Purpose**: Central hub for data storage and cross-tab communication
- **Responsibilities**:
  - Manages network request capture via Chrome Debugger API
  - Stores error context, journey data, and network requests
  - Handles inter-component communication
  - Manages screenshot capture
  - Coordinates data persistence

#### **Content Script (content.js)**
- **Purpose**: Bridge between web page and extension
- **Responsibilities**:
  - Injects monitoring scripts into web pages
  - Captures page-level events
  - Forwards data to background script
  - Manages DevTools panel communication

#### **Injected Script (injected.js)**
- **Purpose**: Deep page monitoring and event capture
- **Responsibilities**:
  - Intercepts network requests (XMLHttpRequest, Fetch API)
  - Captures JavaScript errors and unhandled promises
  - Tracks user interactions (clicks, form inputs, navigation)
  - Monitors console messages
  - Collects environment context

### 3. React Application Structure

#### **Main App (App.tsx)**
- **Purpose**: Central application shell and navigation
- **Features**:
  - Tab-based navigation system
  - Extension state management
  - Error boundary integration
  - DevTools panel detection

#### **Component Hierarchy**
```
App
├── ErrorContextTab (Error tracking & screenshots)
├── NetworkTab (Network monitoring - API & Assets)
├── ApiTesterTab (HTTP client tool)
├── JourneyTab (User interaction tracking)
├── ConsoleTab (Console message monitoring)
├── StorageTab (Local/Session storage viewer)
├── PersonalDataTab (Privacy analysis)
├── DataFlowTab (Data flow visualization)
└── UIPerformanceTab (Performance metrics)
```

---

## Data Flow & Communication

### 1. Extension Communication Flow

```
Web Page → Injected Script → Content Script → Background Script → React App
     ↑                                                                ↓
     └─────────────── User Interactions & UI Updates ←──────────────┘
```

### 2. Data Collection Pipeline

#### **Phase 1: Event Capture**
1. **Injected Script** monitors page events:
   - Network requests (XHR/Fetch interception)
   - JavaScript errors (window.onerror, unhandledrejection)
   - User interactions (click, input, navigation)
   - Console messages (console.log, console.error overrides)

2. **Content Script** receives events:
   - Forwards to background script via `chrome.runtime.sendMessage`
   - Adds tab context and metadata

#### **Phase 2: Data Storage**
1. **Background Script** processes events:
   - **Network Data**: Stored in `Map<tabId, requests[]>`
   - **Error Context**: Stored in `Map<tabId, errors[]>`
   - **Journey Data**: Stored in Chrome storage (`devInsightsJourney_${tabId}`)
   - **Screenshots**: Temporary storage as base64 data URLs

2. **Data Retention**:
   - Network requests: Last 100 per tab
   - Errors: Last 50 per tab
   - Journey steps: Last 100 per tab
   - Screenshots: Memory-based (cleared on extension reload)

#### **Phase 3: Data Retrieval**
1. **React App** requests data via messages:
   - `GET_NETWORK_DATA` → Network requests
   - `GET_ERROR_CONTEXT` → Error data with enhanced context
   - `GET_JOURNEY` → User interaction history

2. **Real-time Updates**:
   - Polling every 2 seconds for new data
   - Event-driven updates for critical errors

### 3. Context Enhancement Pipeline

When errors occur, the system automatically enriches them with context:

```
Error Detected → Get Journey Data → Get Network Data → Generate Reproduction Steps → Enhanced Error
```

**Enhanced Context Includes**:
- **User Journey**: Last 20 actions before error
- **Network Context**: Last 10 API calls before error
- **Environment Info**: Viewport, cookies, online status, referrer
- **Reproduction Steps**: Auto-generated step-by-step instructions
- **Stack Trace**: Full JavaScript error stack
- **Timestamp**: Precise error occurrence time

---

## User Journey & Navigation

### 1. Extension Activation Flow

```
User Opens Browser → Installs Extension → Extension Loads → Injects Scripts → Ready for Monitoring
```

**Detailed Steps**:
1. **Extension Installation**:
   - Chrome loads manifest.json
   - Background script starts running
   - Content scripts register for injection

2. **Page Visit**:
   - Content script injects into page
   - Injected script starts monitoring
   - Debugger attaches (if permissions allow)
   - Real-time data collection begins

3. **Extension Interface Access**:
   - **Popup**: Click extension icon in toolbar
   - **DevTools Panel**: Open Chrome DevTools → "Developer Insights" tab

### 2. Tab Navigation & Features

#### **Error Context Tab** (Default)
- **Purpose**: Comprehensive error tracking and debugging
- **Features**:
  - Real-time error capture with full context
  - Manual log addition with severity levels
  - Screenshot capture with annotation tools
  - Export to Word/JSON formats
  - Copy formatted reports to clipboard

**User Flow**:
```
Tab Load → Error Occurs → Auto-Capture Context → Display in List → Select Error → View Details → Export/Copy
```

#### **Network Tab**
- **Purpose**: Monitor all network activity
- **Sub-tabs**:
  - **API**: REST/GraphQL requests with request/response details
  - **Assets**: Static resources (images, CSS, JS, fonts)

**User Flow**:
```
Page Load → Network Requests Fire → Real-time Display → Filter/Search → View Details → Test in API Tab
```

#### **API Tester Tab**
- **Purpose**: HTTP client for testing endpoints
- **Features**:
  - Custom HTTP requests (GET, POST, PUT, DELETE, etc.)
  - Request headers and body configuration
  - Response visualization with JSON tree
  - Request history and templates
  - Export test results

**User Flow**:
```
Open Tab → Configure Request → Send → View Response → Save to History → Export Results
```

#### **Journey Tab**
- **Purpose**: Visualize user interaction patterns
- **Features**:
  - Chronological list of user actions
  - Click tracking with element details
  - Navigation history
  - Form input monitoring
  - Timeline visualization

**User Flow**:
```
User Interacts → Actions Recorded → Display Timeline → Filter by Type → Export Journey
```

### 3. Advanced Features

#### **Screenshot Annotation System**
1. **Capture**: Click camera button → Chrome captures visible tab
2. **Annotate**: Click pen icon → Canvas overlay appears
3. **Draw**: Use pen tool with color/size controls
4. **Undo**: Step-by-step undo functionality
5. **Save**: Annotations merged with original screenshot
6. **Export**: Download annotated image

#### **Manual Logging Workflow**
1. **Add Log**: Click "Add Log" button
2. **Fill Details**: Message, notes, severity level
3. **Auto-Context**: System captures current page state
4. **Generate Steps**: Automatic reproduction instructions
5. **Save**: Log appears in main list with context
6. **Export**: Include in Word reports

---

## Extension Lifecycle

### 1. Installation & Initialization
```javascript
// Background script starts
chrome.runtime.onInstalled → Setup data structures → Register event listeners

// Content script injection
Page Load → chrome.tabs.onUpdated → Inject content.js → Inject injected.js

// DevTools integration
DevTools Open → Load devtools.html → Create panel → Load React app
```

### 2. Runtime Operation
```javascript
// Continuous monitoring
Page Events → Injected Script → Content Script → Background Script → Storage

// Data requests
React App → chrome.runtime.sendMessage → Background Script → Response → UI Update

// Error handling
JavaScript Error → Enhanced Context → Storage → Real-time Display
```

### 3. Cleanup & Memory Management
- **Automatic Cleanup**: Old data removed when limits exceeded
- **Tab Cleanup**: Data cleared when tabs close
- **Extension Reload**: All in-memory data reset

---

## Feature Deep Dive

### 1. Network Monitoring Implementation

**Chrome Debugger API Integration**:
```javascript
// Attach debugger to capture network events
chrome.debugger.attach({tabId}, "1.3");
chrome.debugger.sendCommand({tabId}, "Network.enable");

// Listen for network events
chrome.debugger.onEvent.addListener((source, method, params) => {
  if (method === 'Network.responseReceived') {
    // Process response data
  }
});
```

**Request Interception (Injected Script)**:
```javascript
// Override XMLHttpRequest
const originalXHR = window.XMLHttpRequest;
function XMLHttpRequestProxy() {
  // Intercept all XHR methods
  // Capture request/response data
  // Forward to extension
}
window.XMLHttpRequest = XMLHttpRequestProxy;

// Override Fetch API
const originalFetch = window.fetch;
window.fetch = function(...args) {
  // Capture request details
  // Execute original fetch
  // Capture response
  // Forward to extension
};
```

### 2. Error Context System

**Multi-layered Error Capture**:
1. **Global Error Handler**: `window.onerror`
2. **Promise Rejection**: `window.unhandledrejection`
3. **Console Override**: Intercept `console.error`
4. **Network Errors**: Failed HTTP requests

**Context Enhancement Algorithm**:
```javascript
function enhanceError(error, timestamp) {
  const context = {
    userJourney: getJourneyBefore(timestamp),
    networkContext: getNetworkBefore(timestamp),
    environmentInfo: getCurrentEnvironment(),
    reproductionSteps: generateSteps(error, journey)
  };
  return { ...error, ...context };
}
```

### 3. JSON Viewer Component

**Hierarchical Data Display**:
```tsx
const JsonTree = ({ data, level = 0 }) => {
  // Recursive component for nested objects
  // Color-coded by data type
  // Expandable/collapsible nodes
  // Property keys and values displayed
};
```

**Features**:
- **Type Visualization**: Different colors for strings, numbers, booleans, null
- **Interactive**: Click to expand/collapse objects and arrays
- **Search**: Filter properties by name or value
- **Copy**: Select and copy data portions

---

## Technical Implementation

### 1. Technology Stack

**Frontend**:
- **React 18**: Component-based UI with hooks
- **TypeScript**: Type-safe development
- **Tailwind CSS**: Utility-first styling
- **Lucide React**: Icon library

**Extension APIs**:
- **Chrome Extensions Manifest V3**: Modern extension architecture
- **Chrome Debugger API**: Network monitoring
- **Chrome Storage API**: Data persistence
- **Chrome Tabs API**: Tab management

**Build Tools**:
- **Vite**: Fast development and building
- **ESLint**: Code linting and standards
- **PostCSS**: CSS processing
- **Terser**: JavaScript minification

### 2. State Management

**React State Pattern**:
```tsx
// Component-level state for UI
const [errors, setErrors] = useState<ErrorContext[]>([]);
const [selectedError, setSelectedError] = useState<ErrorContext | null>(null);

// Cross-component communication via props and callbacks
<ErrorContextTab tabId={currentTabId} />
```

**Extension State**:
- **Background Script**: Central data store
- **Chrome Storage**: Persistent data
- **Message Passing**: Real-time updates

### 3. Performance Optimizations

**Data Throttling**:
- Polling interval: 2 seconds for non-critical updates
- Batch message processing
- Limited data retention (last N items)

**Memory Management**:
- Automatic cleanup of old data
- Efficient data structures (Maps over Objects)
- Lazy loading of large datasets

**UI Optimizations**:
- Virtual scrolling for large lists
- Debounced search inputs
- Memoized components for stable renders

---

## Build & Deployment

### 1. Development Setup

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Open Chrome DevTools → Developer Insights tab
```

**Development Features**:
- Hot reload for React components
- TypeScript compilation
- ESLint code checking
- Tailwind CSS compilation

### 2. Production Build

```bash
# Build for production
npm run build

# Output in dist/ directory:
# - main.js (React app bundle)
# - main.css (Compiled styles)
# - Static assets and extension files
```

**Build Optimizations**:
- Code splitting and tree shaking
- CSS purging and minification
- Asset optimization
- Source map generation

### 3. Extension Packaging

**Chrome Web Store Deployment**:
1. **Build**: `npm run build`
2. **Package**: Zip dist/ contents
3. **Upload**: Chrome Developer Dashboard
4. **Review**: Automated and manual review process
5. **Publish**: Live in Chrome Web Store

**Development Installation**:
1. Open Chrome → Extensions → Developer mode
2. "Load unpacked" → Select dist/ folder
3. Extension loads and is ready for testing

### 4. File Structure Post-Build

```
dist/
├── manifest.json          # Extension configuration
├── background.js          # Service worker
├── content.js             # Content script
├── injected.js            # Page injection script
├── devtools.html          # DevTools integration
├── devtools.js            # DevTools logic
├── panel.html             # DevTools panel
├── index.html             # Popup interface
├── assets/
│   ├── main-[hash].js     # React app bundle
│   ├── main-[hash].css    # Compiled styles
│   └── icon*.png          # Extension icons
```

---

## Data Persistence & Storage

### 1. Storage Architecture

**Chrome Storage API**:
```javascript
// Journey data (persistent across sessions)
chrome.storage.local.set({
  [`devInsightsJourney_${tabId}`]: journeySteps
});

// Settings and preferences
chrome.storage.sync.set({
  userPreferences: { theme: 'dark', autoCapture: true }
});
```

**In-Memory Storage (Background Script)**:
```javascript
class DevInsightsBackground {
  constructor() {
    this.networkRequests = new Map();     // Per-tab network data
    this.errorContext = new Map();        // Per-tab error data
    this.injectedRequests = new Map();    // API call data
  }
}
```

### 2. Data Synchronization

**Real-time Updates**:
- Extension → Background: Immediate message passing
- Background → UI: Polling every 2 seconds
- Cross-tab: Shared background script state

**Conflict Resolution**:
- Timestamp-based ordering
- Last-write-wins for settings
- Append-only for events and logs

---

## Security & Privacy

### 1. Permission Model

**Minimum Required Permissions**:
- `activeTab`: Access current tab only when user activates extension
- `storage`: Persist user data and settings
- `debugger`: Monitor network requests (with user consent)
- `tabs`: Get tab information for context

**Data Handling**:
- **Local Only**: All data stays on user's machine
- **No External Transmission**: No data sent to external servers
- **User Control**: Clear data anytime through extension
- **Temporary Storage**: Most data cleared on browser restart

### 2. Content Security Policy

**Manifest V3 Compliance**:
- No eval() or unsafe inline scripts
- Strict CSP for all extension pages
- Secure message passing between components
- Sandboxed iframe for untrusted content

---

## Troubleshooting & Common Issues

### 1. Extension Not Working

**Debugger Permission Issues**:
```javascript
// Check if debugger can attach
chrome.debugger.attach({tabId}, "1.3", () => {
  if (chrome.runtime.lastError) {
    console.error('Cannot attach debugger:', chrome.runtime.lastError);
  }
});
```

**Content Script Injection Failures**:
- Chrome internal pages (chrome://) are not accessible
- Some sites block content script injection
- Extension permissions might be insufficient

### 2. Data Not Appearing

**Common Causes**:
1. **Tab ID Mismatch**: Ensure correct tab ID is being used
2. **Storage Limits**: Chrome storage quotas exceeded
3. **Permission Denied**: User denied debugger access
4. **Script Injection Failed**: Content security policy blocks injection

**Debugging Steps**:
```javascript
// Check if scripts are injected
console.log('Content script loaded:', !!window.devInsightsContentScript);
console.log('Injected script loaded:', !!window.devInsightsInjected);

// Verify data flow
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Message received:', message.type, message);
});
```

### 3. Performance Issues

**Memory Usage**:
- Monitor background script memory in Task Manager
- Clear old data regularly
- Reduce polling frequency if needed

**UI Responsiveness**:
- Use React DevTools to identify slow components
- Implement virtual scrolling for large datasets
- Debounce expensive operations

---

## Future Enhancements

### 1. Planned Features

**Advanced Analytics**:
- Performance metrics collection
- User behavior pattern analysis
- A/B testing integration
- Real user monitoring (RUM)

**Enhanced Debugging**:
- Redux/Vuex state inspection
- Component tree visualization
- Memory leak detection
- Bundle analysis tools

**Collaboration Features**:
- Share debug sessions with team
- Export findings to external tools
- Integration with bug tracking systems
- Team debugging workflows

### 2. Technical Improvements

**Architecture**:
- WebAssembly for performance-critical operations
- Offscreen document for heavy computations
- Service worker optimization
- Cross-browser compatibility (Firefox, Edge)

**UI/UX**:
- Dark/light theme support
- Customizable dashboard layouts
- Keyboard shortcuts and accessibility
- Mobile-responsive design

---

This comprehensive documentation covers the complete Developer Insights extension architecture, from initial browser startup through user navigation and data flow. The extension provides a powerful suite of debugging tools while maintaining security, performance, and ease of use.
