# Developer Insights Chrome Extension
## Comprehensive Architecture Documentation

---

## 📋 Table of Contents
1. [Executive Summary](#executive-summary)
2. [Technology Stack](#technology-stack)
3. [Architecture Overview](#architecture-overview)
4. [Core Components](#core-components)
5. [Data Flow](#data-flow)
6. [Extension Structure](#extension-structure)
7. [Security & Permissions](#security--permissions)
8. [Development Workflow](#development-workflow)
9. [Component Details](#component-details)
10. [Future Enhancements](#future-enhancements)

---

## 🎯 Executive Summary

**Developer Insights** is a Chrome extension designed to provide web developers with comprehensive, real-time insights into website performance, API interactions, user journeys, and debugging information. The extension offers a unified dashboard for monitoring network requests, testing APIs, tracking user interactions, and analyzing web application behavior.

### Key Features
- **Network Monitoring**: Real-time capture and analysis of network requests
- **API Testing**: Interactive API endpoint testing with request/response inspection
- **User Journey Tracking**: Monitor user interactions and navigation patterns
- **Performance Analytics**: Performance indicators and optimization insights
- **Developer Tools Integration**: Seamless integration with browser DevTools

---

## 🛠️ Technology Stack

### **Frontend Framework**
- **React 18.3.1**: Core UI framework with hooks and functional components
- **TypeScript 5.5.3**: Type-safe JavaScript with enhanced developer experience
- **Vite 5.4.2**: Modern build tool for fast development and optimized production builds

### **Styling & UI**
- **Tailwind CSS 3.4.1**: Utility-first CSS framework for rapid UI development
- **Lucide React 0.344.0**: Modern icon library with 1000+ customizable icons
- **PostCSS 8.4.35**: CSS processing with autoprefixer for browser compatibility

### **Chrome Extension APIs**
- **Manifest V3**: Latest Chrome extension specification
- **Chrome Debugger API**: Deep network request monitoring
- **Chrome Storage API**: Persistent data storage across sessions
- **Chrome Tabs API**: Tab management and information retrieval
- **Chrome Cookies API**: Cookie inspection and management

### **Development Tools**
- **ESLint 9.9.1**: Code linting and quality enforcement
- **TypeScript ESLint**: TypeScript-specific linting rules
- **Terser 5.43.1**: JavaScript minification for production builds

---

## 🏗️ Architecture Overview

### **Multi-Layer Architecture**

```
┌─────────────────────────────────────────────────────┐
│                   Browser Layer                     │
├─────────────────────────────────────────────────────┤
│  React UI Components (Popup & DevTools Panel)      │
├─────────────────────────────────────────────────────┤
│         Chrome Extension Runtime Layer             │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐   │
│  │   Content   │ │ Background  │ │   Injected  │   │
│  │   Script    │ │   Script    │ │   Script    │   │
│  └─────────────┘ └─────────────┘ └─────────────┘   │
├─────────────────────────────────────────────────────┤
│              Web Page Context                       │
│  DOM Manipulation, Network Interception, Events    │
└─────────────────────────────────────────────────────┘
```

### **Communication Flow**
1. **Injected Script** → Captures page-level events (XHR, Fetch, User Interactions)
2. **Content Script** → Bridges injected script and extension runtime
3. **Background Script** → Manages Chrome APIs, data storage, and debugger
4. **React UI** → Displays processed data with interactive components

---

## 🔧 Core Components

### **1. Background Script (`background.js`)**
- **Purpose**: Central coordinator for all extension operations
- **Responsibilities**:
  - Chrome Debugger API management
  - Network request aggregation and storage
  - Message routing between components
  - Tab lifecycle management
  - Local storage operations

### **2. Content Script (`content.js`)**
- **Purpose**: Bridge between web page and extension
- **Responsibilities**:
  - Injected script lifecycle management
  - Message passing coordination
  - Journey data retrieval
  - Tab identification and context management

### **3. Injected Script (`injected.js`)**
- **Purpose**: Deep web page integration
- **Responsibilities**:
  - XMLHttpRequest and Fetch API interception
  - URL resolution (relative to absolute)
  - Request/response data capture
  - User interaction event monitoring

### **4. React UI Layer**
- **Purpose**: User interface and data visualization
- **Components**:
  - Main application shell with tab navigation
  - Network monitoring with performance indicators
  - Interactive API testing interface
  - User journey visualization
  - Real-time data updates

---

## 📊 Data Flow

### **Network Request Capture Flow**
```
Web Page Request → Injected Script → Content Script → Background Script → React UI
     ↓                  ↓                ↓               ↓              ↓
  XHR/Fetch         Intercept &       Forward to      Store & Process   Display &
  Execution         Resolve URLs      Background       Network Data      Analyze
```

### **User Journey Tracking Flow**
```
User Interaction → Injected Script → Content Script → Background Script → Local Storage → React UI
      ↓                 ↓                ↓               ↓                    ↓           ↓
   Click/Type      Capture Event    Forward Event   Process & Store    Persist Data   Visualize
```

### **API Testing Flow**
```
User Input → React UI → Background Script → Chrome APIs → External API → Response Processing → UI Update
    ↓           ↓           ↓                  ↓              ↓              ↓                ↓
Set Params   Validate    Execute Request   Handle CORS   Receive Data   Parse & Format   Display Results
```

---

## 📁 Extension Structure

```
dev-insights-main/
├── public/                      # Static extension files
│   ├── manifest.json           # Extension configuration
│   ├── background.js           # Service worker
│   ├── content.js             # Content script
│   ├── injected.js            # Page-level script
│   ├── index.html             # Popup interface
│   ├── panel.html             # DevTools panel
│   └── icons/                 # Extension icons
├── src/                        # React application source
│   ├── App.tsx                # Main application component
│   ├── main.tsx               # React entry point
│   ├── index.css              # Global styles
│   └── components/            # React components
│       ├── NetworkTab.tsx     # Network monitoring UI
│       ├── ApiTesterTab.tsx   # API testing interface
│       ├── JourneyTab.tsx     # User journey visualization
│       └── [other components] # Additional UI components
├── dist/                       # Built extension files
├── package.json               # Dependencies and scripts
├── vite.config.ts            # Build configuration
├── tailwind.config.js        # Styling configuration
└── tsconfig.json             # TypeScript configuration
```

---

## 🔒 Security & Permissions

### **Required Permissions**
- **`activeTab`**: Access current tab information
- **`storage`**: Persist extension data locally
- **`debugger`**: Deep network monitoring capabilities
- **`cookies`**: Cookie inspection and management
- **`<all_urls>`**: Universal website access for comprehensive monitoring

### **Security Measures**
- **Content Security Policy**: Strict CSP prevents code injection
- **Sandboxed Execution**: Each script runs in isolated context
- **Permission Scoping**: Minimal required permissions principle
- **Error Handling**: Graceful handling of extension context invalidation

---

## 🔄 Development Workflow

### **Build Process**
```bash
# Development
npm run dev          # Start development server with hot reload

# Production
npm run build        # Create optimized production build
npm run preview      # Preview production build locally

# Code Quality
npm run lint         # ESLint code analysis and formatting
```

### **Development Architecture**
- **Hot Module Replacement**: Instant UI updates during development
- **TypeScript Compilation**: Real-time type checking and transpilation
- **Tailwind JIT**: Just-in-time CSS compilation for optimal performance
- **Source Maps**: Debug-friendly mapping for production troubleshooting

---

## 🧩 Component Details

### **NetworkTab Component**
- **Purpose**: Network request monitoring and analysis
- **Features**:
  - Real-time request capture
  - Performance categorization (Fast/Normal/Slow/Very Slow)
  - API vs Asset request filtering
  - Request/response inspection
  - URL formatting and resolution
- **Data Sources**: Chrome Debugger API + Injected script data

### **ApiTesterTab Component**
- **Purpose**: Interactive API endpoint testing
- **Features**:
  - Request builder (method, headers, body)
  - Response analysis and formatting
  - Request history and templates
  - Authentication header management
  - CORS handling and error reporting
- **Integration**: Direct Chrome API usage for cross-origin requests

### **JourneyTab Component**
- **Purpose**: User interaction tracking and analysis
- **Features**:
  - Click and navigation event capture
  - Journey step visualization
  - Timestamp and sequence tracking
  - Per-tab journey isolation
- **Storage**: Chrome local storage with tab-specific keys

---

## 🚀 Future Enhancements

### **Planned Features**
1. **Advanced Analytics**: Performance trend analysis and reporting
2. **Export Capabilities**: Data export in multiple formats (JSON, CSV, HAR)
3. **Custom Filters**: User-defined request filtering and categorization
4. **Integration APIs**: Webhook support for external monitoring tools
5. **Performance Budgets**: Automated performance threshold monitoring
6. **Security Scanning**: Basic security vulnerability detection

### **Technical Improvements**
1. **Offline Support**: Service worker caching for offline functionality
2. **Data Compression**: Efficient storage of large datasets
3. **Real-time Sync**: Multi-tab data synchronization
4. **Plugin Architecture**: Extensible component system for custom features

---

## 📈 Performance Considerations

### **Optimization Strategies**
- **Lazy Loading**: Components loaded on-demand to reduce initial bundle size
- **Data Virtualization**: Efficient rendering of large request lists
- **Memory Management**: Automatic cleanup of old data to prevent memory leaks
- **Debounced Updates**: Throttled UI updates to maintain responsivity

### **Resource Usage**
- **CPU Impact**: Minimal background processing with efficient event handling
- **Memory Footprint**: Controlled data retention with automatic pruning
- **Network Overhead**: Zero additional network requests for core functionality

---

## 🎯 Conclusion

The Developer Insights Chrome Extension represents a comprehensive solution for web development monitoring and debugging. Built with modern web technologies and following Chrome extension best practices, it provides developers with powerful insights while maintaining excellent performance and security standards.

The modular architecture ensures maintainability and extensibility, while the React-based UI delivers a smooth, responsive user experience. The extension's multi-layered approach to data capture ensures comprehensive coverage of web application behavior, making it an invaluable tool for modern web development workflows.

---

## 📞 Technical Support

For technical questions, feature requests, or bug reports, please refer to the project repository or contact the development team.

**Version**: 1.0.0  
**Last Updated**: June 2025  
**Chrome Extension Manifest**: Version 3
