# dev-insights
its an extension that displays all insights related to all web activities in specific tabs
