# Import API Collections Feature

The Developer Insights extension now includes an **Import API Collections** tab that allows you to import and manage your API collections directly within the extension.

## Features

### 🔄 Collection Import
- **Drag & Drop or Click Upload**: Import API Collection JSON files (Postman Collection v2.1 format)
- **Validation**: Automatic validation of collection format
- **Visual Feedback**: Clear success/error messages during import

### 📋 Collection Management
- **Overview Display**: View imported collections with descriptions and request counts
- **Request Listing**: Browse all imported requests organized by collection and folder
- **Visual Organization**: Clear method indicators (GET, POST, PUT, DELETE) with color coding

### 🚀 Request Execution
- **Direct Execution**: Execute requests directly from the import tab
- **API Tester Integration**: Send requests to the API Tester tab for advanced testing
- **Header & Body Support**: Full support for headers, request bodies, and authentication

### 💾 Data Management
- **Export Functionality**: Export imported requests as JSON for backup
- **Clear All**: Remove all imported data when needed
- **Persistent Storage**: Imported collections remain available during your session

## How to Use

### 1. Import a Collection
1. Navigate to the **Import API Collections** tab
2. Click the upload area or drag a `.json` file
3. Select your API Collection JSON file (Postman Collection v2.1 format)
4. Wait for the import confirmation

### 2. Manage Requests
- Browse imported collections and their requests
- Use the color-coded method indicators to identify request types
- View request URLs, headers, and associated collections

### 3. Execute Requests
- **Quick Execute**: Click the "Execute" button for immediate testing
- **Advanced Testing**: Click "To API Tester" to send the request to the API Tester tab for detailed analysis

### 4. Export & Cleanup
- Use the "Export" button to download imported requests as JSON
- Use "Clear All" to remove all imported data

## Sample Collection

A sample collection (`sample-postman-collection.json`) is included in the project root for testing purposes. This collection includes:
- Basic GET/POST requests
- Nested folder structure
- Headers and request bodies
- RESTful API examples using JSONPlaceholder

## Supported Collection Format

The feature supports **Postman Collection v2.1** format. Make sure your collection file:
- Is exported from Postman as a Collection v2.1
- Has valid JSON structure
- Contains the required schema information

## Integration with API Tester

The Import API Collections feature seamlessly integrates with the existing API Tester tab:
- Imported requests can be sent directly to API Tester
- Headers and request bodies are automatically populated
- Supports all HTTP methods and authentication types
- Maintains request history and undo functionality

## Error Handling

The feature includes comprehensive error handling:
- Invalid JSON format detection
- Non-API collection file detection  
- Network request execution errors
- Clear user feedback for all error states

## Future Enhancements

Planned improvements include:
- Support for additional collection formats (OpenAPI, Insomnia, etc.)
- Environment variable support
- Authentication preset import
- Collection folder organization in UI
- Bulk request execution
- Request comparison tools
