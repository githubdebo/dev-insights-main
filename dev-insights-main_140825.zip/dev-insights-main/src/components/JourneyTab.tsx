import React, { useEffect, useState } from 'react';

// Enhanced journey step interface with loading time information and page context
// Note: Input and focus events are filtered out from display and export
interface JourneyStep {
  type: 'url' | 'click' | 'input' | 'focus';
  value: string;
  timestamp: number;
  element?: string; // JSON string containing element details
  loadTime?: number; // Time taken to load content after interaction
  domLoadTime?: number; // DOM content loaded time
  fullLoadTime?: number; // Complete page load time
  size?: number; // Content size if available
  description?: string; // Full description of the action
  pageUrl?: string; // URL of the page where the interaction occurred
  pageTitle?: string; // Title of the page where the interaction occurred
}

export const JourneyTab: React.FC = () => {
  const [steps, setSteps] = useState<JourneyStep[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [lastUpdateTimestamp, setLastUpdateTimestamp] = useState<number>(0);

  const loadJourneyData = (isBackgroundUpdate = false) => {
    // Only show loading state for initial load or manual refresh, not background polling
    if (!isBackgroundUpdate) {
      setIsLoading(true);
      setError(null);
    }
    
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabId = tabs[0]?.id || 'global';
      try {
        chrome.runtime.sendMessage({ type: 'GET_JOURNEY', tabId }, (resp) => {
          if (!isBackgroundUpdate) {
            setIsLoading(false);
          }
          
          if (chrome.runtime.lastError) {
            if (!isBackgroundUpdate) {
              setError('Unable to load journey data. Extension context may be invalid or reloaded.');
            }
            return;
          }
          
          if (resp && Array.isArray(resp.steps)) {
            // Sort steps by timestamp ascending and filter out input and focus events
            const sortedSteps = [...resp.steps]
              .filter(step => step.type !== 'input' && step.type !== 'focus') // Exclude input and focus events
              .sort((a, b) => {
                // Primary sort by timestamp
                const timeDiff = a.timestamp - b.timestamp;
                
                // If timestamps are very close (within 100ms), ensure logical order
                if (Math.abs(timeDiff) <= 100) {
                  // Click events should come before navigation events with similar timestamps
                  if (a.type === 'click' && b.type === 'url') return -1;
                  if (a.type === 'url' && b.type === 'click') return 1;
                }
                
                return timeDiff;
              });
            
            // Check if data has actually changed to prevent unnecessary re-renders
            const currentTimestamp = sortedSteps.length > 0 ? 
              Math.max(...sortedSteps.map(step => step.timestamp)) : 0;
            
            // Only update if data has changed or this is not a background update
            if (!isBackgroundUpdate || currentTimestamp !== lastUpdateTimestamp || sortedSteps.length !== steps.length) {
              setSteps(sortedSteps);
              setLastUpdateTimestamp(currentTimestamp);
              
              // Clear error state if we successfully loaded data
              if (error) {
                setError(null);
              }
            }
            
            // If no steps found or cleared, ensure state reflects this
            if (sortedSteps.length === 0 && steps.length > 0) {
              // Check if this might be due to a recent page refresh
              const now = Date.now();
              const recentRefresh = sessionStorage.getItem('devInsights_lastRefresh');
              if (recentRefresh && (now - parseInt(recentRefresh)) < 10000) {
                console.log('Journey cleared due to recent page refresh');
                // Clear any old data that might be lingering
                setSteps([]);
                setLastUpdateTimestamp(0);
                if (!isBackgroundUpdate) {
                  setError(null);
                }
              }
            }
          } else {
            // If resp.steps is not an array or doesn't exist, ensure we clear the state
            if (!isBackgroundUpdate || steps.length > 0) {
              setSteps([]);
              setLastUpdateTimestamp(0);
              if (!isBackgroundUpdate) {
                setError('No journey data found for this tab.');
              }
            }
          }
        });
      } catch (e) {
        if (!isBackgroundUpdate) {
          setIsLoading(false);
          setSteps([]); // Clear any existing steps on error
          setError('Unable to load journey data. Extension context may be invalid or reloaded.');
          setLastUpdateTimestamp(0);
        }
      }
    });
  };

  useEffect(() => {
    // Initial load
    loadJourneyData(false);
    
    // Set up periodic refresh with longer interval and background mode
    const refreshInterval = setInterval(() => {
      loadJourneyData(true); // Background update - won't show loading state
    }, 5000); // Reduced frequency to every 5 seconds
    
    // Cleanup interval on component unmount
    return () => clearInterval(refreshInterval);
  }, []);

  // Add a refresh handler for manual refresh
  const handleRefresh = () => {
    loadJourneyData(false); // Manual refresh - will show loading state
  };

  // Add CSV export handler
  const handleExportCSV = () => {
    if (steps.length === 0) return;
    
    // Filter out input and focus events from export
    const filteredSteps = steps.filter(step => step.type !== 'input' && step.type !== 'focus');
    
    const csvHeaders = [
      'Step',
      'Timestamp',
      'Type',
      'Action',
      'Page URL',
      'Load Time (ms)',
      'Content Size (bytes)'
    ];
    
    const csvRows = filteredSteps.map((step, index) => {
      return [
        index + 1,
        new Date(step.timestamp).toISOString(),
        step.type,
        `"${step.value.replace(/"/g, '""')}"`, // Escape quotes
        `"${(step.pageUrl || 'Unknown').replace(/"/g, '""')}"`, // Escape quotes in URL
        step.loadTime || '',
        step.size || ''
      ];
    });
    
    const csvContent = [csvHeaders, ...csvRows]
      .map(row => row.join(','))
      .join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `journey-export-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Add a clear handler
  const handleClear = () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabId = tabs[0]?.id || 'global';
      try {
        chrome.runtime.sendMessage({ type: 'CLEAR_JOURNEY', tabId }, (resp) => {
          if (chrome.runtime.lastError) {
            setError('Unable to clear journey data.');
            return;
          }
          if (resp && resp.success) {
            setSteps([]);
            setError(null);
          }
        });
      } catch (e) {
        setError('Unable to clear journey data.');
      }
    });
  };

  return (
    <div className="h-full flex flex-col p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex gap-2 flex-wrap">
          <button
            className="px-3 py-1.5 text-sm bg-blue-700 hover:bg-blue-800 rounded text-white"
            onClick={handleRefresh}
          >
            Refresh
          </button>
          <button
            className="px-3 py-1.5 text-sm bg-green-700 hover:bg-green-800 rounded text-white"
            onClick={handleExportCSV}
            disabled={steps.length === 0}
          >
            Export to Excel
          </button>
          <button
            className="px-3 py-1.5 text-sm bg-red-600 hover:bg-red-700 rounded text-white"
            onClick={handleClear}
            disabled={steps.length === 0}
          >
            Clear Journey
          </button>
        </div>
      </div>
      <p className="text-sm text-gray-400 mb-4">
        Shows the sequence of URLs visited and clicks performed in this tab (input and focus events are filtered out). 
        <br />
        <span className="text-xs text-gray-500">Note: Journey data is automatically cleared when the page is refreshed to start logging from the beginning.</span>
      </p>
      {error ? (
        <div className="text-red-400 text-sm mb-4">{error}</div>
      ) : isLoading ? (
        <div className="text-gray-400 text-sm mb-4">Loading journey data...</div>
      ) : steps.length === 0 ? (
        <div className="text-gray-400 text-sm mb-4">
          {(() => {
            const now = Date.now();
            const recentRefresh = sessionStorage.getItem('devInsights_lastRefresh');
            if (recentRefresh && (now - parseInt(recentRefresh)) < 10000) {
              return (
                <>
                  Journey data was cleared due to page refresh. Start interacting with the page to see new journey steps logged here.
                  <div className="text-xs text-blue-400 mt-1">
                    🔄 Page refreshed at {new Date(parseInt(recentRefresh)).toLocaleTimeString()} - logging will resume with new interactions.
                  </div>
                </>
              );
            } else {
              return (
                <>
                  No journey data found for this tab yet. Start interacting with the page to see your journey logged here.
                  <div className="text-xs text-gray-500 mt-1">
                    💡 Tip: The initial page load and all your clicks will be tracked automatically.
                  </div>
                </>
              );
            }
          })()}
        </div>
      ) : (
        // Enhanced list representation with loading times
        <div className="mb-6">
          <h3 className="text-base font-semibold mb-2">Journey Steps ({steps.length})</h3>
          <div className="space-y-3">
            {steps.map((step, i) => {
              let elementDetails = null;
              try {
                elementDetails = step.element ? JSON.parse(step.element) : null;
              } catch (e) {
                // Ignore parsing errors
              }
              
              // Determine border color based on step type and content
              let borderColor = 'border-blue-500'; // default
              if (step.type === 'url') {
                try {
                  const elementData = step.element ? JSON.parse(step.element) : null;
                  if (elementData?.source === 'initial_load' || elementData?.isInitialLoad) {
                    borderColor = 'border-purple-500'; // Purple for initial page load
                  } else {
                    borderColor = 'border-blue-500'; // Blue for navigation
                  }
                } catch (e) {
                  // If parsing fails, check if it's described as initial load
                  if (step.description && step.description.includes('Page loaded:')) {
                    borderColor = 'border-purple-500';
                  } else {
                    borderColor = 'border-blue-500';
                  }
                }
              } else if (step.type === 'click') {
                if (step.loadTime && step.loadTime > 100) {
                  borderColor = 'border-orange-500'; // Orange for clicks with performance impact
                } else {
                  borderColor = 'border-green-500'; // Green for regular clicks
                }
              }
              
              return (
                <div key={i} className={`bg-gray-800 rounded p-3 border-l-4 ${borderColor}`}>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-medium text-gray-300">#{i + 1}</span>
                        <span className="font-mono text-xs text-gray-400">
                          {new Date(step.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                      
                      <div className="mb-2">
                        {step.type === 'url' ? (
                          (() => {
                            try {
                              const elementData = elementDetails?.source === 'initial_load' || elementDetails?.isInitialLoad;
                              const isInitialLoad = elementData || (step.description && step.description.includes('Page loaded:'));
                              return isInitialLoad ? (
                                <span className="text-purple-400 font-medium">Initial Load: </span>
                              ) : (
                                <span className="text-blue-400 font-medium">Navigation: </span>
                              );
                            } catch (e) {
                              return step.description && step.description.includes('Page loaded:') ? (
                                <span className="text-purple-400 font-medium">Initial Load: </span>
                              ) : (
                                <span className="text-blue-400 font-medium">Navigation: </span>
                              );
                            }
                          })()
                        ) : step.type === 'click' ? (
                          step.loadTime && step.loadTime > 100 ? (
                            <span className="text-orange-400 font-medium">Click + Load ({step.loadTime}ms): </span>
                          ) : (
                            <span className="text-green-400 font-medium">Click: </span>
                          )
                        ) : (
                          <span className="text-gray-400 font-medium">{step.type}: </span>
                        )}
                        <span className="text-gray-200">{step.description || step.value}</span>
                        
                        {/* Show full text if it's longer than what's displayed */}
                        {elementDetails && elementDetails.text && elementDetails.text.length > 100 && (
                          <div className="text-xs text-gray-500 mt-1">
                            <details className="cursor-pointer">
                              <summary className="hover:text-gray-400">Full Text Content</summary>
                              <div className="mt-1 break-words whitespace-pre-wrap">{elementDetails.text}</div>
                            </details>
                          </div>
                        )}
                      </div>
                      
                      {/* Show page context if available and different from current step for navigation */}
                      {step.pageUrl && step.type !== 'url' && (
                        <div className="text-xs text-gray-400 mb-2">
                          <span className="font-medium">Page: </span>
                          <span className="break-all">{step.pageUrl}</span>
                          {step.pageTitle && step.pageTitle !== 'Untitled' && (
                            <span className="ml-2">({step.pageTitle})</span>
                          )}
                        </div>
                      )}
                      
                      {/* Show loading times if available */}
                      {(step.loadTime || step.size) && (
                        <div className="text-xs text-gray-400 mb-2">
                          <span className="font-medium">Performance: </span>
                          {step.loadTime && <span>Load: {step.loadTime}ms </span>}
                          {step.size && <span>Size: {(step.size / 1024).toFixed(1)}KB</span>}
                        </div>
                      )}
                      
                      {/* Show element details if available */}
                      {elementDetails && (
                        <div className="text-xs text-gray-500">
                          <details className="cursor-pointer">
                            <summary className="hover:text-gray-400">Element Details</summary>
                            <div className="mt-1 ml-3 space-y-1">
                              {elementDetails.tag && <div>Tag: {elementDetails.tag}</div>}
                              {elementDetails.text && (
                                <div>
                                  <div>Full Text: "{elementDetails.text}"</div>
                                  {elementDetails.displayText && elementDetails.displayText !== elementDetails.text && (
                                    <div className="text-gray-600">Display Text: "{elementDetails.displayText}"</div>
                                  )}
                                </div>
                              )}
                              {elementDetails.href && <div>URL: {elementDetails.href}</div>}
                              {elementDetails.type && <div>Type: {elementDetails.type}</div>}
                              {elementDetails.id && <div>ID: {elementDetails.id}</div>}
                              {elementDetails.className && <div>Class: {elementDetails.className}</div>}
                              {elementDetails.willNavigate && <div>Triggers Navigation: Yes</div>}
                              {step.pageUrl && (
                                <div>
                                  <div>Page URL: {step.pageUrl}</div>
                                  {step.pageTitle && step.pageTitle !== 'Untitled' && (
                                    <div>Page Title: {step.pageTitle}</div>
                                  )}
                                </div>
                              )}
                            </div>
                          </details>
                        </div>
                      )}
                      
                      {/* Show full URL for navigation steps */}
                      {step.type === 'url' && step.value.length > 60 && (
                        <div className="text-xs text-gray-500 mt-1">
                          <details className="cursor-pointer">
                            <summary className="hover:text-gray-400">Full URL</summary>
                            <div className="mt-1 break-all font-mono">{step.value}</div>
                          </details>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          
          {/* Journey Summary */}
          {steps.length > 1 && (
            <div className="mt-4 p-3 bg-gray-800 rounded">
              <h4 className="text-sm font-semibold mb-2 text-gray-300">Journey Summary</h4>
              <div className="text-xs text-gray-400 space-y-1">
                <div>Total Steps: {steps.length}</div>
                <div>Duration: {((steps[steps.length - 1].timestamp - steps[0].timestamp) / 1000).toFixed(1)}s</div>
                <div>Average Time Between Steps: {((steps[steps.length - 1].timestamp - steps[0].timestamp) / (steps.length - 1) / 1000).toFixed(1)}s</div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
