import { useState, useEffect, useRef } from 'react';
import { AlertTriangle, Copy, Download, FileText, RefreshCw, Trash2, Eye, ChevronDown, ChevronRight, Camera, Plus, X, Pen, Undo, Palette, Save, Image as ImageIcon, Paperclip } from 'lucide-react';

interface ErrorContext {
  id: string;
  type: 'javascript' | 'network' | 'unhandled-promise' | 'console-error' | 'console-warning';
  message: string;
  stack?: string;
  url?: string;
  lineNumber?: number;
  columnNumber?: number;
  source?: string;
  timestamp: number;
  userAgent: string;
  pageUrl: string;
  networkDetails?: {
    method: string;
    status: number;
    statusText: string;
    responseText: string;
  };
  // Enhanced debugging context
  userJourney?: JourneyStep[];
  networkContext?: NetworkRequest[];
  reproductionSteps?: string[];
  environmentInfo?: {
    viewport: string;
    cookiesEnabled: boolean;
    onlineStatus: boolean;
    referrer: string;
  };
  // Associated screenshots
  associatedScreenshots?: string[]; // Array of screenshot IDs
}

interface JourneyStep {
  type: 'click' | 'url' | 'input' | 'scroll' | 'focus';
  value: string;
  timestamp: number;
  element?: string;
}

interface NetworkRequest {
  method: string;
  url: string;
  status: number;
  statusText: string;
  duration: number;
  timestamp: number;
  requestBody?: string;
  responseBody?: string;
}

interface ErrorContextTabProps {
  tabId: number | null;
}

export function ErrorContextTab({ tabId }: ErrorContextTabProps) {
  const [errors, setErrors] = useState<ErrorContext[]>([]);
  const [selectedError, setSelectedError] = useState<ErrorContext | null>(null);
  const [selectedManualLog, setSelectedManualLog] = useState<ManualLog | null>(null);
  const [selectedItemType, setSelectedItemType] = useState<'error' | 'manual' | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [jsonViewerData, setJsonViewerData] = useState<{ data: any; title: string } | null>(null);
  const [expandedKeys, setExpandedKeys] = useState<Set<string>>(new Set());
  const [isCapturingScreenshot, setIsCapturingScreenshot] = useState(false);
  const [screenshots, setScreenshots] = useState<Array<{ id: string; dataUrl: string; timestamp: number; title: string }>>([]);
  const [viewingScreenshot, setViewingScreenshot] = useState<{ id: string; dataUrl: string; timestamp: number; title: string } | null>(null);
  const [isScreenshotsExpanded, setIsScreenshotsExpanded] = useState(false);
  const [isErrorsExpanded, setIsErrorsExpanded] = useState(false);
  const [isManualLogsExpanded, setIsManualLogsExpanded] = useState(false);
  const [manualLogs, setManualLogs] = useState<ManualLog[]>([]);
  const [showAddLogModal, setShowAddLogModal] = useState(false);
  const [newLogData, setNewLogData] = useState({ message: '', note: '', severity: 'info' as 'info' | 'warning' | 'critical' });

  // Screenshot association state
  const [showScreenshotAssociation, setShowScreenshotAssociation] = useState(false);
  const [associationTarget, setAssociationTarget] = useState<{ type: 'error' | 'manual', id: string } | null>(null);

  // Annotation state
  const [isAnnotating, setIsAnnotating] = useState(false);
  const [penColor, setPenColor] = useState('#ff0000');
  const [penSize, setPenSize] = useState(3);
  const [annotationHistory, setAnnotationHistory] = useState<ImageData[]>([]);
  const [annotationHistoryIndex, setAnnotationHistoryIndex] = useState(-1);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [lastPosition, setLastPosition] = useState<{ x: number; y: number } | null>(null);

  // Check if chrome APIs are available
  const isChromeApiAvailable = typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage;

  useEffect(() => {
    loadErrors();
    const interval = setInterval(loadErrors, 2000); // Refresh every 2 seconds
    return () => clearInterval(interval);
  }, [tabId]);

  // Ensure screenshots list is closed when no screenshots exist
  useEffect(() => {
    if (screenshots.length === 0 && isScreenshotsExpanded) {
      setIsScreenshotsExpanded(false);
    }
  }, [screenshots.length, isScreenshotsExpanded]);

  // Ensure errors list is closed when no errors exist
  useEffect(() => {
    if (errors.length === 0 && isErrorsExpanded) {
      setIsErrorsExpanded(false);
    }
  }, [errors.length, isErrorsExpanded]);

  // Ensure manual logs list is closed when no manual logs exist
  useEffect(() => {
    if (manualLogs.length === 0 && isManualLogsExpanded) {
      setIsManualLogsExpanded(false);
    }
  }, [manualLogs.length, isManualLogsExpanded]);

  const loadErrors = async () => {
    if (!tabId || !isChromeApiAvailable) return;
    
    try {
      const response = await chrome.runtime.sendMessage({
        type: 'GET_ERROR_CONTEXT',
        tabId: tabId
      });
      
      if (response && response.errors) {
        // Get shared journey and network data once
        let allJourneySteps: JourneyStep[] = [];
        let allNetworkRequests: NetworkRequest[] = [];
        
        try {
          const journeyResponse = await chrome.runtime.sendMessage({
            type: 'GET_JOURNEY',
            tabId: tabId
          }).catch(() => ({ steps: [] }));
          
          const networkResponse = await chrome.runtime.sendMessage({
            type: 'GET_NETWORK_DATA',
            tabId: tabId
          }).catch(() => ({ networkRequests: [] }));
          
          allJourneySteps = journeyResponse?.steps || [];
          allNetworkRequests = networkResponse?.networkRequests || [];
        } catch (error) {
          console.warn('Failed to get journey or network data:', error);
        }

        // Enhance errors with context isolated to each error's timestamp
        const enhancedErrors = response.errors.map((error: ErrorContext) => {
          try {
            // Filter journey steps to only include those BEFORE this error occurred
            const errorTimestamp = error.timestamp || Date.now();
            const relevantJourneySteps = allJourneySteps.filter(step => {
              const stepTimestamp = step.timestamp || 0;
              return stepTimestamp > 0 && stepTimestamp < errorTimestamp;
            }).slice(-20); // Last 20 actions before this error
            
            // Filter network requests to only include those BEFORE this error occurred
            const relevantNetworkRequests = allNetworkRequests.filter(request => {
              const requestTimestamp = request.timestamp || 0;
              return requestTimestamp > 0 && requestTimestamp < errorTimestamp;
            }).slice(-10); // Last 10 requests before this error
            
            return {
              ...error,
              userJourney: relevantJourneySteps,
              networkContext: relevantNetworkRequests,
              reproductionSteps: generateReproductionSteps(error, relevantJourneySteps)
            };
          } catch (enhanceError) {
            console.warn('Failed to enhance error context:', enhanceError);
            // Return error with minimal enhancement
            return {
              ...error,
              userJourney: [],
              networkContext: [],
              reproductionSteps: generateReproductionSteps(error, [])
            };
          }
        });
        
        setErrors(enhancedErrors);
      }
    } catch (error) {
      console.error('Failed to load error context:', error);
      // Set empty array on failure to prevent infinite loading
      setErrors([]);
    }
  };

  const generateReproductionSteps = (error: ErrorContext, journey: JourneyStep[]): string[] => {
    const steps: string[] = [];
    let stepNumber = 1;
    
    // Add initial page load
    steps.push(`${stepNumber}. Open browser and navigate to: ${error.pageUrl}`);
    stepNumber++;
    
    // Sort journey by timestamp to ensure correct sequence
    const sortedJourney = [...journey].sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));
    
    // Filter and process journey steps in chronological order
    const meaningfulSteps: string[] = [];
    let lastMeaningfulUrl = error.pageUrl;
    
    // Patterns to ignore (automatic redirects/system navigation)
    const ignoredPatterns = [
      '/auth/',
      '/login',
      '/logout',
      'guest',
      'redirect',
      'sso'
    ];
    
    sortedJourney.forEach((step, index) => {
      let shouldAdd = false;
      let stepText = '';
      
      switch (step.type) {
        case 'url':
          // Skip automatic auth/system redirects and very similar URLs
          const isIgnoredUrl = ignoredPatterns.some(pattern => step.value.toLowerCase().includes(pattern));
          const isRootNavigation = step.value.endsWith('/') && step.value.split('/').length <= 4;
          const isSameBasePath = lastMeaningfulUrl && step.value.includes(lastMeaningfulUrl.split('/').slice(0, 5).join('/'));
          
          if (!isIgnoredUrl && !isRootNavigation && !isSameBasePath && 
              step.value !== lastMeaningfulUrl && 
              !step.value.includes('#') && 
              step.value.length < 150) {
            
            try {
              const url = new URL(step.value);
              const pathParts = url.pathname.split('/').filter(part => part.length > 0);
              
              // Show navigation change with more context
              if (pathParts.length >= 1) {
                const shortPath = url.pathname + (url.search ? url.search : '');
                stepText = `Navigate to: ${shortPath}`;
                
                // Check if previous step was a click that might have caused this navigation
                if (index > 0 && sortedJourney[index - 1].type === 'click') {
                  const timeDiff = (step.timestamp || 0) - (sortedJourney[index - 1].timestamp || 0);
                  if (timeDiff < 2000) { // Within 2 seconds
                    stepText += ` (from previous click)`;
                  }
                }
                
                lastMeaningfulUrl = step.value;
                shouldAdd = true;
              }
            } catch {
              // Invalid URL, skip
            }
          }
          break;
        case 'click':
          // Only add clicks on buttons and links
          if (step.value.includes('Clicked button:') || step.value.includes('Clicked link:') || step.value.includes('Clicked:')) {
            stepText = step.value;
            shouldAdd = true;
          }
          break;
        case 'input':
          // Only add meaningful input events
          if (step.value.includes('Entered') && !step.value.includes('undefined')) {
            stepText = step.value;
            shouldAdd = true;
          }
          break;
        // Skip focus and scroll events
      }
      
      // Avoid duplicates but preserve sequence
      if (shouldAdd && stepText && !meaningfulSteps.some(existing => existing === stepText)) {
        meaningfulSteps.push(stepText);
      }
    });
    
    // Add meaningful steps with proper numbering (maintaining chronological order)
    meaningfulSteps.forEach((stepText) => {
      steps.push(`${stepNumber}. ${stepText}`);
      stepNumber++;
    });
    
    // Add error occurrence
    steps.push(`${stepNumber}. Error occurred: ${error.message}`);
    
    return steps;
  };

  // Helper function to generate reproduction steps for manual logs
  const generateManualLogReproductionSteps = (pageUrl: string, message: string, journey: JourneyStep[]): string[] => {
    const steps: string[] = [];
    let stepNumber = 1;
    
    // Add initial page load
    steps.push(`${stepNumber}. Open browser and navigate to: ${pageUrl}`);
    stepNumber++;
    
    // Sort journey by timestamp to ensure correct sequence
    const sortedJourney = [...journey].sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));
    
    // Filter and process journey steps in chronological order
    const meaningfulSteps: string[] = [];
    let lastMeaningfulUrl = pageUrl;
    
    // Patterns to ignore (automatic redirects/system navigation)
    const ignoredPatterns = [
      '/auth/', '/login', '/logout', 'guest', 'redirect', 'sso'
    ];
    
    sortedJourney.forEach((step, index) => {
      let shouldAdd = false;
      let stepText = '';
      
      switch (step.type) {
        case 'url':
          // Skip automatic auth/system redirects and very similar URLs
          const isIgnoredUrl = ignoredPatterns.some(pattern => step.value.toLowerCase().includes(pattern));
          const isRootNavigation = step.value.endsWith('/') && step.value.split('/').length <= 4;
          const isSameBasePath = lastMeaningfulUrl && step.value.includes(lastMeaningfulUrl.split('/').slice(0, 5).join('/'));
          
          if (!isIgnoredUrl && !isRootNavigation && !isSameBasePath && 
              step.value &&
              !step.value.includes('#') && 
              step.value.length < 150) {
            
            try {
              const url = new URL(step.value);
              const pathParts = url.pathname.split('/').filter(part => part.length > 0);
              
              // Show navigation change with more context
              if (pathParts.length >= 1) {
                const shortPath = url.pathname + (url.search ? url.search : '');
                stepText = `Navigate to: ${shortPath}`;
                
                // Check if previous step was a click that might have caused this navigation
                if (index > 0 && sortedJourney[index - 1].type === 'click') {
                  const timeDiff = (step.timestamp || 0) - (sortedJourney[index - 1].timestamp || 0);
                  if (timeDiff < 2000) { // Within 2 seconds
                    stepText += ` (from previous click)`;
                  }
                }
                
                lastMeaningfulUrl = step.value;
                shouldAdd = true;
              }
            } catch {
              // Invalid URL, skip
            }
          }
          break;
        case 'click':
          // Only add clicks on buttons and links
          if (step.value.includes('Clicked button:') || step.value.includes('Clicked link:') || step.value.includes('Clicked:')) {
            stepText = step.value;
            shouldAdd = true;
          }
          break;
        case 'input':
          // Only add meaningful input events
          if (step.value.includes('Entered') && !step.value.includes('undefined')) {
            stepText = step.value;
            shouldAdd = true;
          }
          break;
        // Skip focus and scroll events
      }
      
      // Avoid duplicates but preserve sequence
      if (shouldAdd && stepText && !meaningfulSteps.some(existing => existing === stepText)) {
        meaningfulSteps.push(stepText);
      }
    });
    
    // Add meaningful steps with proper numbering (maintaining chronological order)
    meaningfulSteps.forEach((stepText) => {
      steps.push(`${stepNumber}. ${stepText}`);
      stepNumber++;
    });
    
    // Add the manual log observation
    steps.push(`${stepNumber}. Observed issue: ${message}`);
    
    return steps;
  };

  // Manual logging functions
  const addManualLog = async () => {
    if (!newLogData.message.trim()) return;
    
    const timestamp = Date.now();
    let userJourney: JourneyStep[] = [];
    let networkContext: NetworkRequest[] = [];
    let pageUrl = '';
    let userAgent = '';
    let environmentInfo = undefined;
    
    // Collect context data similar to error logging
    if (tabId && isChromeApiAvailable) {
      try {
        // Get journey data
        const journeyResponse = await chrome.runtime.sendMessage({
          type: 'GET_JOURNEY',
          tabId: tabId
        }).catch(() => ({ steps: [] }));
        
        // Get network data
        const networkResponse = await chrome.runtime.sendMessage({
          type: 'GET_NETWORK_DATA',
          tabId: tabId
        }).catch(() => ({ networkRequests: [] }));
        
        // Get current page URL and user agent
        try {
          const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
          if (tabs[0]) {
            pageUrl = tabs[0].url || '';
            userAgent = navigator.userAgent;
          }
        } catch (error) {
          console.warn('Failed to get tab info:', error);
        }
        
        // Filter journey and network data to last 20 actions/requests before this log
        const allJourneySteps = journeyResponse?.steps || [];
        const allNetworkRequests = networkResponse?.networkRequests || [];
        
        userJourney = allJourneySteps.filter((step: JourneyStep) => {
          const stepTimestamp = step.timestamp || 0;
          return stepTimestamp > 0 && stepTimestamp < timestamp;
        }).slice(-20); // Last 20 actions before this log
        
        networkContext = allNetworkRequests.filter((request: NetworkRequest) => {
          const requestTimestamp = request.timestamp || 0;
          return requestTimestamp > 0 && requestTimestamp < timestamp;
        }).slice(-10); // Last 10 requests before this log
        
        // Get environment info
        try {
          environmentInfo = {
            viewport: `${window.innerWidth}x${window.innerHeight}`,
            cookiesEnabled: navigator.cookieEnabled,
            onlineStatus: navigator.onLine,
            referrer: document.referrer
          };
        } catch (error) {
          console.warn('Failed to get environment info:', error);
        }
        
      } catch (error) {
        console.warn('Failed to collect context for manual log:', error);
      }
    }
    
    // Generate reproduction steps
    const reproductionSteps = generateManualLogReproductionSteps(
      pageUrl || window.location.href, 
      newLogData.message, 
      userJourney
    );
    
    const log: ManualLog = {
      id: `manual-log-${timestamp}`,
      message: newLogData.message,
      note: newLogData.note,
      timestamp: timestamp,
      severity: newLogData.severity,
      pageUrl: pageUrl || window.location.href,
      userAgent: userAgent || navigator.userAgent,
      userJourney: userJourney.length > 0 ? userJourney : undefined,
      networkContext: networkContext.length > 0 ? networkContext : undefined,
      reproductionSteps: reproductionSteps,
      environmentInfo: environmentInfo
    };
    
    setManualLogs(prev => [log, ...prev]);
    setNewLogData({ message: '', note: '', severity: 'info' });
    setShowAddLogModal(false);
  };

  const deleteManualLog = (id: string) => {
    setManualLogs(prev => {
      const newLogs = prev.filter(log => log.id !== id);
      // If no manual logs left, close the list
      if (newLogs.length === 0) {
        setIsManualLogsExpanded(false);
      }
      return newLogs;
    });
  };

  const deleteError = (id: string) => {
    setErrors(prev => {
      const newErrors = prev.filter(error => error.id !== id);
      // If no errors left, close the list
      if (newErrors.length === 0) {
        setIsErrorsExpanded(false);
      }
      return newErrors;
    });
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'info': return 'text-blue-400';
      case 'warning': return 'text-yellow-400';
      case 'critical': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getSeverityBg = (severity: string) => {
    switch (severity) {
      case 'info': return 'bg-blue-900';
      case 'warning': return 'bg-yellow-900';
      case 'critical': return 'bg-red-900';
      default: return 'bg-gray-900';
    }
  };

  // Format manual log for copying
  const formatManualLogForCopy = (log: ManualLog): string => {
    let text = `MANUAL DEBUG LOG REPORT\n`;
    text += `========================\n\n`;
    
    text += `Severity: ${log.severity.toUpperCase()}\n`;
    text += `Issue: ${log.message}\n`;
    text += `Page URL: ${log.pageUrl}\n`;
    text += `Timestamp: ${new Date(log.timestamp).toLocaleString()}\n`;
    text += `User Agent: ${log.userAgent}\n\n`;
    
    if (log.note) {
      text += `DETAILED NOTES:\n${log.note}\n\n`;
    }
    
    // Environment Info
    if (log.environmentInfo) {
      text += `ENVIRONMENT INFO:\n`;
      text += `Viewport: ${log.environmentInfo.viewport}\n`;
      text += `Cookies Enabled: ${log.environmentInfo.cookiesEnabled}\n`;
      text += `Online Status: ${log.environmentInfo.onlineStatus}\n`;
      text += `Referrer: ${log.environmentInfo.referrer}\n\n`;
    }
    
    // Reproduction Steps
    if (log.reproductionSteps && log.reproductionSteps.length > 0) {
      text += `REPRODUCTION STEPS:\n`;
      log.reproductionSteps.forEach(step => {
        text += `${step}\n`;
      });
      text += `\n`;
    }
    
    // User Journey
    if (log.userJourney && log.userJourney.length > 0) {
      text += `USER JOURNEY (Last 20 actions):\n`;
      log.userJourney.forEach((step, index) => {
        const timeAgo = Math.round((log.timestamp - step.timestamp) / 1000);
        text += `${index + 1}. [${timeAgo}s ago] ${step.type.toUpperCase()}: ${step.value}\n`;
      });
      text += `\n`;
    }
    
    // Network Context
    if (log.networkContext && log.networkContext.length > 0) {
      text += `NETWORK CONTEXT (Recent API requests):\n`;
      log.networkContext.forEach((req, index) => {
        const timeAgo = Math.round((log.timestamp - req.timestamp) / 1000);
        text += `${index + 1}. [${timeAgo}s ago] ${req.method} ${req.url} - ${req.status} ${req.statusText} (${req.duration}ms)\n`;
      });
    }
    
    return text;
  };

  // Export manual logs to Word document
  const exportManualLogsToWord = () => {
    if (manualLogs.length === 0) return;
    
    try {
      let htmlContent = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
        <head>
          <meta charset="utf-8">
          <title>Manual Debug Logs Report</title>
          <!--[if gte mso 9]>
          <xml>
            <w:WordDocument>
              <w:View>Print</w:View>
              <w:Zoom>90</w:Zoom>
              <w:DoNotPromptForConvert/>
              <w:DoNotShowRevisions/>
              <w:DoNotPrintRevisions/>
            </w:WordDocument>
          </xml>
          <![endif]-->
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
            .header { background-color: #f8f9fa; padding: 20px; border-left: 4px solid #28a745; margin-bottom: 30px; }
            .log-item { border: 1px solid #ddd; margin-bottom: 30px; padding: 20px; border-radius: 8px; page-break-inside: avoid; }
            .log-header { font-weight: bold; margin-bottom: 15px; font-size: 18px; }
            .severity-info { color: #17a2b8; }
            .severity-warning { color: #ffc107; }
            .severity-critical { color: #dc3545; }
            .section { margin-bottom: 20px; }
            .section-title { font-weight: bold; color: #333; margin-bottom: 10px; font-size: 14px; text-transform: uppercase; }
            .field { margin-bottom: 8px; }
            .field-label { font-weight: bold; display: inline-block; width: 120px; }
            .field-value { font-family: monospace; background-color: #f8f9fa; padding: 2px 4px; }
            .notes { background-color: #f8f9fa; padding: 15px; font-family: monospace; font-size: 11px; white-space: pre-wrap; border-radius: 5px; margin-top: 10px; }
            .steps-list { background-color: #f8f9fa; padding: 15px; border-radius: 5px; }
            .steps-list ol { margin: 0; padding-left: 20px; }
            .steps-list li { margin-bottom: 5px; }
            .journey-item { background-color: #fff3cd; padding: 8px; margin-bottom: 5px; border-radius: 3px; font-size: 12px; }
            .network-item { background-color: #d1ecf1; padding: 8px; margin-bottom: 5px; border-radius: 3px; font-size: 12px; }
            table { width: 100%; border-collapse: collapse; margin-top: 10px; }
            th, td { border: 1px solid #ddd; padding: 12px; text-align: left; vertical-align: top; }
            th { background-color: #f8f9fa; font-weight: bold; }
            .url-cell { word-break: break-all; max-width: 300px; }
            .summary-stats { background-color: #e8f5e8; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Manual Debug Logs Report</h1>
            <p><strong>Generated on:</strong> ${new Date().toLocaleString()}</p>
            <p><strong>Total Manual Logs:</strong> ${manualLogs.length}</p>
            <div class="summary-stats">
              <strong>Summary:</strong> This report contains manual debug observations and issues logged by the user, including reproduction steps, user journey, and network context for effective debugging.
            </div>
          </div>
    `;

    manualLogs.forEach((log, index) => {
      const severityClass = `severity-${log.severity}`;
      htmlContent += `
        <div class="log-item">
          <div class="log-header ${severityClass}">Manual Log #${index + 1} - ${log.severity.toUpperCase()}</div>
          
          <div class="section">
            <div class="section-title">Basic Information</div>
            <table>
              <tr><th>Field</th><th>Value</th></tr>
              <tr><td>Issue/Observation</td><td>${log.message}</td></tr>
              <tr><td>Page URL</td><td class="url-cell">${log.pageUrl}</td></tr>
              <tr><td>Timestamp</td><td>${new Date(log.timestamp).toLocaleString()}</td></tr>
              <tr><td>User Agent</td><td class="url-cell">${log.userAgent}</td></tr>
              <tr><td>Severity</td><td class="${severityClass}">${log.severity.toUpperCase()}</td></tr>
            </table>
          </div>
      `;
      
      if (log.note) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Detailed Notes</div>
            <div class="notes">${log.note}</div>
          </div>
        `;
      }
      
      // Environment Info
      if (log.environmentInfo) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Environment Context</div>
            <table>
              <tr><td>Viewport</td><td>${log.environmentInfo.viewport}</td></tr>
              <tr><td>Cookies Enabled</td><td>${log.environmentInfo.cookiesEnabled}</td></tr>
              <tr><td>Online Status</td><td>${log.environmentInfo.onlineStatus}</td></tr>
              <tr><td>Referrer</td><td class="url-cell">${log.environmentInfo.referrer}</td></tr>
            </table>
          </div>
        `;
      }
      
      // Reproduction Steps
      if (log.reproductionSteps && log.reproductionSteps.length > 0) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Auto-Generated Reproduction Steps</div>
            <div class="steps-list">
              <ol>
        `;
        log.reproductionSteps.forEach(step => {
          htmlContent += `<li>${step}</li>`;
        });
        htmlContent += `
              </ol>
            </div>
          </div>
        `;
      }
      
      // User Journey
      if (log.userJourney && log.userJourney.length > 0) {
        htmlContent += `
          <div class="section">
            <div class="section-title">User Journey (Last ${log.userJourney.length} Actions)</div>
        `;
        log.userJourney.forEach((step, stepIndex) => {
          const timeAgo = Math.round((log.timestamp - step.timestamp) / 1000);
          htmlContent += `
            <div class="journey-item">
              <strong>${stepIndex + 1}.</strong> [${timeAgo}s ago] <strong>${step.type.toUpperCase()}:</strong> ${step.value}
              ${step.element ? `<br><em>Element: ${step.element}</em>` : ''}
            </div>
          `;
        });
        htmlContent += `</div>`;
      }
      
      // Network Context
      if (log.networkContext && log.networkContext.length > 0) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Network Context (Recent API Requests)</div>
        `;
        log.networkContext.forEach((req, reqIndex) => {
          const timeAgo = Math.round((log.timestamp - req.timestamp) / 1000);
          htmlContent += `
            <div class="network-item">
              <strong>${reqIndex + 1}.</strong> [${timeAgo}s ago] <strong>${req.method}</strong> ${req.url}<br>
              <em>Status: ${req.status} ${req.statusText} (${req.duration}ms)</em>
            </div>
          `;
        });
        htmlContent += `</div>`;
      }
      
      // Associated Screenshots
      if (log.associatedScreenshots && log.associatedScreenshots.length > 0) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Associated Screenshots (${log.associatedScreenshots.length})</div>
        `;
        log.associatedScreenshots.forEach((screenshotId, screenshotIndex) => {
          const screenshot = screenshots.find(s => s.id === screenshotId);
          if (screenshot) {
            htmlContent += `
              <div class="screenshot-item" style="margin-bottom: 20px; padding: 15px; border: 1px solid #ddd; border-radius: 8px; background-color: #fafafa; page-break-inside: avoid;">
                <div style="font-weight: bold; margin-bottom: 8px; color: #333; font-size: 14px;">Screenshot #${screenshotIndex + 1}: ${screenshot.title}</div>
                <div style="font-size: 12px; color: #666; margin-bottom: 15px;">Captured: ${new Date(screenshot.timestamp).toLocaleString()}</div>
                <div style="text-align: center; margin: 0 auto; width: 100%; max-width: 280px;">
                  <img src="${screenshot.dataUrl}" style="max-width: 100%; width: auto; height: auto; max-height: 196px; border: 2px solid #ccc; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); display: block; margin: 0 auto; object-fit: scale-down; background-color: #f8f9fa;" />
                </div>
              </div>
            `;
          }
        });
        htmlContent += `</div>`;
      }
      
      htmlContent += `</div>`;
    });

    htmlContent += `
        </body>
      </html>
    `;

    const blob = new Blob([htmlContent], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `manual-debug-logs-${new Date().toISOString().split('T')[0]}.doc`;
    link.click();
    URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Failed to export manual logs to Word:', error);
      alert('Failed to export manual logs to Word document. Please try again.');
    }
  };

  const clearErrors = async () => {
    if (!tabId || !isChromeApiAvailable) return;
    
    try {
      // Clear errors
      await chrome.runtime.sendMessage({
        type: 'CLEAR_ERROR_CONTEXT',
        tabId: tabId
      });
      
      // Also clear journey history to prevent bleed into future errors
      await chrome.runtime.sendMessage({
        type: 'CLEAR_JOURNEY',
        tabId: tabId
      });
      
      // Clear network data as well
      await chrome.runtime.sendMessage({
        type: 'CLEAR_NETWORK_DATA',
        tabId: tabId
      });
      
      setErrors([]);
      setSelectedError(null);
    } catch (error) {
      console.error('Failed to clear errors:', error);
    }
  };

  const refreshErrors = async () => {
    setIsLoading(true);
    await loadErrors();
    setIsLoading(false);
  };

  const copyToClipboard = async (error: ErrorContext) => {
    const formattedError = formatErrorForCopy(error);
    
    // Create a larger, more visible textarea with the content
    const textarea = document.createElement('textarea');
    textarea.value = formattedError;
    textarea.style.position = 'fixed';
    textarea.style.top = '50%';
    textarea.style.left = '50%';
    textarea.style.transform = 'translate(-50%, -50%)';
    textarea.style.width = '80vw';
    textarea.style.height = '70vh';
    textarea.style.maxWidth = '800px';
    textarea.style.maxHeight = '600px';
    textarea.style.minWidth = '500px';
    textarea.style.minHeight = '400px';
    textarea.style.zIndex = '10000';
    textarea.style.background = '#1f2937';
    textarea.style.color = '#e5e7eb';
    textarea.style.border = '2px solid #60a5fa';
    textarea.style.borderRadius = '8px';
    textarea.style.padding = '16px';
    textarea.style.fontSize = '14px';
    textarea.style.fontFamily = 'Consolas, Monaco, "Courier New", monospace';
    textarea.style.boxShadow = '0 20px 50px rgba(0, 0, 0, 0.8)';
    textarea.readOnly = true;
    textarea.style.resize = 'both';
    textarea.style.overflow = 'auto';
    
    // Create overlay background
    const overlay = document.createElement('div');
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.background = 'rgba(0, 0, 0, 0.8)';
    overlay.style.zIndex = '9999';
    
    document.body.appendChild(overlay);
    document.body.appendChild(textarea);
    textarea.focus();
    textarea.select();
    
    // Try to copy automatically
    try {
      document.execCommand('copy');
    } catch {
      // Silent failure - user can copy manually
    }
    
    // Remove elements when user clicks outside or presses escape
    const cleanup = () => {
      if (document.body.contains(textarea)) {
        document.body.removeChild(textarea);
      }
      if (document.body.contains(overlay)) {
        document.body.removeChild(overlay);
      }
      document.removeEventListener('click', cleanup);
      document.removeEventListener('keydown', escapeHandler);
    };
    
    const escapeHandler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        cleanup();
      }
    };
    
    // Close when clicking on overlay (but not textarea)
    overlay.addEventListener('click', cleanup);
    
    // Prevent clicks on the textarea from closing the modal
    textarea.addEventListener('click', (e) => {
      e.stopPropagation();
    });
    
    // Add keyboard listener
    document.addEventListener('keydown', escapeHandler);
  };

  // Copy manual log to clipboard with large textarea overlay
  const copyManualLogToClipboard = async (log: ManualLog) => {
    const logText = formatManualLogForCopy(log);
    
    // Create a larger, more visible textarea with the content
    const textarea = document.createElement('textarea');
    textarea.value = logText;
    textarea.style.position = 'fixed';
    textarea.style.top = '50%';
    textarea.style.left = '50%';
    textarea.style.transform = 'translate(-50%, -50%)';
    textarea.style.width = '80vw';
    textarea.style.height = '70vh';
    textarea.style.maxWidth = '800px';
    textarea.style.maxHeight = '600px';
    textarea.style.minWidth = '500px';
    textarea.style.minHeight = '400px';
    textarea.style.zIndex = '10000';
    textarea.style.background = '#1f2937';
    textarea.style.color = '#e5e7eb';
    textarea.style.border = '2px solid #60a5fa';
    textarea.style.borderRadius = '8px';
    textarea.style.padding = '16px';
    textarea.style.fontSize = '14px';
    textarea.style.fontFamily = 'Consolas, Monaco, "Courier New", monospace';
    textarea.style.boxShadow = '0 20px 50px rgba(0, 0, 0, 0.8)';
    textarea.readOnly = true;
    textarea.style.resize = 'both';
    textarea.style.overflow = 'auto';
    
    // Create overlay background
    const overlay = document.createElement('div');
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.background = 'rgba(0, 0, 0, 0.8)';
    overlay.style.zIndex = '9999';
    
    document.body.appendChild(overlay);
    document.body.appendChild(textarea);
    textarea.focus();
    textarea.select();
    
    // Try to copy automatically
    try {
      document.execCommand('copy');
    } catch {
      // Silent failure - user can copy manually
    }
    
    // Remove elements when user clicks outside or presses escape
    const cleanup = () => {
      if (document.body.contains(textarea)) {
        document.body.removeChild(textarea);
      }
      if (document.body.contains(overlay)) {
        document.body.removeChild(overlay);
      }
      document.removeEventListener('click', cleanup);
      document.removeEventListener('keydown', escapeHandler);
    };
    
    const escapeHandler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        cleanup();
      }
    };
    
    // Close when clicking on overlay (but not textarea)
    overlay.addEventListener('click', cleanup);
    
    // Prevent clicks on the textarea from closing the modal
    textarea.addEventListener('click', (e) => {
      e.stopPropagation();
    });
    
    // Add keyboard listener
    document.addEventListener('keydown', escapeHandler);
  };

  const formatErrorForCopy = (error: ErrorContext): string => {
    let text = `ERROR DEBUGGING REPORT\n`;
    text += `========================\n\n`;
    
    text += `Error Type: ${error.type.toUpperCase()}\n`;
    text += `Message: ${error.message}\n`;
    text += `Page URL: ${error.pageUrl}\n`;
    text += `Timestamp: ${new Date(error.timestamp).toLocaleString()}\n`;
    text += `User Agent: ${error.userAgent}\n\n`;
    
    if (error.url) {
      text += `Source URL: ${error.url}\n`;
    }
    
    if (error.lineNumber) {
      text += `Line: ${error.lineNumber}`;
      if (error.columnNumber) {
        text += `, Column: ${error.columnNumber}`;
      }
      text += '\n';
    }
    
    // Environment Info
    if (error.environmentInfo) {
      text += `\nENVIRONMENT INFO:\n`;
      text += `Viewport: ${error.environmentInfo.viewport}\n`;
      text += `Cookies Enabled: ${error.environmentInfo.cookiesEnabled}\n`;
      text += `Online Status: ${error.environmentInfo.onlineStatus}\n`;
      text += `Referrer: ${error.environmentInfo.referrer}\n`;
    }
    
    // Reproduction Steps
    if (error.reproductionSteps && error.reproductionSteps.length > 0) {
      text += `\nREPRODUCTION STEPS:\n`;
      error.reproductionSteps.forEach(step => {
        text += `${step}\n`;
      });
    }
    
    // User Journey
    if (error.userJourney && error.userJourney.length > 0) {
      text += `\nUSER JOURNEY (Last 20 actions):\n`;
      error.userJourney.forEach((step, index) => {
        const timeAgo = Math.round((error.timestamp - step.timestamp) / 1000);
        text += `${index + 1}. [${timeAgo}s ago] ${step.type.toUpperCase()}: ${step.value}\n`;
      });
    }
    
    // Network Context
    if (error.networkContext && error.networkContext.length > 0) {
      text += `\nNETWORK CONTEXT (Recent API requests):\n`;
      error.networkContext.forEach((req, index) => {
        const timeAgo = Math.round((error.timestamp - req.timestamp) / 1000);
        text += `${index + 1}. [${timeAgo}s ago] ${req.method} ${req.url} - ${req.status} ${req.statusText} (${req.duration}ms)\n`;
      });
    }
    
    if (error.stack) {
      text += `\nSTACK TRACE:\n${error.stack}\n`;
    }
    
    if (error.networkDetails) {
      text += `\nNETWORK ERROR DETAILS:\n`;
      text += `Method: ${error.networkDetails.method}\n`;
      text += `Status: ${error.networkDetails.status} ${error.networkDetails.statusText}\n`;
      if (error.networkDetails.responseText) {
        text += `Response: ${error.networkDetails.responseText}\n`;
      }
    }
    
    return text;
  };

  // Export single error to Word document
  const exportSelectedErrorToWord = (error: ErrorContext) => {
    try {
      let htmlContent = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
        <head>
          <meta charset="utf-8">
          <title>Error Debugging Report</title>
          <!--[if gte mso 9]>
          <xml>
            <w:WordDocument>
              <w:View>Print</w:View>
              <w:Zoom>90</w:Zoom>
              <w:DoNotPromptForConvert/>
              <w:DoNotShowRevisions/>
              <w:DoNotPrintRevisions/>
            </w:WordDocument>
          </xml>
          <![endif]-->
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
            .header { background-color: #f8f9fa; padding: 20px; border-left: 4px solid #dc3545; margin-bottom: 30px; }
            .error-item { border: 1px solid #ddd; margin-bottom: 30px; padding: 20px; border-radius: 8px; page-break-inside: avoid; }
            .error-header { font-weight: bold; color: #dc3545; margin-bottom: 15px; font-size: 18px; }
            .section { margin-bottom: 20px; }
            .section-title { font-weight: bold; color: #333; margin-bottom: 10px; font-size: 14px; text-transform: uppercase; }
            .field { margin-bottom: 8px; }
            .field-label { font-weight: bold; display: inline-block; width: 120px; }
            .field-value { font-family: monospace; background-color: #f8f9fa; padding: 2px 4px; }
            .stack-trace { background-color: #f8f9fa; padding: 15px; font-family: monospace; font-size: 11px; white-space: pre-wrap; border-radius: 5px; margin-top: 10px; }
            .steps-list { background-color: #f8f9fa; padding: 15px; border-radius: 5px; }
            .steps-list ol { margin: 0; padding-left: 20px; }
            .steps-list li { margin-bottom: 5px; }
            .journey-item { background-color: #fff3cd; padding: 8px; margin-bottom: 5px; border-radius: 3px; font-size: 12px; }
            .network-item { background-color: #d1ecf1; padding: 8px; margin-bottom: 5px; border-radius: 3px; font-size: 12px; }
            table { width: 100%; border-collapse: collapse; margin-top: 10px; }
            th, td { border: 1px solid #ddd; padding: 12px; text-align: left; vertical-align: top; }
            th { background-color: #f8f9fa; font-weight: bold; }
            .url-cell { word-break: break-all; max-width: 300px; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Error Debugging Report</h1>
            <p><strong>Generated on:</strong> ${new Date().toLocaleString()}</p>
            <p><strong>Error Type:</strong> ${error.type.toUpperCase()}</p>
          </div>
          
          <div class="error-item">
            <div class="error-header">${error.type.toUpperCase()} Error</div>
            
            <div class="section">
              <div class="section-title">Basic Information</div>
              <table>
                <tr><th>Field</th><th>Value</th></tr>
                <tr><td>Message</td><td>${error.message}</td></tr>
                <tr><td>Page URL</td><td class="url-cell">${error.pageUrl}</td></tr>
                <tr><td>Timestamp</td><td>${new Date(error.timestamp).toLocaleString()}</td></tr>
                <tr><td>User Agent</td><td class="url-cell">${error.userAgent}</td></tr>
      `;
      
      if (error.url) {
        htmlContent += `<tr><td>Source URL</td><td class="url-cell">${error.url}</td></tr>`;
      }
      
      if (error.lineNumber) {
        htmlContent += `<tr><td>Line</td><td>${error.lineNumber}</td></tr>`;
      }
      
      if (error.columnNumber) {
        htmlContent += `<tr><td>Column</td><td>${error.columnNumber}</td></tr>`;
      }
      
      htmlContent += `</table></div>`;
      
      // Environment Info
      if (error.environmentInfo) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Environment Context</div>
            <table>
              <tr><td>Viewport</td><td>${error.environmentInfo.viewport}</td></tr>
              <tr><td>Cookies Enabled</td><td>${error.environmentInfo.cookiesEnabled}</td></tr>
              <tr><td>Online Status</td><td>${error.environmentInfo.onlineStatus}</td></tr>
              <tr><td>Referrer</td><td class="url-cell">${error.environmentInfo.referrer}</td></tr>
            </table>
          </div>
        `;
      }
      
      // Reproduction Steps
      if (error.reproductionSteps && error.reproductionSteps.length > 0) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Auto-Generated Reproduction Steps</div>
            <div class="steps-list">
              <ol>
        `;
        error.reproductionSteps.forEach(step => {
          htmlContent += `<li>${step}</li>`;
        });
        htmlContent += `
              </ol>
            </div>
          </div>
        `;
      }
      
      // User Journey
      if (error.userJourney && error.userJourney.length > 0) {
        htmlContent += `
          <div class="section">
            <div class="section-title">User Journey (Last ${error.userJourney.length} Actions)</div>
        `;
        error.userJourney.forEach((step, stepIndex) => {
          const timeAgo = Math.round((error.timestamp - step.timestamp) / 1000);
          htmlContent += `
            <div class="journey-item">
              <strong>${stepIndex + 1}.</strong> [${timeAgo}s ago] <strong>${step.type.toUpperCase()}:</strong> ${step.value}
              ${step.element ? `<br><em>Element: ${step.element}</em>` : ''}
            </div>
          `;
        });
        htmlContent += `</div>`;
      }
      
      // Network Context
      if (error.networkContext && error.networkContext.length > 0) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Network Context (Recent API Requests)</div>
        `;
        error.networkContext.forEach((req, reqIndex) => {
          const timeAgo = Math.round((error.timestamp - req.timestamp) / 1000);
          htmlContent += `
            <div class="network-item">
              <strong>${reqIndex + 1}.</strong> [${timeAgo}s ago] <strong>${req.method}</strong> ${req.url}<br>
              <em>Status: ${req.status} ${req.statusText} (${req.duration}ms)</em>
            </div>
          `;
        });
        htmlContent += `</div>`;
      }
      
      if (error.stack) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Stack Trace</div>
            <div class="stack-trace">${error.stack}</div>
          </div>
        `;
      }
      
      // Network Error Details
      if (error.networkDetails) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Network Error Details</div>
            <table>
              <tr><td>Method</td><td>${error.networkDetails.method}</td></tr>
              <tr><td>Status</td><td>${error.networkDetails.status} ${error.networkDetails.statusText}</td></tr>
        `;
        if (error.networkDetails.responseText) {
          htmlContent += `<tr><td>Response</td><td class="url-cell">${error.networkDetails.responseText}</td></tr>`;
        }
        htmlContent += `</table></div>`;
      }
      
      // Associated Screenshots
      if (error.associatedScreenshots && error.associatedScreenshots.length > 0) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Associated Screenshots (${error.associatedScreenshots.length})</div>
        `;
        error.associatedScreenshots.forEach((screenshotId, screenshotIndex) => {
          const screenshot = screenshots.find(s => s.id === screenshotId);
          if (screenshot) {
            htmlContent += `
              <div class="screenshot-item" style="margin-bottom: 20px; padding: 15px; border: 1px solid #ddd; border-radius: 8px; background-color: #fafafa; page-break-inside: avoid;">
                <div style="font-weight: bold; margin-bottom: 8px; color: #333; font-size: 14px;">Screenshot #${screenshotIndex + 1}: ${screenshot.title}</div>
                <div style="font-size: 12px; color: #666; margin-bottom: 15px;">Captured: ${new Date(screenshot.timestamp).toLocaleString()}</div>
                <div style="text-align: center; margin: 0 auto; width: 100%; max-width: 280px;">
                  <img src="${screenshot.dataUrl}" style="max-width: 100%; width: auto; height: auto; max-height: 196px; border: 2px solid #ccc; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); display: block; margin: 0 auto; object-fit: scale-down; background-color: #f8f9fa;" />
                </div>
              </div>
            `;
          }
        });
        htmlContent += `</div>`;
      }
      
      htmlContent += `
          </div>
        </body>
      </html>
    `;

    const blob = new Blob([htmlContent], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `error-report-${error.type}-${new Date().toISOString().split('T')[0]}.doc`;
    link.click();
    URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Failed to export error to Word document:', error);
      alert('Failed to export error to Word document. Please try again.');
    }
  };

  // Export single manual log to Word document
  const exportSelectedManualLogToWord = (log: ManualLog) => {
    try {
      let htmlContent = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
        <head>
          <meta charset="utf-8">
          <title>Manual Log Report</title>
          <!--[if gte mso 9]>
          <xml>
            <w:WordDocument>
              <w:View>Print</w:View>
              <w:Zoom>90</w:Zoom>
              <w:DoNotPromptForConvert/>
              <w:DoNotShowRevisions/>
              <w:DoNotPrintRevisions/>
            </w:WordDocument>
          </xml>
          <![endif]-->
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
            .header { background-color: #f8f9fa; padding: 20px; border-left: 4px solid #28a745; margin-bottom: 30px; }
            .log-item { border: 1px solid #ddd; margin-bottom: 30px; padding: 20px; border-radius: 8px; page-break-inside: avoid; }
            .log-header { font-weight: bold; color: #28a745; margin-bottom: 15px; font-size: 18px; }
            .section { margin-bottom: 20px; }
            .section-title { font-weight: bold; color: #333; margin-bottom: 10px; font-size: 14px; text-transform: uppercase; }
            .field { margin-bottom: 8px; }
            .field-label { font-weight: bold; display: inline-block; width: 120px; }
            .field-value { font-family: monospace; background-color: #f8f9fa; padding: 2px 4px; }
            .steps-list { background-color: #f8f9fa; padding: 15px; border-radius: 5px; }
            .steps-list ol { margin: 0; padding-left: 20px; }
            .steps-list li { margin-bottom: 5px; }
            .journey-item { background-color: #fff3cd; padding: 8px; margin-bottom: 5px; border-radius: 3px; font-size: 12px; }
            .network-item { background-color: #d1ecf1; padding: 8px; margin-bottom: 5px; border-radius: 3px; font-size: 12px; }
            table { width: 100%; border-collapse: collapse; margin-top: 10px; }
            th, td { border: 1px solid #ddd; padding: 12px; text-align: left; vertical-align: top; }
            th { background-color: #f8f9fa; font-weight: bold; }
            .url-cell { word-break: break-all; max-width: 300px; }
            .severity-critical { color: #dc3545; font-weight: bold; }
            .severity-warning { color: #fd7e14; font-weight: bold; }
            .severity-info { color: #17a2b8; font-weight: bold; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Manual Log Report</h1>
            <p><strong>Generated on:</strong> ${new Date().toLocaleString()}</p>
            <p><strong>Severity:</strong> <span class="severity-${log.severity}">${log.severity.toUpperCase()}</span></p>
          </div>
          
          <div class="log-item">
            <div class="log-header">Manual Log - ${log.severity.toUpperCase()}</div>
            
            <div class="section">
              <div class="section-title">Log Information</div>
              <table>
                <tr><th>Field</th><th>Value</th></tr>
                <tr><td>Message</td><td>${log.message}</td></tr>
                <tr><td>Note</td><td>${log.note}</td></tr>
                <tr><td>Severity</td><td class="severity-${log.severity}">${log.severity.toUpperCase()}</td></tr>
                <tr><td>Page URL</td><td class="url-cell">${log.pageUrl}</td></tr>
                <tr><td>Timestamp</td><td>${new Date(log.timestamp).toLocaleString()}</td></tr>
                <tr><td>User Agent</td><td class="url-cell">${log.userAgent}</td></tr>
              </table>
            </div>
      `;
      
      // Environment Info
      if (log.environmentInfo) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Environment Context</div>
            <table>
              <tr><td>Viewport</td><td>${log.environmentInfo.viewport}</td></tr>
              <tr><td>Cookies Enabled</td><td>${log.environmentInfo.cookiesEnabled}</td></tr>
              <tr><td>Online Status</td><td>${log.environmentInfo.onlineStatus}</td></tr>
              <tr><td>Referrer</td><td class="url-cell">${log.environmentInfo.referrer}</td></tr>
            </table>
          </div>
        `;
      }
      
      // Reproduction Steps
      if (log.reproductionSteps && log.reproductionSteps.length > 0) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Reproduction Steps</div>
            <div class="steps-list">
              <ol>
        `;
        log.reproductionSteps.forEach(step => {
          htmlContent += `<li>${step}</li>`;
        });
        htmlContent += `
              </ol>
            </div>
          </div>
        `;
      }
      
      // User Journey
      if (log.userJourney && log.userJourney.length > 0) {
        htmlContent += `
          <div class="section">
            <div class="section-title">User Journey (Last ${log.userJourney.length} Actions)</div>
        `;
        log.userJourney.forEach((step, stepIndex) => {
          const timeAgo = Math.round((log.timestamp - step.timestamp) / 1000);
          htmlContent += `
            <div class="journey-item">
              <strong>${stepIndex + 1}.</strong> [${timeAgo}s ago] <strong>${step.type.toUpperCase()}:</strong> ${step.value}
              ${step.element ? `<br><em>Element: ${step.element}</em>` : ''}
            </div>
          `;
        });
        htmlContent += `</div>`;
      }
      
      // Network Context
      if (log.networkContext && log.networkContext.length > 0) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Network Context (Recent API Requests)</div>
        `;
        log.networkContext.forEach((req, reqIndex) => {
          const timeAgo = Math.round((log.timestamp - req.timestamp) / 1000);
          htmlContent += `
            <div class="network-item">
              <strong>${reqIndex + 1}.</strong> [${timeAgo}s ago] <strong>${req.method}</strong> ${req.url}<br>
              <em>Status: ${req.status} ${req.statusText} (${req.duration}ms)</em>
            </div>
          `;
        });
        htmlContent += `</div>`;
      }
      
      // Associated Screenshots
      if (log.associatedScreenshots && log.associatedScreenshots.length > 0) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Associated Screenshots (${log.associatedScreenshots.length})</div>
        `;
        log.associatedScreenshots.forEach((screenshotId, screenshotIndex) => {
          const screenshot = screenshots.find(s => s.id === screenshotId);
          if (screenshot) {
            htmlContent += `
              <div class="screenshot-item" style="margin-bottom: 20px; padding: 15px; border: 1px solid #ddd; border-radius: 8px; background-color: #fafafa; page-break-inside: avoid;">
                <div style="font-weight: bold; margin-bottom: 8px; color: #333; font-size: 14px;">Screenshot #${screenshotIndex + 1}: ${screenshot.title}</div>
                <div style="font-size: 12px; color: #666; margin-bottom: 15px;">Captured: ${new Date(screenshot.timestamp).toLocaleString()}</div>
                <div style="text-align: center; margin: 0 auto; width: 100%; max-width: 280px;">
                  <img src="${screenshot.dataUrl}" style="max-width: 100%; width: auto; height: auto; max-height: 196px; border: 2px solid #ccc; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); display: block; margin: 0 auto; object-fit: scale-down; background-color: #f8f9fa;" />
                </div>
              </div>
            `;
          }
        });
        htmlContent += `</div>`;
      }
      
      htmlContent += `
          </div>
        </body>
      </html>
    `;

    const blob = new Blob([htmlContent], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `manual-log-${log.severity}-${new Date().toISOString().split('T')[0]}.doc`;
    link.click();
    URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Failed to export manual log to Word document:', error);
      alert('Failed to export manual log to Word document. Please try again.');
    }
  };

  const exportToJson = () => {
    try {
      const dataStr = JSON.stringify(errors, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(dataBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `error-context-${new Date().toISOString().split('T')[0]}.json`;
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Failed to export JSON:', error);
      alert('Failed to export JSON file. Please try again.');
    }
  };

  const exportToWord = () => {
    try {
      let htmlContent = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
        <head>
          <meta charset="utf-8">
          <title>Comprehensive Error Debugging Report</title>
          <!--[if gte mso 9]>
          <xml>
            <w:WordDocument>
              <w:View>Print</w:View>
              <w:Zoom>90</w:Zoom>
              <w:DoNotPromptForConvert/>
              <w:DoNotShowRevisions/>
              <w:DoNotPrintRevisions/>
            </w:WordDocument>
          </xml>
          <![endif]-->
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
            .header { background-color: #f8f9fa; padding: 20px; border-left: 4px solid #dc3545; margin-bottom: 30px; }
            .error-item { border: 1px solid #ddd; margin-bottom: 30px; padding: 20px; border-radius: 8px; page-break-inside: avoid; }
            .error-header { font-weight: bold; color: #dc3545; margin-bottom: 15px; font-size: 18px; }
            .section { margin-bottom: 20px; }
            .section-title { font-weight: bold; color: #333; margin-bottom: 10px; font-size: 14px; text-transform: uppercase; }
            .field { margin-bottom: 8px; }
            .field-label { font-weight: bold; display: inline-block; width: 120px; }
            .field-value { font-family: monospace; background-color: #f8f9fa; padding: 2px 4px; }
            .stack-trace { background-color: #f8f9fa; padding: 15px; font-family: monospace; font-size: 11px; white-space: pre-wrap; border-radius: 5px; margin-top: 10px; }
            .steps-list { background-color: #f8f9fa; padding: 15px; border-radius: 5px; }
            .steps-list ol { margin: 0; padding-left: 20px; }
            .steps-list li { margin-bottom: 5px; }
            .journey-item { background-color: #fff3cd; padding: 8px; margin-bottom: 5px; border-radius: 3px; font-size: 12px; }
            .network-item { background-color: #d1ecf1; padding: 8px; margin-bottom: 5px; border-radius: 3px; font-size: 12px; }
            table { width: 100%; border-collapse: collapse; margin-top: 10px; }
            th, td { border: 1px solid #ddd; padding: 12px; text-align: left; vertical-align: top; }
            th { background-color: #f8f9fa; font-weight: bold; }
            .url-cell { word-break: break-all; max-width: 300px; }
            .summary-stats { background-color: #e8f5e8; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Comprehensive Error Debugging Report</h1>
            <p><strong>Generated on:</strong> ${new Date().toLocaleString()}</p>
            <p><strong>Total Errors:</strong> ${errors.length}</p>
            <div class="summary-stats">
              <strong>Summary:</strong> This report contains complete debugging context including user journey, network requests, and auto-generated reproduction steps for effective bug resolution.
            </div>
          </div>
    `;

    errors.forEach((error, index) => {
      htmlContent += `
        <div class="error-item">
          <div class="error-header">Error #${index + 1} - ${error.type.toUpperCase()}</div>
          
          <div class="section">
            <div class="section-title">Basic Information</div>
            <table>
              <tr><th>Field</th><th>Value</th></tr>
              <tr><td>Message</td><td>${error.message}</td></tr>
              <tr><td>Page URL</td><td class="url-cell">${error.pageUrl}</td></tr>
              <tr><td>Timestamp</td><td>${new Date(error.timestamp).toLocaleString()}</td></tr>
              <tr><td>User Agent</td><td class="url-cell">${error.userAgent}</td></tr>
      `;
      
      if (error.url) {
        htmlContent += `<tr><td>Source URL</td><td class="url-cell">${error.url}</td></tr>`;
      }
      
      if (error.lineNumber) {
        htmlContent += `<tr><td>Line</td><td>${error.lineNumber}</td></tr>`;
      }
      
      if (error.columnNumber) {
        htmlContent += `<tr><td>Column</td><td>${error.columnNumber}</td></tr>`;
      }
      
      htmlContent += `</table></div>`;
      
      // Environment Info
      if (error.environmentInfo) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Environment Context</div>
            <table>
              <tr><td>Viewport</td><td>${error.environmentInfo.viewport}</td></tr>
              <tr><td>Cookies Enabled</td><td>${error.environmentInfo.cookiesEnabled}</td></tr>
              <tr><td>Online Status</td><td>${error.environmentInfo.onlineStatus}</td></tr>
              <tr><td>Referrer</td><td class="url-cell">${error.environmentInfo.referrer}</td></tr>
            </table>
          </div>
        `;
      }
      
      // Reproduction Steps
      if (error.reproductionSteps && error.reproductionSteps.length > 0) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Auto-Generated Reproduction Steps</div>
            <div class="steps-list">
              <ol>
        `;
        error.reproductionSteps.forEach(step => {
          htmlContent += `<li>${step}</li>`;
        });
        htmlContent += `
              </ol>
            </div>
          </div>
        `;
      }
      
      // User Journey
      if (error.userJourney && error.userJourney.length > 0) {
        htmlContent += `
          <div class="section">
            <div class="section-title">User Journey (Last ${error.userJourney.length} Actions)</div>
        `;
        error.userJourney.forEach((step, stepIndex) => {
          const timeAgo = Math.round((error.timestamp - step.timestamp) / 1000);
          htmlContent += `
            <div class="journey-item">
              <strong>${stepIndex + 1}.</strong> [${timeAgo}s ago] <strong>${step.type.toUpperCase()}:</strong> ${step.value}
              ${step.element ? `<br><em>Element: ${step.element}</em>` : ''}
            </div>
          `;
        });
        htmlContent += `</div>`;
      }
      
      // Network Context
      if (error.networkContext && error.networkContext.length > 0) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Network Context (Recent API Requests)</div>
        `;
        error.networkContext.forEach((req, reqIndex) => {
          const timeAgo = Math.round((error.timestamp - req.timestamp) / 1000);
          htmlContent += `
            <div class="network-item">
              <strong>${reqIndex + 1}.</strong> [${timeAgo}s ago] <strong>${req.method}</strong> ${req.url}<br>
              <em>Status: ${req.status} ${req.statusText} (${req.duration}ms)</em>
            </div>
          `;
        });
        htmlContent += `</div>`;
      }
      
      if (error.stack) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Stack Trace</div>
            <div class="stack-trace">${error.stack}</div>
          </div>
        `;
      }
      
      // Network Error Details
      if (error.networkDetails) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Network Error Details</div>
            <table>
              <tr><td>Method</td><td>${error.networkDetails.method}</td></tr>
              <tr><td>Status</td><td>${error.networkDetails.status} ${error.networkDetails.statusText}</td></tr>
        `;
        if (error.networkDetails.responseText) {
          htmlContent += `<tr><td>Response</td><td class="url-cell">${error.networkDetails.responseText}</td></tr>`;
        }
        htmlContent += `</table></div>`;
      }
      
      // Associated Screenshots
      if (error.associatedScreenshots && error.associatedScreenshots.length > 0) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Associated Screenshots (${error.associatedScreenshots.length})</div>
        `;
        error.associatedScreenshots.forEach((screenshotId, screenshotIndex) => {
          const screenshot = screenshots.find(s => s.id === screenshotId);
          if (screenshot) {
            htmlContent += `
              <div class="screenshot-item" style="margin-bottom: 20px; padding: 15px; border: 1px solid #ddd; border-radius: 8px; background-color: #fafafa; page-break-inside: avoid;">
                <div style="font-weight: bold; margin-bottom: 8px; color: #333; font-size: 14px;">Screenshot #${screenshotIndex + 1}: ${screenshot.title}</div>
                <div style="font-size: 12px; color: #666; margin-bottom: 15px;">Captured: ${new Date(screenshot.timestamp).toLocaleString()}</div>
                <div style="text-align: center; margin: 0 auto; width: 100%; max-width: 280px;">
                  <img src="${screenshot.dataUrl}" style="max-width: 100%; width: auto; height: auto; max-height: 196px; border: 2px solid #ccc; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); display: block; margin: 0 auto; object-fit: scale-down; background-color: #f8f9fa;" />
                </div>
              </div>
            `;
          }
        });
        htmlContent += `</div>`;
      }
      
      htmlContent += `</div>`;
    });

    htmlContent += `
        </body>
      </html>
    `;

    const blob = new Blob([htmlContent], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `comprehensive-error-report-${new Date().toISOString().split('T')[0]}.doc`;
    link.click();
    URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Failed to export Word document:', error);
      alert('Failed to export Word document. Please try again.');
    }
  };

  // Unified export function for all visible content
  const exportAllToWord = () => {
    const hasErrors = errors.length > 0;
    const hasManualLogs = manualLogs.length > 0;
    
    if (!hasErrors && !hasManualLogs) return;

    try {
      let htmlContent = '';

      // Export errors using original format if there are errors
      if (hasErrors) {
        htmlContent += `
        <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
          <head>
            <meta charset="utf-8">
            <title>Comprehensive Error Debugging Report</title>
            <!--[if gte mso 9]>
            <xml>
              <w:WordDocument>
                <w:View>Print</w:View>
                <w:Zoom>90</w:Zoom>
                <w:DoNotPromptForConvert/>
                <w:DoNotShowRevisions/>
                <w:DoNotPrintRevisions/>
              </w:WordDocument>
            </xml>
            <![endif]-->
            <style>
              body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
              .header { background-color: #f8f9fa; padding: 20px; border-left: 4px solid #dc3545; margin-bottom: 30px; }
              .error-item { border: 1px solid #ddd; margin-bottom: 30px; padding: 20px; border-radius: 8px; page-break-inside: avoid; }
              .error-header { font-weight: bold; color: #dc3545; margin-bottom: 15px; font-size: 18px; }
              .section { margin-bottom: 20px; }
              .section-title { font-weight: bold; color: #333; margin-bottom: 10px; font-size: 14px; text-transform: uppercase; }
              .field { margin-bottom: 8px; }
              .field-label { font-weight: bold; color: #555; }
              .field-value { margin-left: 10px; word-wrap: break-word; }
              .code-block { background-color: #f8f9fa; border: 1px solid #e9ecef; padding: 15px; border-radius: 4px; font-family: monospace; font-size: 12px; white-space: pre-wrap; margin: 10px 0; }
              .journey-item { border-left: 3px solid #007bff; padding-left: 15px; margin-bottom: 10px; }
              .network-item { border-left: 3px solid #28a745; padding-left: 15px; margin-bottom: 10px; }
              table { width: 100%; border-collapse: collapse; margin: 15px 0; }
              th, td { border: 1px solid #ddd; padding: 12px; text-align: left; vertical-align: top; }
              th { background-color: #f8f9fa; font-weight: bold; }
              .url-cell { word-break: break-all; max-width: 300px; }
              .steps-list { margin: 10px 0; }
              .steps-list ol { padding-left: 20px; }
              .steps-list li { margin-bottom: 5px; }
            </style>
          </head>
          <body>
            <div class="header">
              <h1>Comprehensive Error Debugging Report</h1>
              <p><strong>Generated on:</strong> ${new Date().toLocaleString()}</p>
              <p><strong>Total Errors Found:</strong> ${errors.length}</p>
              <div style="background-color: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin-top: 15px;">
                <strong>Summary:</strong> This report contains detailed information about JavaScript errors, network failures, and related debugging context including user journey, network requests, and reproduction steps for effective troubleshooting.
              </div>
            </div>`;

        errors.forEach((error, index) => {
          htmlContent += `
          <div class="error-item">
            <div class="error-header">Error #${index + 1}: ${error.message}</div>
            
            <div class="section">
              <div class="section-title">Basic Information</div>
              <table>
                <tr><th>Field</th><th>Value</th></tr>
                <tr><td>Error Type</td><td>${error.type}</td></tr>
                <tr><td>Message</td><td>${error.message}</td></tr>
                <tr><td>Page URL</td><td class="url-cell">${error.pageUrl}</td></tr>
                <tr><td>Timestamp</td><td>${new Date(error.timestamp).toLocaleString()}</td></tr>
                <tr><td>User Agent</td><td class="url-cell">${error.userAgent}</td></tr>`;
          
          if (error.url) {
            htmlContent += `<tr><td>Source URL</td><td class="url-cell">${error.url}</td></tr>`;
          }
          if (error.lineNumber) {
            htmlContent += `<tr><td>Line</td><td>${error.lineNumber}</td></tr>`;
          }
          if (error.columnNumber) {
            htmlContent += `<tr><td>Column</td><td>${error.columnNumber}</td></tr>`;
          }
          
          htmlContent += `</table></div>`;
          
          // Environment Info
          if (error.environmentInfo) {
            htmlContent += `
              <div class="section">
                <div class="section-title">Environment Context</div>
                <table>
                  <tr><td>Viewport</td><td>${error.environmentInfo.viewport}</td></tr>
                  <tr><td>Cookies Enabled</td><td>${error.environmentInfo.cookiesEnabled}</td></tr>
                  <tr><td>Online Status</td><td>${error.environmentInfo.onlineStatus}</td></tr>
                  <tr><td>Referrer</td><td class="url-cell">${error.environmentInfo.referrer}</td></tr>
                </table>
              </div>
            `;
          }
          
          // Stack trace
          if (error.stack) {
            htmlContent += `
              <div class="section">
                <div class="section-title">Stack Trace</div>
                <div class="code-block">${error.stack}</div>
              </div>
            `;
          }
          
          // Network details
          if (error.networkDetails) {
            htmlContent += `
              <div class="section">
                <div class="section-title">Network Error Details</div>
                <table>
                  <tr><td>Method</td><td>${error.networkDetails.method}</td></tr>
                  <tr><td>Status</td><td>${error.networkDetails.status}</td></tr>
                  <tr><td>Status Text</td><td>${error.networkDetails.statusText}</td></tr>
                </table>
            `;
            if (error.networkDetails.responseText) {
              htmlContent += `<div class="code-block">${error.networkDetails.responseText}</div>`;
            }
            htmlContent += `</div>`;
          }
          
          // Reproduction Steps
          if (error.reproductionSteps && error.reproductionSteps.length > 0) {
            htmlContent += `
              <div class="section">
                <div class="section-title">Auto-Generated Reproduction Steps</div>
                <div class="steps-list">
                  <ol>
            `;
            error.reproductionSteps.forEach(step => {
              htmlContent += `<li>${step}</li>`;
            });
            htmlContent += `
                  </ol>
                </div>
              </div>
            `;
          }
          
          // User Journey
          if (error.userJourney && error.userJourney.length > 0) {
            htmlContent += `
              <div class="section">
                <div class="section-title">User Journey (Last ${error.userJourney.length} Actions)</div>
            `;
            error.userJourney.forEach((step, stepIndex) => {
              const timeAgo = Math.round((error.timestamp - step.timestamp) / 1000);
              htmlContent += `
                <div class="journey-item">
                  <strong>${stepIndex + 1}.</strong> [${timeAgo}s ago] <strong>${step.type.toUpperCase()}:</strong> ${step.value}
                  ${step.element ? `<br><em>Element: ${step.element}</em>` : ''}
                </div>
              `;
            });
            htmlContent += `</div>`;
          }
          
          // Network Context
          if (error.networkContext && error.networkContext.length > 0) {
            htmlContent += `
              <div class="section">
                <div class="section-title">Network Context (Last ${error.networkContext.length} Requests)</div>
            `;
            error.networkContext.forEach((req, reqIndex) => {
              const timeAgo = Math.round((error.timestamp - req.timestamp) / 1000);
              htmlContent += `
                <div class="network-item">
                  <strong>${reqIndex + 1}.</strong> [${timeAgo}s ago] <strong>${req.method}</strong> ${req.url} → ${req.status} ${req.statusText} (${req.duration}ms)
                  ${req.requestBody ? `<br><em>Request Body: ${req.requestBody}</em>` : ''}
                </div>
              `;
            });
            htmlContent += `</div>`;
          }

          // Associated screenshots section for errors
          const errorScreenshots = screenshots.filter(s => error.associatedScreenshots?.includes(s.id));
          if (errorScreenshots.length > 0) {
            htmlContent += `
            <div class="section">
              <div class="section-title">Associated Screenshots</div>`;
            
            errorScreenshots.forEach((screenshot, idx) => {
              htmlContent += `
              <div style="max-width: 280px; margin: 10px 0; text-align: center;">
                <img src="${screenshot.dataUrl}" alt="Screenshot ${idx + 1}" style="max-width: 100%; max-height: 196px; object-fit: scale-down; border: 1px solid #ddd; border-radius: 4px;">
                <div style="font-size: 12px; color: #666; margin-top: 5px;">Screenshot ${idx + 1} - ${new Date(screenshot.timestamp).toLocaleString()}</div>
              </div>`;
            });
            
            htmlContent += `</div>`;
          }
          
          htmlContent += `</div>`;
        });

        if (hasManualLogs) {
          htmlContent += `<div style="page-break-before: always;"></div>`;
        }
      }

      // Export manual logs using original format if there are manual logs
      if (hasManualLogs) {
        if (!hasErrors) {
          htmlContent += `
          <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
            <head>
              <meta charset="utf-8">
              <title>Manual Debug Logs Report</title>
              <!--[if gte mso 9]>
              <xml>
                <w:WordDocument>
                  <w:View>Print</w:View>
                  <w:Zoom>90</w:Zoom>
                  <w:DoNotPromptForConvert/>
                  <w:DoNotShowRevisions/>
                  <w:DoNotPrintRevisions/>
                </w:WordDocument>
              </xml>
              <![endif]-->
              <style>
                body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
                .header { background-color: #f8f9fa; padding: 20px; border-left: 4px solid #28a745; margin-bottom: 30px; }
                .log-item { border: 1px solid #ddd; margin-bottom: 30px; padding: 20px; border-radius: 8px; page-break-inside: avoid; }
                .log-header { font-weight: bold; margin-bottom: 15px; font-size: 18px; }
                .severity-info { color: #17a2b8; }
                .severity-warning { color: #ffc107; }
                .severity-critical { color: #dc3545; }
                .section { margin-bottom: 20px; }
                .section-title { font-weight: bold; color: #333; margin-bottom: 10px; font-size: 14px; text-transform: uppercase; }
                .field { margin-bottom: 8px; }
                .field-label { font-weight: bold; color: #555; }
                .field-value { margin-left: 10px; word-wrap: break-word; }
                .code-block { background-color: #f8f9fa; border: 1px solid #e9ecef; padding: 15px; border-radius: 4px; font-family: monospace; font-size: 12px; white-space: pre-wrap; margin: 10px 0; }
                .journey-step { border-left: 3px solid #007bff; padding-left: 15px; margin-bottom: 10px; }
                .network-request { border-left: 3px solid #28a745; padding-left: 15px; margin-bottom: 10px; }
                table { width: 100%; border-collapse: collapse; margin: 15px 0; }
                th, td { border: 1px solid #ddd; padding: 12px; text-align: left; vertical-align: top; }
                th { background-color: #f8f9fa; font-weight: bold; }
                .url-cell { word-break: break-all; max-width: 300px; }
                .summary-stats { background-color: #e8f5e8; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
              </style>
            </head>
            <body>
              <div class="header">
                <h1>Manual Debug Logs Report</h1>
                <p><strong>Generated on:</strong> ${new Date().toLocaleString()}</p>
                <p><strong>Total Manual Logs:</strong> ${manualLogs.length}</p>
                <div class="summary-stats">
                  <strong>Summary:</strong> This report contains manual debug observations and issues logged by the user, including reproduction steps, user journey, and network context for effective debugging.
                </div>
              </div>`;
        } else {
          htmlContent += `
            <div class="header" style="background-color: #f8f9fa; padding: 20px; border-left: 4px solid #28a745; margin: 30px 0;">
              <h2>Manual Debug Logs</h2>
              <p><strong>Total Manual Logs:</strong> ${manualLogs.length}</p>
              <div style="background-color: #e8f5e8; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                <strong>Summary:</strong> This section contains manual debug observations and issues logged by the user, including reproduction steps, user journey, and network context for effective debugging.
              </div>
            </div>`;
        }

        manualLogs.forEach((log, index) => {
          const severityClass = `severity-${log.severity}`;
          htmlContent += `
            <div class="log-item">
              <div class="log-header ${severityClass}">Manual Log #${index + 1} - ${log.severity.toUpperCase()}</div>
              
              <div class="section">
                <div class="section-title">Basic Information</div>
                <table>
                  <tr><th>Field</th><th>Value</th></tr>
                  <tr><td>Issue/Observation</td><td>${log.message}</td></tr>
                  <tr><td>Page URL</td><td class="url-cell">${log.pageUrl}</td></tr>
                  <tr><td>Timestamp</td><td>${new Date(log.timestamp).toLocaleString()}</td></tr>
                  <tr><td>User Agent</td><td class="url-cell">${log.userAgent}</td></tr>
                  <tr><td>Severity</td><td class="${severityClass}">${log.severity.toUpperCase()}</td></tr>
                </table>
              </div>
          `;
          
          if (log.note) {
            htmlContent += `
              <div class="section">
                <div class="section-title">Detailed Notes</div>
                <div class="notes">${log.note}</div>
              </div>
            `;
          }

          // Associated screenshots section for logs
          const logScreenshots = screenshots.filter(s => log.associatedScreenshots?.includes(s.id));
          if (logScreenshots.length > 0) {
            htmlContent += `
            <div class="section">
              <div class="section-title">Associated Screenshots</div>`;
            
            logScreenshots.forEach((screenshot, idx) => {
              htmlContent += `
              <div style="max-width: 280px; margin: 10px 0; text-align: center;">
                <img src="${screenshot.dataUrl}" alt="Screenshot ${idx + 1}" style="max-width: 100%; max-height: 196px; object-fit: scale-down; border: 1px solid #ddd; border-radius: 4px;">
                <div style="font-size: 12px; color: #666; margin-top: 5px;">Screenshot ${idx + 1} - ${new Date(screenshot.timestamp).toLocaleString()}</div>
              </div>`;
            });
            
            htmlContent += `</div>`;
          }

          if (log.reproductionSteps && log.reproductionSteps.length > 0) {
            htmlContent += `
              <div class="section">
                <div class="section-title">Reproduction Steps</div>
                <ol>
            `;
            log.reproductionSteps.forEach(step => {
              htmlContent += `<li>${step}</li>`;
            });
            htmlContent += `
                </ol>
              </div>
            `;
          }

          if (log.userJourney && log.userJourney.length > 0) {
            htmlContent += `
              <div class="section">
                <div class="section-title">User Journey</div>
            `;
            log.userJourney.forEach((step, stepIndex) => {
              const stepTime = new Date(step.timestamp).toLocaleTimeString();
              htmlContent += `
                <div class="journey-step">
                  <strong>Step ${stepIndex + 1}</strong> (${stepTime}): ${step.type} - ${step.value}
                </div>
              `;
            });
            htmlContent += `</div>`;
          }

          if (log.networkContext && log.networkContext.length > 0) {
            htmlContent += `
              <div class="section">
                <div class="section-title">Network Context</div>
            `;
            log.networkContext.forEach((req, reqIndex) => {
              const reqTime = new Date(req.timestamp).toLocaleTimeString();
              htmlContent += `
                <div class="network-request">
                  <strong>Request ${reqIndex + 1}</strong> (${reqTime}): ${req.method} ${req.url} - ${req.status} ${req.statusText} (${req.duration}ms)
                </div>
              `;
            });
            htmlContent += `</div>`;
          }

          if (log.environmentInfo) {
            htmlContent += `
              <div class="section">
                <div class="section-title">Environment Information</div>
                <table>
                  <tr><th>Property</th><th>Value</th></tr>
                  <tr><td>Viewport</td><td>${log.environmentInfo.viewport}</td></tr>
                  <tr><td>Cookies Enabled</td><td>${log.environmentInfo.cookiesEnabled ? 'Yes' : 'No'}</td></tr>
                  <tr><td>Online Status</td><td>${log.environmentInfo.onlineStatus ? 'Online' : 'Offline'}</td></tr>
                  <tr><td>Referrer</td><td class="url-cell">${log.environmentInfo.referrer || 'None'}</td></tr>
                </table>
              </div>
            `;
          }

          htmlContent += `</div>`;
        });
      }

      htmlContent += `
          </body>
        </html>`;

      const blob = new Blob([htmlContent], { type: 'application/msword' });
      const url = URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = `page-insights-report-${new Date().toISOString().split('T')[0]}.doc`;
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Failed to export Page Insights report:', error);
      alert('Failed to export Page Insights report. Please try again.');
    }
  };

  const formatTimestamp = (timestamp: number) => {
    return new Date(timestamp).toLocaleString();
  };

  const getErrorTypeColor = (type: string) => {
    switch (type) {
      case 'javascript': return 'text-red-400';
      case 'network': return 'text-orange-400';
      case 'unhandled-promise': return 'text-yellow-400';
      case 'console-error': return 'text-red-500';
      case 'console-warning': return 'text-yellow-500';
      default: return 'text-gray-400';
    }
  };

  // JSON viewer functionality
  const openJsonViewer = (data: any, title: string) => {
    setJsonViewerData({ data, title });
    setExpandedKeys(new Set()); // Reset expanded state when opening new viewer
  };

  const closeJsonViewer = () => {
    setJsonViewerData(null);
    setExpandedKeys(new Set()); // Reset expanded state when closing
  };

  // Screenshot functionality
  const captureScreenshot = async () => {
    if (!tabId || !isChromeApiAvailable) return;
    
    setIsCapturingScreenshot(true);
    try {
      // Get device pixel ratio for higher resolution capture
      const devicePixelRatio = window.devicePixelRatio || 1;
      
      // Use chrome.tabs.captureVisibleTab API
      const response = await chrome.runtime.sendMessage({
        type: 'CAPTURE_SCREENSHOT',
        tabId: tabId,
        options: {
          format: 'png',
          quality: 100,
          devicePixelRatio: devicePixelRatio
        }
      });
      
      if (response && response.dataUrl) {
        const screenshot = {
          id: `screenshot-${Date.now()}`,
          dataUrl: response.dataUrl,
          timestamp: Date.now(),
          title: `Page Screenshot - ${new Date().toLocaleString()}`
        };
        setScreenshots(prev => [screenshot, ...prev]);
      }
    } catch (error) {
      console.error('Failed to capture screenshot:', error);
    } finally {
      setIsCapturingScreenshot(false);
    }
  };

  const downloadScreenshot = (screenshot: { id: string; dataUrl: string; timestamp: number; title: string }) => {
    // Create a canvas to potentially enhance the image quality
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();
    
    img.onload = () => {
      // Set canvas to original image size or larger for better quality
      const scaleFactor = 2; // 2x scale for better quality
      canvas.width = img.width * scaleFactor;
      canvas.height = img.height * scaleFactor;
      
      // Enable image smoothing for better quality
      if (ctx) {
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        
        // Draw the image at higher resolution
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        
        // Convert to high-quality PNG
        canvas.toBlob((blob) => {
          if (blob) {
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `page-screenshot-${new Date(screenshot.timestamp).toISOString().slice(0, 19).replace(/:/g, '-')}-hq.png`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
          } else {
            // Fallback to original method
            const link = document.createElement('a');
            link.href = screenshot.dataUrl;
            link.download = `page-screenshot-${new Date(screenshot.timestamp).toISOString().slice(0, 19).replace(/:/g, '-')}.png`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
          }
        }, 'image/png', 1.0); // Maximum quality PNG
      }
    };
    
    img.onerror = () => {
      // Fallback to original method if image processing fails
      const link = document.createElement('a');
      link.href = screenshot.dataUrl;
      link.download = `page-screenshot-${new Date(screenshot.timestamp).toISOString().slice(0, 19).replace(/:/g, '-')}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    };
    
    img.src = screenshot.dataUrl;
  };

  const deleteScreenshot = (id: string) => {
    setScreenshots(prev => {
      const newScreenshots = prev.filter(s => s.id !== id);
      // If no screenshots left, close the list
      if (newScreenshots.length === 0) {
        setIsScreenshotsExpanded(false);
      }
      return newScreenshots;
    });
  };

  const openScreenshotViewer = (screenshot: { id: string; dataUrl: string; timestamp: number; title: string }) => {
    setViewingScreenshot(screenshot);
  };

  const closeScreenshotViewer = () => {
    setViewingScreenshot(null);
    setIsAnnotating(false);
    setAnnotationHistory([]);
    setAnnotationHistoryIndex(-1);
  };

  // Screenshot association functions
  const openScreenshotAssociation = (targetType: 'error' | 'manual', targetId: string) => {
    setAssociationTarget({ type: targetType, id: targetId });
    setShowScreenshotAssociation(true);
  };

  const closeScreenshotAssociation = () => {
    setShowScreenshotAssociation(false);
    setAssociationTarget(null);
  };

  const associateScreenshot = (screenshotId: string) => {
    if (!associationTarget) return;

    if (associationTarget.type === 'error') {
      setErrors(prev => prev.map(error => {
        if (error.id === associationTarget.id) {
          const currentScreenshots = error.associatedScreenshots || [];
          if (!currentScreenshots.includes(screenshotId)) {
            const updatedError = {
              ...error,
              associatedScreenshots: [...currentScreenshots, screenshotId]
            };
            
            // Update selectedError if it's the one being modified
            if (selectedError && selectedError.id === associationTarget.id) {
              setSelectedError(updatedError);
            }
            
            return updatedError;
          }
        }
        return error;
      }));
    } else if (associationTarget.type === 'manual') {
      setManualLogs(prev => prev.map(log => {
        if (log.id === associationTarget.id) {
          const currentScreenshots = log.associatedScreenshots || [];
          if (!currentScreenshots.includes(screenshotId)) {
            const updatedLog = {
              ...log,
              associatedScreenshots: [...currentScreenshots, screenshotId]
            };
            
            // Update selectedManualLog if it's the one being modified
            if (selectedManualLog && selectedManualLog.id === associationTarget.id) {
              setSelectedManualLog(updatedLog);
            }
            
            return updatedLog;
          }
        }
        return log;
      }));
    }

    closeScreenshotAssociation();
  };

  const removeScreenshotAssociation = (targetType: 'error' | 'manual', targetId: string, screenshotId: string) => {
    if (targetType === 'error') {
      setErrors(prev => prev.map(error => {
        if (error.id === targetId) {
          const updatedError = {
            ...error,
            associatedScreenshots: (error.associatedScreenshots || []).filter(id => id !== screenshotId)
          };
          
          // Update selectedError if it's the one being modified
          if (selectedError && selectedError.id === targetId) {
            setSelectedError(updatedError);
          }
          
          return updatedError;
        }
        return error;
      }));
    } else if (targetType === 'manual') {
      setManualLogs(prev => prev.map(log => {
        if (log.id === targetId) {
          const updatedLog = {
            ...log,
            associatedScreenshots: (log.associatedScreenshots || []).filter(id => id !== screenshotId)
          };
          
          // Update selectedManualLog if it's the one being modified
          if (selectedManualLog && selectedManualLog.id === targetId) {
            setSelectedManualLog(updatedLog);
          }
          
          return updatedLog;
        }
        return log;
      }));
    }
  };

  const getScreenshotById = (id: string) => {
    return screenshots.find(screenshot => screenshot.id === id);
  };

  // Annotation functions
  const startAnnotation = () => {
    setIsAnnotating(true);
    // Initialize canvas after the screenshot is loaded
    setTimeout(() => {
      if (canvasRef.current) {
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          // Save initial state
          const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          setAnnotationHistory([imageData]);
          setAnnotationHistoryIndex(0);
        }
      }
    }, 100);
  };

  const stopAnnotation = () => {
    setIsAnnotating(false);
  };

  const saveAnnotation = () => {
    if (canvasRef.current && viewingScreenshot) {
      const canvas = canvasRef.current;
      const dataUrl = canvas.toDataURL('image/png', 1.0); // Maximum quality
      
      // Update the screenshot with annotations
      setScreenshots(prev => 
        prev.map(s => 
          s.id === viewingScreenshot.id 
            ? { ...s, dataUrl, title: s.title + ' (Annotated)' }
            : s
        )
      );
      
      // Update viewing screenshot
      setViewingScreenshot(prev => prev ? { ...prev, dataUrl, title: prev.title + ' (Annotated)' } : null);
      
      setIsAnnotating(false);
    }
  };

  const getCanvasPosition = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY
    };
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isAnnotating) return;
    
    setIsDrawing(true);
    const pos = getCanvasPosition(e);
    setLastPosition(pos);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !canvasRef.current || !lastPosition) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const pos = getCanvasPosition(e);
    
    ctx.beginPath();
    ctx.moveTo(lastPosition.x, lastPosition.y);
    ctx.lineTo(pos.x, pos.y);
    
    ctx.globalCompositeOperation = 'source-over';
    ctx.strokeStyle = penColor;
    ctx.lineWidth = penSize;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.stroke();
    
    setLastPosition(pos);
  };

  const stopDrawing = () => {
    if (!isDrawing) return;
    
    setIsDrawing(false);
    setLastPosition(null);
    
    // Save state for undo/redo
    if (canvasRef.current) {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const newHistory = annotationHistory.slice(0, annotationHistoryIndex + 1);
        newHistory.push(imageData);
        setAnnotationHistory(newHistory);
        setAnnotationHistoryIndex(newHistory.length - 1);
      }
    }
  };

  const undoAnnotation = () => {
    if (annotationHistoryIndex > 0) {
      const newIndex = annotationHistoryIndex - 1;
      setAnnotationHistoryIndex(newIndex);
      
      if (canvasRef.current) {
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.putImageData(annotationHistory[newIndex], 0, 0);
        }
      }
    }
  };

  // Initialize canvas when starting annotation
  useEffect(() => {
    if (isAnnotating && canvasRef.current && viewingScreenshot) {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        const img = new Image();
        img.onload = () => {
          // Use higher resolution for better quality
          const devicePixelRatio = window.devicePixelRatio || 1;
          const maxWidth = 1200 * devicePixelRatio; // Higher base resolution
          const maxHeight = 900 * devicePixelRatio;
          const imgAspect = img.width / img.height;
          
          let canvasWidth, canvasHeight;
          if (imgAspect > maxWidth / maxHeight) {
            canvasWidth = Math.min(maxWidth, img.width);
            canvasHeight = canvasWidth / imgAspect;
          } else {
            canvasHeight = Math.min(maxHeight, img.height);
            canvasWidth = canvasHeight * imgAspect;
          }
          
          // Set canvas size to maintain quality
          canvas.width = canvasWidth;
          canvas.height = canvasHeight;
          
          // Enable high-quality rendering
          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';
          
          // Draw the image on the canvas
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(img, 0, 0, canvasWidth, canvasHeight);
          
          // Save initial state
          const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          setAnnotationHistory([imageData]);
          setAnnotationHistoryIndex(0);
        };
        img.src = viewingScreenshot.dataUrl;
      }
    }
  }, [isAnnotating, viewingScreenshot]);

  // JSON Tree Component for hierarchical display
  const JsonTree = ({ data, level = 0 }: { data: any; level?: number }) => {
    const toggleExpanded = (key: string) => {
      const newExpanded = new Set(expandedKeys);
      if (newExpanded.has(key)) {
        newExpanded.delete(key);
      } else {
        newExpanded.add(key);
      }
      setExpandedKeys(newExpanded);
    };

    const renderValue = (value: any, key: string, path: string) => {
      const isExpanded = expandedKeys.has(path);
      const indent = level * 20;

      // Handle primitive values - show key: value
      if (value === null) {
        return (
          <div className="flex items-center" style={{ paddingLeft: `${indent}px` }}>
            <span className="text-blue-300">{key}:</span>
            <span className="text-gray-500 ml-2">null</span>
          </div>
        );
      }
      
      if (value === undefined) {
        return (
          <div className="flex items-center" style={{ paddingLeft: `${indent}px` }}>
            <span className="text-blue-300">{key}:</span>
            <span className="text-gray-500 ml-2">undefined</span>
          </div>
        );
      }
      
      if (typeof value === 'boolean') {
        return (
          <div className="flex items-center" style={{ paddingLeft: `${indent}px` }}>
            <span className="text-blue-300">{key}:</span>
            <span className="text-purple-400 ml-2">{value.toString()}</span>
          </div>
        );
      }
      
      if (typeof value === 'number') {
        return (
          <div className="flex items-center" style={{ paddingLeft: `${indent}px` }}>
            <span className="text-blue-300">{key}:</span>
            <span className="text-green-400 ml-2">{value}</span>
          </div>
        );
      }
      
      if (typeof value === 'string') {
        return (
          <div className="flex items-center" style={{ paddingLeft: `${indent}px` }}>
            <span className="text-blue-300">{key}:</span>
            <span className="text-yellow-400 ml-2">"{value}"</span>
          </div>
        );
      }

      if (Array.isArray(value)) {
        return (
          <div>
            <div 
              className="flex items-center cursor-pointer hover:bg-gray-700 p-1 rounded"
              onClick={() => toggleExpanded(path)}
              style={{ paddingLeft: `${indent}px` }}
            >
              {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
              <span className="text-blue-300 ml-1">{key}: Array[{value.length}]</span>
            </div>
            {isExpanded && (
              <div>
                {value.map((item, index) => (
                  <div key={index} style={{ paddingLeft: `${indent + 20}px` }}>
                    <JsonTree data={{ [`[${index}]`]: item }} level={level + 1} />
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      }

      if (typeof value === 'object') {
        const keys = Object.keys(value);
        return (
          <div>
            <div 
              className="flex items-center cursor-pointer hover:bg-gray-700 p-1 rounded"
              onClick={() => toggleExpanded(path)}
              style={{ paddingLeft: `${indent}px` }}
            >
              {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
              <span className="text-blue-300 ml-1">{key}: Object{`{${keys.length}}`}</span>
            </div>
            {isExpanded && (
              <div>
                {keys.map(objKey => (
                  <div key={objKey} style={{ paddingLeft: `${indent + 20}px` }}>
                    <JsonTree data={{ [objKey]: value[objKey] }} level={level + 1} />
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      }

      return (
        <div className="flex items-center" style={{ paddingLeft: `${indent}px` }}>
          <span className="text-blue-300">{key}:</span>
          <span className="text-gray-300 ml-2">{String(value)}</span>
        </div>
      );
    };

    if (typeof data === 'object' && data !== null) {
      return (
        <div>
          {Object.entries(data).map(([key, value]) => (
            <div key={key} className="mb-1">
              {renderValue(value, key, `${level}-${key}`)}
            </div>
          ))}
        </div>
      );
    }

    return <div className="text-gray-300">{JSON.stringify(data, null, 2)}</div>;
  };

  return (
    <div className="p-4 h-full flex flex-col bg-gray-900 text-white">
      {/* Action Buttons */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsErrorsExpanded(!isErrorsExpanded)}
            className="relative p-2 bg-red-600 hover:bg-red-700 disabled:bg-red-800 rounded transition-colors cursor-pointer"
            title={errors.length > 0 ? (isErrorsExpanded ? "Hide errors" : "Show errors") : "No errors captured"}
            disabled={errors.length === 0}
          >
            <AlertTriangle size={16} />
            {errors.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full min-w-[18px] h-[18px] flex items-center justify-center">
                {errors.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setIsScreenshotsExpanded(!isScreenshotsExpanded)}
            className="relative p-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-800 rounded transition-colors cursor-pointer"
            title={screenshots.length > 0 ? (isScreenshotsExpanded ? "Hide screenshots" : "Show screenshots") : "No screenshots captured"}
            disabled={screenshots.length === 0}
          >
            <ImageIcon size={16} />
            {screenshots.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-blue-500 text-white text-xs rounded-full min-w-[18px] h-[18px] flex items-center justify-center">
                {screenshots.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setIsManualLogsExpanded(!isManualLogsExpanded)}
            className="relative p-2 bg-green-600 hover:bg-green-700 disabled:bg-green-800 rounded transition-colors cursor-pointer"
            title={manualLogs.length > 0 ? (isManualLogsExpanded ? "Hide manual logs" : "Show manual logs") : "No manual logs captured"}
            disabled={manualLogs.length === 0}
          >
            <FileText size={16} />
            {manualLogs.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-green-500 text-white text-xs rounded-full min-w-[18px] h-[18px] flex items-center justify-center">
                {manualLogs.length}
              </span>
            )}
          </button>
        </div>
        
        <div className="flex space-x-2">
          <button
            onClick={() => setShowAddLogModal(true)}
            className="p-2 bg-green-600 hover:bg-green-700 rounded transition-colors"
            title="Add manual log"
          >
            <Plus size={16} />
          </button>
          <button
            onClick={captureScreenshot}
            disabled={isCapturingScreenshot}
            className="p-2 bg-purple-600 hover:bg-purple-700 disabled:bg-purple-800 rounded transition-colors"
            title={isCapturingScreenshot ? "Capturing screenshot..." : "Capture screenshot"}
          >
            <Camera size={16} className={isCapturingScreenshot ? 'animate-pulse' : ''} />
          </button>
          
          <button
            onClick={refreshErrors}
            disabled={isLoading}
            className="p-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-800 rounded transition-colors"
            title="Refresh page insights"
          >
            <RefreshCw size={16} className={isLoading ? 'animate-spin' : ''} />
          </button>
          
          <button
            onClick={clearErrors}
            className="p-2 bg-red-600 hover:bg-red-700 rounded transition-colors"
            title="Clear all insights"
          >
            <Trash2 size={16} />
          </button>
          
          {(errors.length > 0 || manualLogs.length > 0) && (
            <button
              onClick={exportAllToWord}
              className="p-2 bg-green-600 hover:bg-green-700 rounded transition-colors"
              title="Download all insights to Word"
            >
              <Download size={16} />
            </button>
          )}
        </div>
      </div>

      {/* Screenshots Section - Fixed overlay */}
      {screenshots.length > 0 && isScreenshotsExpanded && (
        <>
          {/* Backdrop to close on click outside */}
          <div 
            className="fixed inset-0 z-30"
            onClick={() => setIsScreenshotsExpanded(false)}
          />
          <div className="fixed top-16 left-4 right-4 z-40 max-w-md mx-auto">
            <div className="bg-gray-800 rounded-lg border border-gray-700 shadow-2xl">
            {/* Screenshots Header */}
            <div className="flex items-center justify-between p-3 bg-gray-750 rounded-t-lg border-b border-gray-700">
              <div className="flex items-center">
                <Camera className="mr-2 text-purple-400" size={18} />
                <h3 className="text-base font-semibold">Page Screenshots</h3>
                <span className="ml-2 bg-purple-600 text-white text-xs px-2 py-1 rounded-full">
                  {screenshots.length}
                </span>
              </div>
              <button
                onClick={() => setIsScreenshotsExpanded(false)}
                className="p-1 text-gray-400 hover:text-gray-300 transition-colors"
                title="Hide screenshots"
              >
                <X size={16} />
              </button>
            </div>
            
            {/* Screenshots List */}
            <div className="p-3 space-y-2 max-h-80 overflow-y-auto">
              {screenshots.map((screenshot, index) => (
                <div
                  key={screenshot.id}
                  className="flex items-center gap-3 p-2 bg-gray-700 rounded-lg border border-gray-600 hover:bg-gray-650 transition-colors"
                >
                  {/* Thumbnail */}
                  <div className="w-12 h-9 bg-gray-600 rounded overflow-hidden flex-shrink-0">
                    <img 
                      src={screenshot.dataUrl} 
                      alt="Screenshot thumbnail"
                      className="w-full h-full object-cover cursor-pointer hover:scale-105 transition-transform"
                      onClick={() => openScreenshotViewer(screenshot)}
                    />
                  </div>
                  
                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-white">
                        Screenshot #{index + 1}
                      </span>
                      <span className="text-xs text-gray-400">
                        {new Date(screenshot.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <p className="text-xs text-gray-300 truncate">{screenshot.title}</p>
                  </div>
                  
                  {/* Actions */}
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <button
                      onClick={() => openScreenshotViewer(screenshot)}
                      className="p-1.5 bg-blue-600 rounded hover:bg-blue-700 text-white transition-colors"
                      title="View full size"
                    >
                      <Eye size={12} />
                    </button>
                    <button
                      onClick={() => downloadScreenshot(screenshot)}
                      className="p-1.5 bg-green-600 rounded hover:bg-green-700 text-white transition-colors"
                      title="Download"
                    >
                      <Download size={12} />
                    </button>
                    <button
                      onClick={() => deleteScreenshot(screenshot.id)}
                      className="p-1.5 bg-red-600 rounded hover:bg-red-700 text-white transition-colors"
                      title="Delete"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        </>
      )}

      {/* Errors Section - Fixed overlay */}
      {errors.length > 0 && isErrorsExpanded && (
        <>
          {/* Backdrop to close on click outside */}
          <div 
            className="fixed inset-0 z-30"
            onClick={() => setIsErrorsExpanded(false)}
          />
          <div className="fixed top-16 left-4 right-4 z-40 max-w-md mx-auto">
          <div className="bg-gray-800 rounded-lg border border-gray-700 shadow-2xl">
            {/* Errors Header */}
            <div className="flex items-center justify-between p-3 bg-gray-750 rounded-t-lg border-b border-gray-700">
              <div className="flex items-center">
                <AlertTriangle className="mr-2 text-red-400" size={18} />
                <h3 className="text-base font-semibold">Page Errors</h3>
                <span className="ml-2 bg-red-600 text-white text-xs px-2 py-1 rounded-full">
                  {errors.length}
                </span>
              </div>
              <button
                onClick={() => setIsErrorsExpanded(false)}
                className="p-1 text-gray-400 hover:text-gray-300 transition-colors"
                title="Hide errors"
              >
                <X size={16} />
              </button>
            </div>
            
            {/* Errors List */}
            <div className="p-3 space-y-2 max-h-80 overflow-y-auto">
              {errors.map((error) => (
                <div
                  key={error.id}
                  className="flex items-start gap-3 p-2 bg-gray-700 rounded-lg border border-gray-600 hover:bg-gray-650 transition-colors cursor-pointer"
                  onClick={() => {
                    setSelectedError(error);
                    setSelectedManualLog(null);
                    setSelectedItemType('error');
                    setIsErrorsExpanded(false);
                  }}
                >
                  {/* Error Icon */}
                  <div className="flex-shrink-0 mt-1">
                    <AlertTriangle size={16} className="text-red-400" />
                  </div>
                  
                  {/* Error Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-white">
                        {error.type.toUpperCase()}
                      </span>
                      <span className="text-xs text-gray-400">
                        {new Date(error.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <p className="text-sm text-gray-300 truncate">{error.message}</p>
                    {error.url && (
                      <p className="text-xs text-gray-500 truncate">{error.url}</p>
                    )}
                  </div>
                  
                  {/* Actions */}
                  <div className="flex items-center gap-1 flex-shrink-0">
                    {/* Screenshot indicator */}
                    {error.associatedScreenshots && error.associatedScreenshots.length > 0 && (
                      <div className="relative mr-1">
                        <Camera size={14} className="text-purple-400" />
                        <span className="absolute -top-1 -right-1 bg-purple-500 text-white text-xs rounded-full min-w-[16px] h-[16px] flex items-center justify-center text-[10px]">
                          {error.associatedScreenshots.length}
                        </span>
                      </div>
                    )}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        copyToClipboard(error);
                      }}
                      className="p-1.5 bg-blue-600 rounded hover:bg-blue-700 text-white transition-colors"
                      title="Copy error details"
                    >
                      <Copy size={12} />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteError(error.id);
                      }}
                      className="p-1.5 bg-red-600 rounded hover:bg-red-700 text-white transition-colors"
                      title="Delete error"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        </>
      )}

      {/* Manual Logs Section - Fixed overlay */}
      {manualLogs.length > 0 && isManualLogsExpanded && (
        <>
          {/* Backdrop to close on click outside */}
          <div 
            className="fixed inset-0 z-30"
            onClick={() => setIsManualLogsExpanded(false)}
          />
          <div className="fixed top-16 left-4 right-4 z-40 max-w-md mx-auto">
          <div className="bg-gray-800 rounded-lg border border-gray-700 shadow-2xl">
            {/* Manual Logs Header */}
            <div className="flex items-center justify-between p-3 bg-gray-750 rounded-t-lg border-b border-gray-700">
              <div className="flex items-center">
                <Plus className="mr-2 text-green-400" size={18} />
                <h3 className="text-base font-semibold">Manual Logs</h3>
                <span className="ml-2 bg-green-600 text-white text-xs px-2 py-1 rounded-full">
                  {manualLogs.length}
                </span>
              </div>
              <button
                onClick={() => setIsManualLogsExpanded(false)}
                className="p-1 text-gray-400 hover:text-gray-300 transition-colors"
                title="Hide manual logs"
              >
                <X size={16} />
              </button>
            </div>
            
            {/* Manual Logs List */}
            <div className="p-3 space-y-2 max-h-80 overflow-y-auto">
              {manualLogs.map((log) => (
                <div
                  key={log.id}
                  className="flex items-start gap-3 p-2 bg-gray-700 rounded-lg border border-gray-600 hover:bg-gray-650 transition-colors cursor-pointer"
                  onClick={() => {
                    setSelectedManualLog(log);
                    setSelectedError(null);
                    setSelectedItemType('manual');
                    setIsManualLogsExpanded(false);
                  }}
                >
                  {/* Severity Icon */}
                  <div className="flex-shrink-0 mt-1">
                    <div className={`w-3 h-3 rounded-full ${
                      log.severity === 'critical' ? 'bg-red-500' :
                      log.severity === 'warning' ? 'bg-yellow-500' : 'bg-blue-500'
                    }`} />
                  </div>
                  
                  {/* Log Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className={`text-sm font-medium ${
                        log.severity === 'critical' ? 'text-red-300' :
                        log.severity === 'warning' ? 'text-yellow-300' : 'text-blue-300'
                      }`}>
                        {log.severity.toUpperCase()}
                      </span>
                      <span className="text-xs text-gray-400">
                        {new Date(log.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <p className="text-sm text-gray-300 truncate">{log.message}</p>
                    {log.note && (
                      <p className="text-xs text-gray-500 truncate">{log.note}</p>
                    )}
                  </div>
                  
                  {/* Actions */}
                  <div className="flex items-center gap-1 flex-shrink-0">
                    {/* Screenshot indicator */}
                    {log.associatedScreenshots && log.associatedScreenshots.length > 0 && (
                      <div className="relative mr-1">
                        <Camera size={14} className="text-purple-400" />
                        <span className="absolute -top-1 -right-1 bg-purple-500 text-white text-xs rounded-full min-w-[16px] h-[16px] flex items-center justify-center text-[10px]">
                          {log.associatedScreenshots.length}
                        </span>
                      </div>
                    )}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        const logText = `Manual Log: ${log.message}\nSeverity: ${log.severity}\nTimestamp: ${new Date(log.timestamp).toLocaleString()}\nNote: ${log.note || 'None'}`;
                        navigator.clipboard.writeText(logText).catch(() => {
                          // Fallback for older browsers
                          const textarea = document.createElement('textarea');
                          textarea.value = logText;
                          document.body.appendChild(textarea);
                          textarea.select();
                          document.execCommand('copy');
                          document.body.removeChild(textarea);
                        });
                      }}
                      className="p-1.5 bg-blue-600 rounded hover:bg-blue-700 text-white transition-colors"
                      title="Copy log details"
                    >
                      <Copy size={12} />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteManualLog(log.id);
                      }}
                      className="p-1.5 bg-red-600 rounded hover:bg-red-700 text-white transition-colors"
                      title="Delete log"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        </>
      )}

      {!isChromeApiAvailable ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center text-gray-400">
            <AlertTriangle size={48} className="mx-auto mb-4 opacity-50" />
            <p className="text-lg">Chrome Extension APIs Not Available</p>
            <p className="text-sm mt-2">Please reload this extension or use it within a Chrome extension context</p>
          </div>
        </div>
      ) : errors.length === 0 && screenshots.length === 0 && manualLogs.length === 0 ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center text-gray-400">
            <AlertTriangle size={48} className="mx-auto mb-4 opacity-50" />
            <p className="text-lg">No insights captured yet</p>
            <p className="text-sm mt-2">JavaScript errors, console errors, network failures, manual logs, and page screenshots will appear here</p>
            <div className="mt-6 space-y-2">
              <p className="text-xs bg-gray-800 p-3 rounded max-w-md">
                <strong>Add manual logs:</strong> Click the <Plus size={14} className="inline mx-1" /> icon to document issues and observations
              </p>
              <p className="text-xs bg-gray-800 p-3 rounded max-w-md">
                <strong>Capture insights:</strong> Click the <Camera size={14} className="inline mx-1" /> icon to capture the current page state
              </p>
              <p className="text-xs bg-gray-800 p-3 rounded max-w-md">
                <strong>Debug errors:</strong> Run <code className="bg-gray-700 px-1 rounded">console.error('test')</code> in the browser console to see error tracking in action
              </p>
            </div>
          </div>
        </div>
      ) : (
        <div className="flex-1 overflow-hidden">
          {/* Full Width Details Panel */}
          {selectedItemType && (selectedError || selectedManualLog) && (
            <div className="h-full overflow-y-auto p-4 bg-gray-800 rounded border border-gray-700">
              {selectedItemType === 'error' && selectedError && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-red-400">Error Details</h3>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => openScreenshotAssociation('error', selectedError.id)}
                        className="p-2 text-gray-400 hover:text-purple-400 transition-colors"
                        title="Associate screenshot"
                        disabled={screenshots.length === 0}
                      >
                        <Paperclip size={16} />
                      </button>
                      <button
                        onClick={() => exportSelectedErrorToWord(selectedError)}
                        className="p-2 text-gray-400 hover:text-green-400 transition-colors"
                        title="Download error details to Word"
                      >
                        <Download size={16} />
                      </button>
                      <button
                        onClick={() => copyToClipboard(selectedError)}
                        className="p-2 text-gray-400 hover:text-blue-400 transition-colors"
                        title="Copy error details"
                      >
                        <Copy size={16} />
                      </button>
                      <button
                        onClick={() => setSelectedError(null)}
                        className="p-2 text-gray-400 hover:text-red-400 transition-colors"
                        title="Close details"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <span className="font-medium text-gray-300">Type:</span>
                      <span className="ml-2 text-red-300">{selectedError.type}</span>
                    </div>
                    
                    <div>
                      <span className="font-medium text-gray-300">Message:</span>
                      <p className="mt-1 p-3 bg-gray-900 rounded text-red-200">{selectedError.message}</p>
                    </div>

                    {selectedError.stack && (
                      <div>
                        <span className="font-medium text-gray-300">Stack Trace:</span>
                        <pre className="mt-1 p-3 bg-gray-900 rounded text-xs text-gray-300 overflow-x-auto whitespace-pre-wrap max-h-48 overflow-y-auto">
                          {selectedError.stack}
                        </pre>
                      </div>
                    )}

                    <div>
                      <span className="font-medium text-gray-300">Timestamp:</span>
                      <span className="ml-2 text-gray-400">{new Date(selectedError.timestamp).toLocaleString()}</span>
                    </div>

                    {selectedError.url && (
                      <div>
                        <span className="font-medium text-gray-300">Source URL:</span>
                        <p className="mt-1 p-3 bg-gray-900 rounded text-blue-300 break-all">{selectedError.url}</p>
                        <p className="text-xs text-gray-500 mt-1">The specific file or resource where this error originated</p>
                      </div>
                    )}

                    {(selectedError.lineNumber || selectedError.columnNumber) && (
                      <div>
                        <span className="font-medium text-gray-300">Location:</span>
                        <span className="ml-2 text-gray-400">
                          Line {selectedError.lineNumber}, Column {selectedError.columnNumber}
                        </span>
                      </div>
                    )}

                    {selectedError.source && (
                      <div>
                        <span className="font-medium text-gray-300">Source:</span>
                        <p className="mt-1 p-3 bg-gray-900 rounded text-gray-300 break-all">{selectedError.source}</p>
                      </div>
                    )}

                    <div>
                      <span className="font-medium text-gray-300">User Agent:</span>
                      <p className="mt-1 p-3 bg-gray-900 rounded text-gray-400 text-sm break-all">{selectedError.userAgent}</p>
                    </div>

                    <div>
                      <span className="font-medium text-gray-300">Page URL:</span>
                      <p className="mt-1 p-3 bg-gray-900 rounded text-blue-300 break-all">{selectedError.pageUrl}</p>
                    </div>

                    {selectedError.networkDetails && (
                      <div>
                        <span className="font-medium text-gray-300">Network Details:</span>
                        <div className="mt-1 p-3 bg-gray-900 rounded">
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <div><span className="text-gray-400">Method:</span> <span className="text-white">{selectedError.networkDetails.method}</span></div>
                            <div><span className="text-gray-400">Status:</span> <span className="text-white">{selectedError.networkDetails.status} {selectedError.networkDetails.statusText}</span></div>
                          </div>
                          {selectedError.networkDetails.responseText && (
                            <div className="mt-2">
                              <span className="text-gray-400">Response:</span>
                              <pre className="mt-1 text-xs text-gray-300 whitespace-pre-wrap">{selectedError.networkDetails.responseText}</pre>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {selectedError.reproductionSteps && selectedError.reproductionSteps.length > 0 && (
                      <div>
                        <span className="font-medium text-gray-300">Reproduction Steps:</span>
                        <div className="mt-1 p-3 bg-gray-900 rounded">
                          <ol className="list-decimal list-inside space-y-1">
                            {selectedError.reproductionSteps.map((step, index) => (
                              <li key={index} className="text-sm text-green-300">{step}</li>
                            ))}
                          </ol>
                        </div>
                      </div>
                    )}

                    {selectedError.userJourney && selectedError.userJourney.length > 0 && (
                      <div>
                        <span className="font-medium text-gray-300">User Journey (Last {selectedError.userJourney.length} actions):</span>
                        <div className="mt-1 p-2 bg-gray-900 rounded max-h-48 overflow-y-auto">
                          {selectedError.userJourney.map((step, index) => {
                            const timeAgo = Math.round((selectedError.timestamp - step.timestamp) / 1000);
                            return (
                              <div key={index} className="text-sm mb-2 p-2 bg-yellow-900 bg-opacity-30 rounded">
                                <span className="text-yellow-300 font-medium">{index + 1}. [{timeAgo}s ago]</span>
                                <span className="text-white ml-2">{step.type.toUpperCase()}: {step.value}</span>
                                {step.element && <div className="text-gray-400 ml-6 text-xs">Element: {step.element}</div>}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {selectedError.networkContext && selectedError.networkContext.length > 0 && (
                      <div>
                        <span className="font-medium text-gray-300">Network Context (Recent requests):</span>
                        <div className="mt-1 p-2 bg-gray-900 rounded max-h-48 overflow-y-auto">
                          {selectedError.networkContext.map((req, index) => {
                            const timeAgo = Math.round((selectedError.timestamp - req.timestamp) / 1000);
                            const statusColor = req.status >= 400 ? 'text-red-300' : req.status >= 300 ? 'text-yellow-300' : 'text-green-300';
                            return (
                              <div key={index} className="text-sm mb-2 p-2 bg-blue-900 bg-opacity-30 rounded">
                                <div className="flex justify-between items-start">
                                  <span className="text-blue-300 font-medium">{index + 1}. [{timeAgo}s ago]</span>
                                  <span className={`text-xs ${statusColor}`}>{req.status} {req.statusText}</span>
                                </div>
                                <div className="text-white mt-1">{req.method} {req.url}</div>
                                {req.duration && <div className="text-gray-400 text-xs">Duration: {req.duration}ms</div>}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {selectedError.environmentInfo && (
                      <div>
                        <span className="font-medium text-gray-300">Environment Info:</span>
                        <div className="mt-1 p-3 bg-gray-900 rounded">
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <div><span className="text-gray-400">Viewport:</span> <span className="text-white">{selectedError.environmentInfo.viewport}</span></div>
                            <div><span className="text-gray-400">Cookies:</span> <span className="text-white">{selectedError.environmentInfo.cookiesEnabled ? 'Enabled' : 'Disabled'}</span></div>
                            <div><span className="text-gray-400">Online:</span> <span className="text-white">{selectedError.environmentInfo.onlineStatus ? 'Yes' : 'No'}</span></div>
                            <div><span className="text-gray-400">Referrer:</span> <span className="text-white break-all">{selectedError.environmentInfo.referrer || 'None'}</span></div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Associated Screenshots */}
                    {selectedError.associatedScreenshots && selectedError.associatedScreenshots.length > 0 && (
                      <div className="mt-4 border-t border-gray-700 pt-4">
                        <div className="mb-3">
                          <span className="font-medium text-gray-300">Associated Screenshots ({selectedError.associatedScreenshots.length}):</span>
                        </div>
                        <div className="p-3 bg-gray-900 rounded border border-gray-700">
                          <div className="grid grid-cols-1 gap-3">
                            {selectedError.associatedScreenshots.map((screenshotId, index) => {
                              const screenshot = getScreenshotById(screenshotId);
                              if (!screenshot) return null;
                              return (
                                <div key={screenshotId} className="border border-gray-600 rounded p-3 bg-gray-800">
                                  <div className="flex justify-between items-start mb-3">
                                    <div>
                                      <div className="text-sm font-medium text-purple-300">Screenshot #{index + 1}: {screenshot.title}</div>
                                      <div className="text-xs text-gray-400">Captured: {new Date(screenshot.timestamp).toLocaleString()}</div>
                                    </div>
                                    <button
                                      onClick={() => removeScreenshotAssociation('error', selectedError.id, screenshotId)}
                                      className="p-1 text-gray-400 hover:text-red-400 transition-colors"
                                      title="Remove association"
                                    >
                                      <X size={12} />
                                    </button>
                                  </div>
                                  <img 
                                    src={screenshot.dataUrl} 
                                    alt={screenshot.title}
                                    className="w-full max-w-md h-auto border border-gray-600 rounded cursor-pointer hover:border-purple-400 transition-colors"
                                    onClick={() => openScreenshotViewer(screenshot)}
                                  />
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {selectedItemType === 'manual' && selectedManualLog && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-green-400">Manual Log Details</h3>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => openScreenshotAssociation('manual', selectedManualLog.id)}
                        className="p-2 text-gray-400 hover:text-purple-400 transition-colors"
                        title="Associate screenshot"
                        disabled={screenshots.length === 0}
                      >
                        <Paperclip size={16} />
                      </button>
                      <button
                        onClick={() => exportSelectedManualLogToWord(selectedManualLog)}
                        className="p-2 text-gray-400 hover:text-green-400 transition-colors"
                        title="Download log details to Word"
                      >
                        <Download size={16} />
                      </button>
                      <button
                        onClick={() => {
                          const logText = `Manual Log: ${selectedManualLog.message}\nSeverity: ${selectedManualLog.severity}\nTimestamp: ${new Date(selectedManualLog.timestamp).toLocaleString()}\nNote: ${selectedManualLog.note || 'None'}`;
                          navigator.clipboard.writeText(logText).catch(() => {
                            const textarea = document.createElement('textarea');
                            textarea.value = logText;
                            document.body.appendChild(textarea);
                            textarea.select();
                            document.execCommand('copy');
                            document.body.removeChild(textarea);
                          });
                        }}
                        className="p-2 text-gray-400 hover:text-blue-400 transition-colors"
                        title="Copy log details"
                      >
                        <Copy size={16} />
                      </button>
                      <button
                        onClick={() => setSelectedManualLog(null)}
                        className="p-2 text-gray-400 hover:text-red-400 transition-colors"
                        title="Close details"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <span className="font-medium text-gray-300">Severity:</span>
                      <span className={`ml-2 ${
                        selectedManualLog.severity === 'critical' ? 'text-red-300' :
                        selectedManualLog.severity === 'warning' ? 'text-yellow-300' : 'text-blue-300'
                      }`}>
                        {selectedManualLog.severity.toUpperCase()}
                      </span>
                    </div>
                    
                    <div>
                      <span className="font-medium text-gray-300">Message:</span>
                      <p className="mt-1 p-3 bg-gray-900 rounded text-white">{selectedManualLog.message}</p>
                    </div>

                    {selectedManualLog.note && (
                      <div>
                        <span className="font-medium text-gray-300">Notes:</span>
                        <p className="mt-1 p-3 bg-gray-900 rounded text-gray-300">{selectedManualLog.note}</p>
                      </div>
                    )}

                    <div>
                      <span className="font-medium text-gray-300">Timestamp:</span>
                      <span className="ml-2 text-gray-400">{new Date(selectedManualLog.timestamp).toLocaleString()}</span>
                    </div>

                    {selectedManualLog.pageUrl && (
                      <div>
                        <span className="font-medium text-gray-300">Page URL:</span>
                        <p className="mt-1 p-3 bg-gray-900 rounded text-blue-300 break-all">{selectedManualLog.pageUrl}</p>
                      </div>
                    )}

                    {selectedManualLog.userAgent && (
                      <div>
                        <span className="font-medium text-gray-300">User Agent:</span>
                        <p className="mt-1 p-3 bg-gray-900 rounded text-gray-400 text-sm break-all">{selectedManualLog.userAgent}</p>
                      </div>
                    )}

                    {selectedManualLog.reproductionSteps && selectedManualLog.reproductionSteps.length > 0 && (
                      <div>
                        <span className="font-medium text-gray-300">Reproduction Steps:</span>
                        <div className="mt-1 p-3 bg-gray-900 rounded">
                          <ol className="list-decimal list-inside space-y-1">
                            {selectedManualLog.reproductionSteps.map((step, index) => (
                              <li key={index} className="text-sm text-green-300">{step}</li>
                            ))}
                          </ol>
                        </div>
                      </div>
                    )}

                    {selectedManualLog.userJourney && selectedManualLog.userJourney.length > 0 && (
                      <div>
                        <span className="font-medium text-gray-300">User Journey (Last {selectedManualLog.userJourney.length} actions):</span>
                        <div className="mt-1 p-2 bg-gray-900 rounded max-h-48 overflow-y-auto">
                          {selectedManualLog.userJourney.map((step, index) => {
                            const timeAgo = Math.round((selectedManualLog.timestamp - step.timestamp) / 1000);
                            return (
                              <div key={index} className="text-sm mb-2 p-2 bg-yellow-900 bg-opacity-30 rounded">
                                <span className="text-yellow-300 font-medium">{index + 1}. [{timeAgo}s ago]</span>
                                <span className="text-white ml-2">{step.type.toUpperCase()}: {step.value}</span>
                                {step.element && <div className="text-gray-400 ml-6 text-xs">Element: {step.element}</div>}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {selectedManualLog.networkContext && selectedManualLog.networkContext.length > 0 && (
                      <div>
                        <span className="font-medium text-gray-300">Network Context (Recent requests):</span>
                        <div className="mt-1 p-2 bg-gray-900 rounded max-h-48 overflow-y-auto">
                          {selectedManualLog.networkContext.map((req, index) => {
                            const timeAgo = Math.round((selectedManualLog.timestamp - req.timestamp) / 1000);
                            const statusColor = req.status >= 400 ? 'text-red-300' : req.status >= 300 ? 'text-yellow-300' : 'text-green-300';
                            return (
                              <div key={index} className="text-sm mb-2 p-2 bg-blue-900 bg-opacity-30 rounded">
                                <div className="flex justify-between items-start">
                                  <span className="text-blue-300 font-medium">{index + 1}. [{timeAgo}s ago]</span>
                                  <span className={`text-xs ${statusColor}`}>{req.status} {req.statusText}</span>
                                </div>
                                <div className="text-white mt-1">{req.method} {req.url}</div>
                                {req.duration && <div className="text-gray-400 text-xs">Duration: {req.duration}ms</div>}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {selectedManualLog.environmentInfo && (
                      <div>
                        <span className="font-medium text-gray-300">Environment Info:</span>
                        <div className="mt-1 p-3 bg-gray-900 rounded">
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <div><span className="text-gray-400">Viewport:</span> <span className="text-white">{selectedManualLog.environmentInfo.viewport}</span></div>
                            <div><span className="text-gray-400">Cookies:</span> <span className="text-white">{selectedManualLog.environmentInfo.cookiesEnabled ? 'Enabled' : 'Disabled'}</span></div>
                            <div><span className="text-gray-400">Online:</span> <span className="text-white">{selectedManualLog.environmentInfo.onlineStatus ? 'Yes' : 'No'}</span></div>
                            <div><span className="text-gray-400">Referrer:</span> <span className="text-white break-all">{selectedManualLog.environmentInfo.referrer || 'None'}</span></div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Associated Screenshots */}
                    {selectedManualLog.associatedScreenshots && selectedManualLog.associatedScreenshots.length > 0 && (
                      <div className="mt-4 border-t border-gray-700 pt-4">
                        <div className="mb-3">
                          <span className="font-medium text-gray-300">Associated Screenshots ({selectedManualLog.associatedScreenshots.length}):</span>
                        </div>
                        <div className="p-3 bg-gray-900 rounded border border-gray-700">
                          <div className="grid grid-cols-1 gap-3">
                            {selectedManualLog.associatedScreenshots.map((screenshotId, index) => {
                              const screenshot = getScreenshotById(screenshotId);
                              if (!screenshot) return null;
                              return (
                                <div key={screenshotId} className="border border-gray-600 rounded p-3 bg-gray-800">
                                  <div className="flex justify-between items-start mb-3">
                                    <div>
                                      <div className="text-sm font-medium text-purple-300">Screenshot #{index + 1}: {screenshot.title}</div>
                                      <div className="text-xs text-gray-400">Captured: {new Date(screenshot.timestamp).toLocaleString()}</div>
                                    </div>
                                    <button
                                      onClick={() => removeScreenshotAssociation('manual', selectedManualLog.id, screenshotId)}
                                      className="p-1 text-gray-400 hover:text-red-400 transition-colors"
                                      title="Remove association"
                                    >
                                      <X size={12} />
                                    </button>
                                  </div>
                                  <img 
                                    src={screenshot.dataUrl} 
                                    alt={screenshot.title}
                                    className="w-full max-w-md h-auto border border-gray-600 rounded cursor-pointer hover:border-purple-400 transition-colors"
                                    onClick={() => openScreenshotViewer(screenshot)}
                                  />
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          ) || (
            <div className="h-full flex items-center justify-center text-gray-400">
              <div className="text-center">
                <AlertTriangle size={48} className="mx-auto mb-4 opacity-50" />
                <p className="text-lg">Select an item to view details</p>
                <p className="text-sm mt-1">Click on an error or manual log from the lists above</p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* JSON Viewer Modal */}
      {jsonViewerData && (
        <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50">
          <div className="bg-gray-900 border border-gray-600 rounded-lg max-w-4xl max-h-[90vh] w-[90vw] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-gray-600">
              <h3 className="text-lg font-semibold text-white">{jsonViewerData.title}</h3>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    const textToCopy = typeof jsonViewerData.data === 'object' && 'type' in jsonViewerData.data
                      ? formatErrorForCopy(jsonViewerData.data as ErrorContext)
                      : JSON.stringify(jsonViewerData.data, null, 2);
                    
                    // Create a larger, more visible textarea with the content
                    const textarea = document.createElement('textarea');
                    textarea.value = textToCopy;
                    textarea.style.position = 'fixed';
                    textarea.style.top = '50%';
                    textarea.style.left = '50%';
                    textarea.style.transform = 'translate(-50%, -50%)';
                    textarea.style.width = '80vw';
                    textarea.style.height = '70vh';
                    textarea.style.maxWidth = '800px';
                    textarea.style.maxHeight = '600px';
                    textarea.style.minWidth = '500px';
                    textarea.style.minHeight = '400px';
                    textarea.style.zIndex = '10000';
                    textarea.style.background = '#1f2937';
                    textarea.style.color = '#e5e7eb';
                    textarea.style.border = '2px solid #60a5fa';
                    textarea.style.borderRadius = '8px';
                    textarea.style.padding = '16px';
                    textarea.style.fontSize = '14px';
                    textarea.style.fontFamily = 'Consolas, Monaco, "Courier New", monospace';
                    textarea.style.boxShadow = '0 20px 50px rgba(0, 0, 0, 0.8)';
                    textarea.readOnly = true;
                    textarea.style.resize = 'both';
                    textarea.style.overflow = 'auto';
                    
                    // Create overlay background
                    const overlay = document.createElement('div');
                    overlay.style.position = 'fixed';
                    overlay.style.top = '0';
                    overlay.style.left = '0';
                    overlay.style.width = '100%';
                    overlay.style.height = '100%';
                    overlay.style.background = 'rgba(0, 0, 0, 0.8)';
                    overlay.style.zIndex = '9999';
                    
                    document.body.appendChild(overlay);
                    document.body.appendChild(textarea);
                    textarea.focus();
                    textarea.select();
                    
                    // Try to copy automatically
                    try {
                      document.execCommand('copy');
                    } catch {
                      // Silent failure - user can copy manually
                    }
                    
                    // Remove elements when user clicks outside or presses escape
                    const cleanup = () => {
                      if (document.body.contains(textarea)) {
                        document.body.removeChild(textarea);
                      }
                      if (document.body.contains(overlay)) {
                        document.body.removeChild(overlay);
                      }
                      document.removeEventListener('click', cleanup);
                      document.removeEventListener('keydown', escapeHandler);
                    };
                    
                    const escapeHandler = (e: KeyboardEvent) => {
                      if (e.key === 'Escape') {
                        cleanup();
                      }
                    };
                    
                    // Close when clicking on overlay (but not textarea)
                    overlay.addEventListener('click', cleanup);
                    
                    // Prevent clicks on the textarea from closing the modal
                    textarea.addEventListener('click', (e) => {
                      e.stopPropagation();
                    });
                    
                    // Add keyboard listener
                    document.addEventListener('keydown', escapeHandler);
                  }}
                  className="p-2 text-gray-400 hover:text-blue-400 transition-colors"
                  title="Copy content"
                >
                  <Copy size={16} />
                </button>
                <button
                  onClick={closeJsonViewer}
                  className="p-2 text-gray-400 hover:text-red-400 transition-colors"
                  title="Close"
                >
                  ✕
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-auto p-4">
              <div className="bg-gray-800 rounded p-4 font-mono text-sm">
                <JsonTree data={jsonViewerData.data} />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Screenshot Viewer Modal with Annotation */}
      {viewingScreenshot && (
        <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50">
          <div className="max-w-[85vw] max-h-[85vh] flex flex-col bg-gray-900 rounded-lg shadow-2xl">
            {/* Header - More Compact */}
            <div className="flex items-center justify-between p-3 bg-gray-800 rounded-t-lg border-b border-gray-700">
              <div className="flex items-center space-x-3">
                <h3 className="text-lg font-semibold text-white truncate max-w-md">{viewingScreenshot.title}</h3>
                <span className="text-xs text-gray-400 bg-gray-700 px-2 py-1 rounded">
                  {new Date(viewingScreenshot.timestamp).toLocaleString()}
                </span>
              </div>
              <div className="flex items-center gap-2">
                {!isAnnotating ? (
                  <>
                    <button
                      onClick={startAnnotation}
                      className="p-2 text-gray-400 hover:text-blue-400 transition-colors rounded hover:bg-gray-700"
                      title="Start annotating"
                    >
                      <Pen size={16} />
                    </button>
                    <button
                      onClick={() => downloadScreenshot(viewingScreenshot)}
                      className="p-2 text-gray-400 hover:text-green-400 transition-colors rounded hover:bg-gray-700"
                      title="Download screenshot"
                    >
                      <Download size={16} />
                    </button>
                  </>
                ) : (
                  <>
                    <button
                      onClick={saveAnnotation}
                      className="p-2 text-gray-400 hover:text-green-400 transition-colors rounded hover:bg-gray-700"
                      title="Save annotations"
                    >
                      <Save size={16} />
                    </button>
                    <button
                      onClick={stopAnnotation}
                      className="p-2 text-gray-400 hover:text-red-400 transition-colors rounded hover:bg-gray-700"
                      title="Cancel annotation"
                    >
                      <X size={16} />
                    </button>
                  </>
                )}
                <button
                  onClick={closeScreenshotViewer}
                  className="p-2 text-gray-400 hover:text-red-400 transition-colors rounded hover:bg-gray-700"
                  title="Close"
                >
                  ✕
                </button>
              </div>
            </div>
            
            {/* Annotation Toolbar - More Compact */}
            {isAnnotating && (
              <div className="flex items-center gap-3 p-2 bg-gray-800 border-b border-gray-700">
                <div className="flex items-center gap-2">
                  <Pen size={14} className="text-blue-400" />
                  <span className="text-xs text-gray-300">Pen</span>
                </div>
                
                <div className="h-4 w-px bg-gray-600"></div>
                
                <div className="flex items-center gap-2">
                  <Palette size={14} className="text-gray-400" />
                  <input
                    type="color"
                    value={penColor}
                    onChange={(e) => setPenColor(e.target.value)}
                    className="w-6 h-6 rounded border border-gray-600 cursor-pointer"
                    title="Choose pen color"
                  />
                  <span className="text-xs text-gray-400">Size:</span>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={penSize}
                    onChange={(e) => setPenSize(parseInt(e.target.value))}
                    className="w-12"
                    title="Pen size"
                  />
                  <span className="text-xs text-gray-400 w-3">{penSize}</span>
                </div>
                
                <div className="h-4 w-px bg-gray-600"></div>
                
                <button
                  onClick={undoAnnotation}
                  disabled={annotationHistoryIndex <= 0}
                  className="p-1 rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed bg-blue-600 hover:bg-blue-700 disabled:hover:bg-blue-600 text-white"
                  title="Undo last annotation"
                >
                  <Undo size={14} />
                </button>
              </div>
            )}

            {/* Image Container - Optimized Size */}
            <div className="bg-gray-800 rounded-b-lg overflow-hidden flex items-center justify-center relative p-2">
              {isAnnotating ? (
                <div className="relative">
                  <canvas
                    ref={canvasRef}
                    className="border border-gray-600 bg-white cursor-crosshair rounded"
                    onMouseDown={startDrawing}
                    onMouseMove={draw}
                    onMouseUp={stopDrawing}
                    onMouseLeave={stopDrawing}
                    style={{
                      maxWidth: '85vw',
                      maxHeight: '70vh',
                      width: 'auto',
                      height: 'auto',
                      objectFit: 'contain',
                      imageRendering: 'crisp-edges'
                    }}
                  />
                </div>
              ) : (
                <img 
                  src={viewingScreenshot.dataUrl} 
                  alt="Page Screenshot"
                  className="max-w-full max-h-[75vh] object-contain rounded"
                  style={{ 
                    display: 'block', 
                    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)',
                    backgroundColor: 'white',
                    imageRendering: 'crisp-edges'
                  }}
                />
              )}
            </div>
          </div>
          {/* Click outside to close */}
          <div 
            className="absolute inset-0 -z-10"
            onClick={closeScreenshotViewer}
          />
        </div>
      )}

      {/* Add Manual Log Modal */}
      {showAddLogModal && (
        <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50">
          <div className="bg-gray-900 border border-gray-600 rounded-lg max-w-2xl w-[90vw] p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white">Add Manual Debug Log</h3>
              <button
                onClick={() => setShowAddLogModal(false)}
                className="text-gray-400 hover:text-red-400 transition-colors"
              >
                <X size={20} />
              </button>
            </div>
            
            <div className="space-y-4">
              {/* Severity Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Severity Level</label>
                <div className="flex space-x-3">
                  {(['info', 'warning', 'critical'] as const).map((severity) => (
                    <button
                      key={severity}
                      onClick={() => setNewLogData(prev => ({ ...prev, severity }))
                      }
                      className={`px-4 py-2 rounded text-sm font-medium transition-colors ${
                        newLogData.severity === severity 
                          ? getSeverityBg(severity) + ' ' + getSeverityColor(severity) + ' border border-current'
                          : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                      }`}
                    >
                      {severity.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>

              {/* Message */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Issue/Observation *</label>
                <input
                  type="text"
                  value={newLogData.message}
                  onChange={(e) => setNewLogData(prev => ({ ...prev, message: e.target.value }))
                  }
                  placeholder="e.g., User data not loading correctly, API response delayed, UI element misaligned..."
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                  autoFocus
                />
              </div>

              {/* Note */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Detailed Notes (Optional)</label>
                <textarea
                  value={newLogData.note}
                  onChange={(e) => setNewLogData(prev => ({ ...prev, note: e.target.value }))
                  }
                  placeholder="Add detailed observations, steps to reproduce, expected vs actual behavior, potential causes, etc..."
                  rows={4}
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500 resize-vertical"
                />
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end space-x-3 pt-4">
                <button
                  onClick={() => setShowAddLogModal(false)}
                  className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={addManualLog}
                  disabled={!newLogData.message.trim()}
                  className="px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-green-800 disabled:cursor-not-allowed text-white rounded transition-colors"
                >
                  Add Log
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Screenshot Association Modal */}
      {showScreenshotAssociation && associationTarget && (
        <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50">
          <div className="bg-gray-900 border border-gray-600 rounded-lg max-w-4xl max-h-[90vh] w-[90vw] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-gray-600">
              <h3 className="text-lg font-semibold text-white">
                Associate Screenshot with {associationTarget.type === 'error' ? 'Error' : 'Manual Log'}
              </h3>
              <button
                onClick={closeScreenshotAssociation}
                className="p-2 text-gray-400 hover:text-red-400 transition-colors"
                title="Close"
              >
                <X size={16} />
              </button>
            </div>
            <div className="flex-1 p-4 overflow-y-auto">
              {screenshots.length === 0 ? (
                <div className="text-center text-gray-400 py-8">
                  <Camera size={48} className="mx-auto mb-4 opacity-50" />
                  <p>No screenshots available to associate</p>
                  <p className="text-sm mt-2">Capture a screenshot first to associate it with this {associationTarget.type}</p>
                </div>
              ) : (
                <div>
                  <p className="text-gray-300 mb-4">
                    Select a screenshot to associate with this {associationTarget.type}:
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {screenshots.map((screenshot) => (
                      <div key={screenshot.id} className="border border-gray-700 rounded p-3 hover:border-purple-400 transition-colors">
                        <div className="mb-2">
                          <div className="text-sm font-medium text-purple-300">{screenshot.title}</div>
                          <div className="text-xs text-gray-400">
                            Captured: {new Date(screenshot.timestamp).toLocaleString()}
                          </div>
                        </div>
                        <img 
                          src={screenshot.dataUrl} 
                          alt={screenshot.title}
                          className="w-full h-32 object-cover border border-gray-600 rounded mb-2"
                        />
                        <button
                          onClick={() => associateScreenshot(screenshot.id)}
                          className="w-full px-3 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded text-sm transition-colors"
                        >
                          Associate This Screenshot
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ErrorContextTab;

// Manual Log interface for user-added observations
interface ManualLog {
  id: string;
  message: string;
  note: string;
  timestamp: number;
  severity: 'info' | 'warning' | 'critical';
  pageUrl: string;
  userAgent: string;
  userJourney?: JourneyStep[];
  networkContext?: NetworkRequest[];
  reproductionSteps?: string[];
  environmentInfo?: {
    viewport: string;
    cookiesEnabled: boolean;
    onlineStatus: boolean;
    referrer: string;
  };
  // Associated screenshots
  associatedScreenshots?: string[]; // Array of screenshot IDs
}
