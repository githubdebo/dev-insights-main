import React, { useState, useRef, useEffect } from 'react';
import { Upload, Download, FileText, CheckCircle, AlertCircle, Trash2, FolderOpen, Send, Plus, X, RefreshCw, Save, ChevronDown, ChevronRight, Copy, Eye } from 'lucide-react';

interface PostmanCollection {
  info: {
    name: string;
    description?: string;
    schema: string;
  };
  item: PostmanItem[];
}

interface PostmanItem {
  name: string;
  request?: {
    method: string;
    header?: Array<{ key: string; value: string; disabled?: boolean }>;
    url: string | { raw: string; host: string[]; path: string[] };
    body?: {
      mode: string;
      raw?: string;
      formdata?: Array<{ key: string; value: string; type: string }>;
    };
    auth?: any;
  };
  item?: PostmanItem[];
}

interface ImportedRequest {
  id: string;
  name: string;
  method: string;
  url: string;
  headers: Record<string, string>;
  body?: string;
  collectionName: string;
  folder?: string;
  params?: Record<string, string>;
  auth?: {
    type: 'none' | 'bearer' | 'basic' | 'api-key';
    token?: string;
    username?: string;
    password?: string;
    key?: string;
    value?: string;
    addTo?: 'header' | 'query';
  };
  bodyType?: 'none' | 'raw' | 'form-data' | 'x-www-form-urlencoded';
  formData?: Array<{ key: string; value: string; type: 'text' | 'file' }>;
  urlEncodedData?: Record<string, string>;
  fetchOptions?: {
    mode?: 'cors' | 'no-cors' | 'same-origin';
    credentials?: 'include' | 'same-origin' | 'omit';
    cache?: 'default' | 'no-cache' | 'reload' | 'force-cache' | 'only-if-cached';
    redirect?: 'follow' | 'manual' | 'error';
  };
  cookies?: Record<string, string>;
}

interface ExecutionRequest {
  id: string;
  name: string;
  method: string;
  url: string;
  headers: Record<string, string>;
  body: string;
  loading?: boolean;
  response?: {
    status: number;
    statusText: string;
    headers: Record<string, string>;
    body: string;
    duration: number;
  };
  params?: Record<string, string>;
  auth?: {
    type: 'none' | 'bearer' | 'basic' | 'api-key';
    token?: string;
    username?: string;
    password?: string;
    key?: string;
    value?: string;
    addTo?: 'header' | 'query';
  };
  bodyType?: 'none' | 'raw' | 'form-data' | 'x-www-form-urlencoded';
  formData?: Array<{ key: string; value: string; type: 'text' | 'file' }>;
  urlEncodedData?: Record<string, string>;
  fetchOptions?: {
    mode?: 'cors' | 'no-cors' | 'same-origin';
    credentials?: 'include' | 'same-origin' | 'omit';
    cache?: 'default' | 'no-cache' | 'reload' | 'force-cache' | 'only-if-cached';
    redirect?: 'follow' | 'manual' | 'error';
  };
  cookies?: Record<string, string>;
}

interface ApiCollectionsTabProps {
  onSendToApiTester?: (request: {
    url: string;
    method: string;
    headers: Array<{ key: string; value: string }>;
    body?: string;
    name?: string;
  }) => void;
}

export const ApiCollectionsTab: React.FC<ApiCollectionsTabProps> = ({ onSendToApiTester }) => {
  const [importedCollections, setImportedCollections] = useState<PostmanCollection[]>([]);
  const [importedRequests, setImportedRequests] = useState<ImportedRequest[]>([]);
  const [selectedCollection, setSelectedCollection] = useState<PostmanCollection | null>(null);
  const [selectedRequest, setSelectedRequest] = useState<ImportedRequest | null>(null);
  const [expandedCollections, setExpandedCollections] = useState<Set<string>>(new Set());
  const [isImporting, setIsImporting] = useState(false);
  const [importStatus, setImportStatus] = useState<{ type: 'success' | 'error' | null; message: string }>({ type: null, message: '' });
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Execution state
  const [executionRequest, setExecutionRequest] = useState<ExecutionRequest | null>(null);
  const [executionStatus, setExecutionStatus] = useState<{ type: 'success' | 'error' | null; message: string; showScrollHint?: boolean }>({ type: null, message: '', showScrollHint: false });

  // Collapsible headers state
  const [requestHeadersCollapsed, setRequestHeadersCollapsed] = useState(true);
  const [responseHeadersCollapsed, setResponseHeadersCollapsed] = useState(true);

  // Collections panel visibility state
  const [collectionsCollapsed, setCollectionsCollapsed] = useState(false);

  // Storage management state
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  // New collection creation state
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newCollectionName, setNewCollectionName] = useState('');
  const [newCollectionDescription, setNewCollectionDescription] = useState('');

  // Request configuration tabs state
  const [activeRequestTab, setActiveRequestTab] = useState<'params' | 'auth' | 'headers' | 'body' | 'fetch' | 'cookies'>('params');

  // Add custom scrollbar styles
  React.useEffect(() => {
    const style = document.createElement('style');
    style.textContent = `
      .collections-scroll::-webkit-scrollbar {
        width: 8px;
      }
      .collections-scroll::-webkit-scrollbar-track {
        background: #1F2937;
        border-radius: 4px;
      }
      .collections-scroll::-webkit-scrollbar-thumb {
        background: #4B5563;
        border-radius: 4px;
      }
      .collections-scroll::-webkit-scrollbar-thumb:hover {
        background: #6B7280;
      }
      .collections-scroll {
        scrollbar-width: thin;
        scrollbar-color: #4B5563 #1F2937;
        padding-bottom: 20px;
      }
    `;
    document.head.appendChild(style);

    return () => {
      document.head.removeChild(style);
    };
  }, []);

  // Auto-hide import status after 3 seconds
  useEffect(() => {
    if (importStatus.type) {
      const timer = setTimeout(() => {
        setImportStatus({ type: null, message: '' });
      }, 3000);

      return () => clearTimeout(timer);
    }
  }, [importStatus.type]);

  // Auto-hide execution status after 3 seconds
  useEffect(() => {
    if (executionStatus.type) {
      const timer = setTimeout(() => {
        setExecutionStatus({ type: null, message: '', showScrollHint: false });
      }, 3000);

      return () => clearTimeout(timer);
    }
  }, [executionStatus.type]);

  // Storage management functions
  const STORAGE_KEY = 'dev-insights-api-collections';

  const saveToLocalStorage = () => {
    try {
      const dataToSave = {
        collections: importedCollections,
        requests: importedRequests,
        savedAt: new Date().toISOString(),
        version: '1.0'
      };
      
      localStorage.setItem(STORAGE_KEY, JSON.stringify(dataToSave));
      setHasUnsavedChanges(false);
      setImportStatus({ type: 'success', message: 'Collections saved to local storage!' });
      
      return true;
    } catch (error) {
      console.error('Failed to save to localStorage:', error);
      setImportStatus({ type: 'error', message: 'Failed to save collections. Storage may be full.' });
      return false;
    }
  };

  const loadFromLocalStorage = () => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const data = JSON.parse(stored);
        setImportedCollections(data.collections || []);
        setImportedRequests(data.requests || []);
        setHasUnsavedChanges(false);
        setImportStatus({ type: 'success', message: `Loaded ${data.collections?.length || 0} collections from storage` });
        return true;
      }
      return false;
    } catch (error) {
      console.error('Failed to load from localStorage:', error);
      setImportStatus({ type: 'error', message: 'Failed to load saved collections' });
      return false;
    }
  };

  const exportCollections = () => {
    try {
      const exportData = {
        collections: importedCollections,
        requests: importedRequests,
        metadata: {
          exportedAt: new Date().toISOString(),
          exportedBy: 'Developer Insights Extension',
          version: '1.0',
          totalCollections: importedCollections.length,
          totalRequests: importedRequests.length
        }
      };

      const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `api-collections-export-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setImportStatus({ type: 'success', message: 'Collections exported successfully!' });
    } catch (error) {
      console.error('Failed to export collections:', error);
      setImportStatus({ type: 'error', message: 'Failed to export collections' });
    }
  };

  const importFromFile = async () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;

      try {
        const content = await file.text();
        const data = JSON.parse(content);
        
        // Check if it's our export format or standard Postman format
        if (data.metadata && data.collections) {
          // Our export format
          const existingCollectionNames = importedCollections.map(c => c.info.name);
          const newCollections = data.collections.filter((c: PostmanCollection) => 
            !existingCollectionNames.includes(c.info.name)
          );
          
          if (newCollections.length === 0) {
            setImportStatus({ type: 'error', message: 'All collections already exist' });
            return;
          }
          
          setImportedCollections(prev => [...prev, ...newCollections]);
          setImportedRequests(prev => [...prev, ...data.requests]);
          setImportStatus({ 
            type: 'success', 
            message: `Imported ${newCollections.length} collections from file` 
          });
        } else if (data.info && data.info.schema) {
          // Standard Postman collection format
          const requests = extractRequestsFromCollection(data);
          setImportedCollections(prev => [...prev, data]);
          setImportedRequests(prev => [...prev, ...requests]);
          setImportStatus({ 
            type: 'success', 
            message: `Imported collection "${data.info.name}" from file` 
          });
        } else {
          setImportStatus({ type: 'error', message: 'Invalid file format' });
        }
      } catch (error) {
        console.error('Import error:', error);
        setImportStatus({ type: 'error', message: 'Failed to import file' });
      }
    };
    input.click();
  };

  // Auto-load on component mount
  useEffect(() => {
    loadFromLocalStorage();
  }, []);

  // Track changes for unsaved indicator
  useEffect(() => {
    if (importedCollections.length > 0 || importedRequests.length > 0) {
      setHasUnsavedChanges(true);
    }
  }, [importedCollections, importedRequests]);

  const extractRequestsFromCollection = (collection: PostmanCollection, parentFolder?: string): ImportedRequest[] => {
    const requests: ImportedRequest[] = [];

    const processItems = (items: PostmanItem[], folder?: string) => {
      items.forEach(item => {
        if (item.request) {
          // It's a request
          const url = typeof item.request.url === 'string' 
            ? item.request.url 
            : item.request.url?.raw || '';

          const headers = item.request.header
            ?.filter(h => !h.disabled)
            ?.reduce((acc, h) => ({ ...acc, [h.key]: h.value }), {}) || {};

          const request: ImportedRequest = {
            id: `${collection.info.name}-${Date.now()}-${Math.random()}`,
            name: item.name,
            method: item.request.method || 'GET',
            url,
            headers,
            body: item.request.body?.raw,
            collectionName: collection.info.name,
            folder: folder || parentFolder
          };

          requests.push(request);
        } else if (item.item) {
          // It's a folder
          processItems(item.item, item.name);
        }
      });
    };

    processItems(collection.item, parentFolder);
    return requests;
  };

  const clearImportedData = () => {
    setImportedCollections([]);
    setImportedRequests([]);
    setSelectedCollection(null);
    setSelectedRequest(null);
    setExecutionRequest(null);
    setImportStatus({ type: null, message: '' });
  };

  const createNewCollection = () => {
    if (!newCollectionName.trim()) {
      setImportStatus({ type: 'error', message: 'Collection name is required' });
      return;
    }

    // Check if collection name already exists
    const existingCollection = importedCollections.find(
      col => col.info.name.toLowerCase() === newCollectionName.trim().toLowerCase()
    );

    if (existingCollection) {
      setImportStatus({ type: 'error', message: 'Collection with this name already exists' });
      return;
    }

    // Create new collection
    const newCollection: PostmanCollection = {
      info: {
        name: newCollectionName.trim(),
        description: newCollectionDescription.trim() || undefined,
        schema: "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
      },
      item: []
    };

    // Add to collections
    setImportedCollections(prev => [...prev, newCollection]);
    setSelectedCollection(newCollection);
    
    // Reset form and close modal
    setNewCollectionName('');
    setNewCollectionDescription('');
    setShowCreateModal(false);
  };

  const cancelCreateCollection = () => {
    setNewCollectionName('');
    setNewCollectionDescription('');
    setShowCreateModal(false);
  };

  // Helper functions for expandable collections
  const toggleCollection = (collectionName: string) => {
    const newExpanded = new Set(expandedCollections);
    if (newExpanded.has(collectionName)) {
      newExpanded.delete(collectionName);
    } else {
      newExpanded.add(collectionName);
    }
    setExpandedCollections(newExpanded);
  };

  const getRequestsForCollection = (collectionName: string) => {
    return importedRequests.filter(request => request.collectionName === collectionName);
  };

  // Helper functions for request execution
  const loadRequestForExecution = (request: ImportedRequest) => {
    const executionReq: ExecutionRequest = {
      id: request.id,
      name: request.name,
      method: request.method,
      url: request.url,
      headers: { ...request.headers },
      body: request.body || '',
      loading: false,
      params: request.params ? { ...request.params } : {},
      auth: request.auth ? { ...request.auth } : { type: 'none' },
      bodyType: request.bodyType || 'none',
      formData: request.formData ? [...request.formData] : [],
      urlEncodedData: request.urlEncodedData ? { ...request.urlEncodedData } : {},
      fetchOptions: request.fetchOptions ? { ...request.fetchOptions } : {
        mode: 'cors',
        credentials: 'include',
        cache: 'default',
        redirect: 'follow'
      },
      cookies: request.cookies ? { ...request.cookies } : {}
    };
    setExecutionRequest(executionReq);
  };

  // Helper function to update auth safely
  const updateAuth = (updates: Partial<ExecutionRequest['auth']>) => {
    const currentAuth = executionRequest?.auth || { type: 'none' };
    updateExecutionRequest({ 
      auth: { 
        ...currentAuth,
        ...updates,
        type: updates?.type || currentAuth.type
      } 
    });
  };

  const updateExecutionRequest = (updates: Partial<ExecutionRequest>) => {
    if (executionRequest) {
      const updatedRequest = { ...executionRequest, ...updates };
      setExecutionRequest(updatedRequest);
      
      // Auto-sync changes back to the imported request
      if (selectedRequest) {
        const updatedRequests = importedRequests.map(request => 
          request.id === executionRequest.id 
            ? {
                ...request,
                name: updatedRequest.name,
                method: updatedRequest.method,
                url: updatedRequest.url,
                headers: updatedRequest.headers,
                body: updatedRequest.body || request.body,
                params: updatedRequest.params,
                auth: updatedRequest.auth,
                bodyType: updatedRequest.bodyType,
                formData: updatedRequest.formData,
                urlEncodedData: updatedRequest.urlEncodedData,
                fetchOptions: updatedRequest.fetchOptions,
                cookies: updatedRequest.cookies
              }
            : request
        );
        setImportedRequests(updatedRequests);
        setSelectedRequest({
          ...selectedRequest,
          name: updatedRequest.name,
          method: updatedRequest.method,
          url: updatedRequest.url,
          headers: updatedRequest.headers,
          body: updatedRequest.body || selectedRequest.body,
          params: updatedRequest.params,
          auth: updatedRequest.auth,
          bodyType: updatedRequest.bodyType,
          formData: updatedRequest.formData,
          urlEncodedData: updatedRequest.urlEncodedData,
          fetchOptions: updatedRequest.fetchOptions,
          cookies: updatedRequest.cookies
        });
        setHasUnsavedChanges(true);
      }
    }
  };

  // Toggle function for collections panel
  const toggleCollectionsPanel = () => {
    setCollectionsCollapsed(!collectionsCollapsed);
  };

  // Toggle function for response headers
  const toggleResponseHeaders = () => {
    setResponseHeadersCollapsed(!responseHeadersCollapsed);
  };

  const executeRequest = async () => {
    if (!executionRequest) return;

    const requestId = `req_${Date.now()}_${Math.random().toString(36).substring(7)}`;
    console.log(`[${requestId}] Starting API request for:`, executionRequest.url);
    
    updateExecutionRequest({ loading: true });
    setExecutionStatus({ type: null, message: '', showScrollHint: false });
    const startTime = Date.now();
    
    try {
      const headers: Record<string, string> = {};
      
      // Parse headers
      Object.entries(executionRequest.headers).forEach(([key, value]) => {
        if (key.trim() && value.trim()) {
          headers[key.trim()] = value.trim();
        }
      });

      // Handle authorization
      if (executionRequest.auth?.type === 'bearer' && executionRequest.auth.token) {
        headers['Authorization'] = `Bearer ${executionRequest.auth.token}`;
      } else if (executionRequest.auth?.type === 'basic' && executionRequest.auth.username && executionRequest.auth.password) {
        const credentials = btoa(`${executionRequest.auth.username}:${executionRequest.auth.password}`);
        headers['Authorization'] = `Basic ${credentials}`;
      } else if (executionRequest.auth?.type === 'api-key' && executionRequest.auth.key && executionRequest.auth.value) {
        if (executionRequest.auth.addTo === 'header') {
          headers[executionRequest.auth.key] = executionRequest.auth.value;
        }
      }

      // Handle cookies
      if (executionRequest.cookies && Object.keys(executionRequest.cookies).length > 0) {
        const cookieString = Object.entries(executionRequest.cookies)
          .filter(([key, value]) => key.trim() && value.trim())
          .map(([key, value]) => `${key}=${value}`)
          .join('; ');
        if (cookieString) {
          headers['Cookie'] = cookieString;
        }
      }

      // Use fetch options from configuration
      const requestOptions: RequestInit = {
        method: executionRequest.method,
        headers,
        mode: executionRequest.fetchOptions?.mode || 'cors',
        cache: executionRequest.fetchOptions?.cache || 'no-cache',
        credentials: executionRequest.fetchOptions?.credentials || 'include',
        redirect: executionRequest.fetchOptions?.redirect || 'follow'
      };

      // Handle different body types
      if (executionRequest.method !== 'GET') {
        if (executionRequest.bodyType === 'raw' && executionRequest.body.trim()) {
          requestOptions.body = executionRequest.body;
        } else if (executionRequest.bodyType === 'form-data' && executionRequest.formData?.length) {
          const formData = new FormData();
          executionRequest.formData.forEach(field => {
            if (field.key.trim() && field.value.trim()) {
              formData.append(field.key, field.value);
            }
          });
          requestOptions.body = formData;
        } else if (executionRequest.bodyType === 'x-www-form-urlencoded' && executionRequest.urlEncodedData) {
          const params = new URLSearchParams();
          Object.entries(executionRequest.urlEncodedData).forEach(([key, value]) => {
            if (key.trim() && value.trim()) {
              params.append(key, value);
            }
          });
          requestOptions.body = params.toString();
          headers['Content-Type'] = 'application/x-www-form-urlencoded';
        }
      }

      // Build final URL with query parameters
      let finalUrl: string;
      try {
        const url = new URL(executionRequest.url);
        
        // Add query parameters
        if (executionRequest.params) {
          Object.entries(executionRequest.params).forEach(([key, value]) => {
            if (key.trim() && value.trim()) {
              url.searchParams.set(key, value);
            }
          });
        }

        // Add API key to query if configured
        if (executionRequest.auth?.type === 'api-key' && 
            executionRequest.auth.addTo === 'query' && 
            executionRequest.auth.key && 
            executionRequest.auth.value) {
          url.searchParams.set(executionRequest.auth.key, executionRequest.auth.value);
        }

        // Add cache-busting parameters
        url.searchParams.set('_t', Date.now().toString());
        url.searchParams.set('_r', Math.random().toString(36).substring(7));
        finalUrl = url.toString();
      } catch (error) {
        // Fallback for invalid URLs
        const separator = executionRequest.url.includes('?') ? '&' : '?';
        const queryParams = [];
        
        // Add configured parameters
        if (executionRequest.params) {
          Object.entries(executionRequest.params).forEach(([key, value]) => {
            if (key.trim() && value.trim()) {
              queryParams.push(`${encodeURIComponent(key)}=${encodeURIComponent(value)}`);
            }
          });
        }

        // Add API key if configured for query
        if (executionRequest.auth?.type === 'api-key' && 
            executionRequest.auth.addTo === 'query' && 
            executionRequest.auth.key && 
            executionRequest.auth.value) {
          queryParams.push(`${encodeURIComponent(executionRequest.auth.key)}=${encodeURIComponent(executionRequest.auth.value)}`);
        }

        // Add cache-busting
        queryParams.push(`_t=${Date.now()}`);
        queryParams.push(`_r=${Math.random().toString(36).substring(7)}`);
        
        finalUrl = `${executionRequest.url}${separator}${queryParams.join('&')}`;
      }

      console.log(`[${requestId}] Making API request to:`, finalUrl);
      console.log(`[${requestId}] Request options:`, requestOptions);

      // Create a timeout promise
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('Request timeout after 30 seconds')), 30000);
      });

      // Race between fetch and timeout
      const response = await Promise.race([
        fetch(finalUrl, requestOptions),
        timeoutPromise
      ]) as Response;
      
      const duration = Date.now() - startTime;
      
      // Get response headers
      const responseHeaders: Record<string, string> = {};
      response.headers.forEach((value, key) => {
        responseHeaders[key] = value;
      });

      // Get response body
      const contentType = response.headers.get('content-type') || '';
      let responseBody: string;
      
      try {
        if (contentType.includes('application/json')) {
          try {
            const jsonData = await response.clone().json();
            responseBody = JSON.stringify(jsonData, null, 2);
          } catch (jsonError) {
            console.warn(`[${requestId}] Failed to parse JSON response, falling back to text:`, jsonError);
            responseBody = await response.clone().text();
          }
        } else {
          responseBody = await response.text();
        }
      } catch (bodyError) {
        console.warn(`[${requestId}] Failed to read response body:`, bodyError);
        responseBody = `Error reading response body: ${bodyError instanceof Error ? bodyError.message : 'Unknown error'}`;
      }

      updateExecutionRequest({
        loading: false,
        response: {
          status: response.status,
          statusText: response.statusText || `HTTP ${response.status}`,
          headers: responseHeaders,
          body: responseBody,
          duration
        }
      });

      // Set execution status message
      if (response.ok) {
        setExecutionStatus({
          type: 'success',
          message: `✅ Request successful (${response.status}) - ${duration}ms`,
          showScrollHint: true
        });
      } else {
        setExecutionStatus({
          type: 'error',
          message: `⚠️ Request failed (${response.status}) - ${duration}ms`,
          showScrollHint: true
        });
      }

      console.log(`[${requestId}] API request completed successfully`);

    } catch (error) {
      const duration = Date.now() - startTime;
      console.error(`[${requestId}] API request failed:`, error);
      
      let errorMessage = 'Unknown error';
      let errorDetails = '';
      
      if (error instanceof TypeError && error.message.includes('Failed to fetch')) {
        errorMessage = 'Network Error - CORS or connectivity issue';
        errorDetails = 'This could be due to:\n' +
                      '• CORS policy blocking the request\n' +
                      '• Network connectivity issues\n' +
                      '• Invalid URL or server not responding\n' +
                      '• Firewall or security software blocking the request';
      } else if (error instanceof TypeError) {
        errorMessage = `Type Error: ${error.message}`;
      } else if (error instanceof Error && error.message.includes('timeout')) {
        errorMessage = 'Request Timeout';
        errorDetails = 'The request took longer than 30 seconds to complete';
      } else {
        errorMessage = error instanceof Error ? error.message : String(error);
      }

      updateExecutionRequest({
        loading: false,
        response: {
          status: 0,
          statusText: errorMessage,
          headers: {},
          body: errorDetails ? `${errorMessage}\n\n${errorDetails}` : errorMessage,
          duration
        }
      });

      // Set error execution status
      setExecutionStatus({
        type: 'error',
        message: `❌ Request failed: ${errorMessage}`,
        showScrollHint: true
      });
    }
  };

  const getStatusColor = (status: number) => {
    if (status === 0) return 'text-red-400';
    if (status >= 200 && status < 300) return 'text-green-400';
    if (status >= 300 && status < 400) return 'text-yellow-400';
    if (status >= 400 && status < 500) return 'text-orange-400';
    if (status >= 500) return 'text-red-400';
    return 'text-gray-400';
  };

  const formatJsonData = (data: any): string => {
    if (typeof data === 'string') {
      try {
        return JSON.stringify(JSON.parse(data), null, 2);
      } catch {
        return data;
      }
    }
    return JSON.stringify(data, null, 2);
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch (error) {
      console.error('Failed to copy to clipboard:', error);
    }
  };

  return (
    <div className="h-full flex flex-col bg-gray-900" style={{ wordWrap: 'break-word', overflowWrap: 'anywhere' }}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-700 bg-gray-800">
        <div className="flex items-center space-x-3">
          <button
            onClick={toggleCollectionsPanel}
            className="p-2 bg-gray-600 hover:bg-gray-700 text-white rounded transition-colors"
            title={collectionsCollapsed ? "Show collections panel" : "Hide collections panel"}
          >
            {collectionsCollapsed ? (
              <ChevronRight size={16} />
            ) : (
              <ChevronDown size={16} />
            )}
          </button>
          <div>
            <h2 className="text-xl font-semibold text-white">API Collections</h2>
            <p className="text-sm text-gray-400 mt-1">
              Import and manage your API collections for testing
            </p>
          </div>
        </div>
        <div className="flex space-x-2">
          <button
            onClick={saveToLocalStorage}
            disabled={!hasUnsavedChanges}
            className={`p-2 rounded transition-colors ${
              hasUnsavedChanges 
                ? 'bg-blue-600 hover:bg-blue-700 text-white' 
                : 'bg-gray-600 text-gray-400 cursor-not-allowed'
            }`}
            title={hasUnsavedChanges ? 'Save collections to local storage' : 'No unsaved changes'}
          >
            <Save size={16} />
          </button>
          <button
            onClick={loadFromLocalStorage}
            className="p-2 bg-gray-600 hover:bg-gray-700 text-white rounded transition-colors"
            title="Reload saved collections"
          >
            <RefreshCw size={16} />
          </button>
          <button
            onClick={importFromFile}
            disabled={isImporting}
            className="p-2 bg-purple-600 hover:bg-purple-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded transition-colors"
            title="Import collection file"
          >
            <Upload size={16} />
          </button>
          {importedRequests.length > 0 && (
            <>
              <button
                onClick={exportCollections}
                className="p-2 bg-green-600 hover:bg-green-700 text-white rounded transition-colors"
                title="Export collections"
              >
                <Download size={16} />
              </button>
              <button
                onClick={clearImportedData}
                className="p-2 bg-red-600 hover:bg-red-700 text-white rounded transition-colors"
                title="Clear all collections"
              >
                <Trash2 size={16} />
              </button>
            </>
          )}
        </div>
      </div>

      {/* Import Status */}
      {importStatus.type && (
        <div className={`flex items-center justify-between p-3 text-sm border-b border-gray-700 ${
          importStatus.type === 'success' 
            ? 'bg-green-900/50 border-green-700' 
            : 'bg-red-900/50 border-red-700'
        }`}>
          <div className="flex items-center space-x-2">
            {importStatus.type === 'success' ? (
              <CheckCircle size={16} className="text-green-400" />
            ) : (
              <AlertCircle size={16} className="text-red-400" />
            )}
            <span className={importStatus.type === 'success' ? 'text-green-300' : 'text-red-300'}>
              {importStatus.message}
            </span>
          </div>
          <button
            onClick={() => setImportStatus({ type: null, message: '' })}
            className="p-1 hover:bg-gray-700 rounded transition-colors"
            title="Close message"
          >
            <X size={14} className={importStatus.type === 'success' ? 'text-green-400' : 'text-red-400'} />
          </button>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex overflow-hidden" style={{ height: 'calc(100vh - 120px)' }}>
        {/* Left Panel - Collections Only */}
        {!collectionsCollapsed && (
          <div className="w-1/3 border-r border-gray-700 overflow-y-auto collections-scroll" style={{ backgroundColor: '#1a1a1a' }}>
          {/* Collections List */}
          <div className="p-4">
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-gray-700">
              <h3 className="text-sm font-medium text-gray-300 uppercase tracking-wide">
                Collections
              </h3>
              <button
                onClick={() => setShowCreateModal(true)}
                className="p-1.5 hover:bg-gray-700 text-gray-400 hover:text-white rounded transition-colors"
                title="Create new collection"
              >
                <Plus size={14} />
              </button>
            </div>
            
            {importedCollections.length > 0 ? (
              <div className="space-y-1">
                {importedCollections.map((collection, index) => {
                  const isExpanded = expandedCollections.has(collection.info.name);
                  const requests = getRequestsForCollection(collection.info.name);
                  
                  return (
                    <div key={index} className="text-sm">
                      {/* Collection Header */}
                      <div 
                        className="flex items-center group hover:bg-gray-800/50 rounded px-1 py-1 cursor-pointer"
                        onClick={() => {
                          setSelectedCollection(collection);
                          toggleCollection(collection.info.name);
                        }}
                      >
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleCollection(collection.info.name);
                          }}
                          className="flex items-center justify-center w-5 h-5 hover:bg-gray-600 rounded mr-1"
                        >
                          {isExpanded ? (
                            <ChevronDown size={12} className="text-gray-400" />
                          ) : (
                            <ChevronRight size={12} className="text-gray-400" />
                          )}
                        </button>
                        <FolderOpen size={14} className="text-orange-400 mr-2 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <div className="text-gray-200 font-medium truncate">{collection.info.name}</div>
                          {requests.length > 0 && (
                            <div className="text-xs text-gray-500">{requests.length} request{requests.length !== 1 ? 's' : ''}</div>
                          )}
                        </div>
                      </div>

                      {/* Expanded Requests */}
                      {isExpanded && (
                        <div className="ml-6 mt-1">
                          {/* Add New Request Button */}
                          <div className="mb-1">
                            <button
                              onClick={() => {
                                const newRequest: ImportedRequest = {
                                  id: `req_${Date.now()}`,
                                  name: 'New Request',
                                  method: 'GET',
                                  url: '',
                                  headers: {},
                                  collectionName: collection.info.name,
                                  params: {},
                                  auth: { type: 'none' },
                                  bodyType: 'none',
                                  formData: [],
                                  urlEncodedData: {},
                                  fetchOptions: {
                                    mode: 'cors',
                                    credentials: 'include',
                                    cache: 'default',
                                    redirect: 'follow'
                                  },
                                  cookies: {}
                                };
                                setImportedRequests(prev => [...prev, newRequest]);
                                setSelectedRequest(newRequest);
                                loadRequestForExecution(newRequest);
                              }}
                              className="flex items-center group hover:bg-gray-800/50 rounded px-1 py-1 w-full text-left cursor-pointer text-gray-400 hover:text-gray-200"
                              title="Add new request to this collection"
                            >
                              <div className="w-5 h-5 flex items-center justify-center mr-1">
                                <Plus size={10} className="text-gray-500" />
                              </div>
                              <span className="text-xs text-gray-500 hover:text-gray-300">Add request</span>
                            </button>
                          </div>

                          {/* Requests List */}
                          {requests.length > 0 && (
                            <div className="space-y-0.5">
                              {requests.map((request) => (
                                <div
                                  key={request.id}
                                  className="flex items-center group hover:bg-gray-800/50 rounded px-1 py-1"
                                >
                                  <div className="w-5 h-5 flex items-center justify-center mr-1">
                                    <div className={`w-2 h-2 rounded-sm ${
                                      request.method === 'GET' ? 'bg-green-500' :
                                      request.method === 'POST' ? 'bg-orange-500' :
                                      request.method === 'PUT' ? 'bg-blue-500' :
                                      request.method === 'DELETE' ? 'bg-red-500' :
                                      'bg-gray-500'
                                    }`}></div>
                                  </div>
                                  <button
                                    className={`flex items-center space-x-2 flex-1 text-left cursor-pointer ${
                                      selectedRequest?.id === request.id
                                        ? 'text-blue-400'
                                        : 'text-gray-300 hover:text-white'
                                    }`}
                                    onClick={() => {
                                      setSelectedRequest(request);
                                      loadRequestForExecution(request);
                                    }}
                                  >
                                    <span className={`text-xs font-medium uppercase min-w-[2.5rem] ${
                                      request.method === 'GET' ? 'text-green-400' :
                                      request.method === 'POST' ? 'text-orange-400' :
                                      request.method === 'PUT' ? 'text-blue-400' :
                                      request.method === 'DELETE' ? 'text-red-400' :
                                      'text-gray-400'
                                    }`}>
                                      {request.method}
                                    </span>
                                    <span className="text-sm truncate flex-1">{request.name}</span>
                                  </button>
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      const remainingRequests = importedRequests.filter(r => r.id !== request.id);
                                      setImportedRequests(remainingRequests);
                                      if (selectedRequest?.id === request.id) {
                                        setSelectedRequest(null);
                                      }
                                    }}
                                    className="p-1 hover:bg-red-600 rounded transition-colors opacity-0 group-hover:opacity-100"
                                    title="Delete request"
                                  >
                                    <X size={12} />
                                  </button>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-12">
                <FileText size={32} className="mx-auto text-gray-500 mb-3" />
                <p className="text-gray-400 text-sm">No collections imported yet</p>
                <p className="text-gray-500 text-xs mt-1">Import an API collection to get started</p>
              </div>
            )}
          </div>
        </div>
        )}

        {/* Right Panel - Request Execution (API Tester Style) */}
        <div className={`flex-1 flex flex-col bg-gray-900 ${collectionsCollapsed ? 'w-full' : ''}`}>
          {/* Collections hidden indicator */}
          {collectionsCollapsed && (
            <div className="p-2 bg-gray-800 border-b border-gray-700 flex items-center justify-center">
              <div className="flex items-center space-x-2 text-gray-400 text-sm">
                <FolderOpen size={14} />
                <span>Collections panel hidden</span>
                <button
                  onClick={toggleCollectionsPanel}
                  className="text-blue-400 hover:text-blue-300 underline text-xs"
                >
                  Show
                </button>
              </div>
            </div>
          )}
          {executionRequest ? (
            <div className="flex-1 p-4 overflow-y-auto">
              <div className="space-y-4">
                {/* Execution Status Messages */}
                {executionStatus.type && (
                  <div className={`p-2 rounded border text-xs ${
                    executionStatus.type === 'success' 
                      ? 'bg-green-900/50 border-green-700 text-green-200' 
                      : 'bg-red-900/50 border-red-700 text-red-200'
                  }`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        {executionStatus.type === 'success' ? (
                          <span className="text-green-400">✅</span>
                        ) : (
                          <span className="text-red-400">❌</span>
                        )}
                        <span className="font-medium">{executionStatus.message}</span>
                        {executionStatus.showScrollHint && (
                          <span className="opacity-80">👇 Scroll down to view the detailed response</span>
                        )}
                      </div>
                      <button
                        onClick={() => setExecutionStatus({ type: null, message: '', showScrollHint: false })}
                        className="p-1 hover:bg-gray-700 rounded transition-colors ml-2"
                        title="Close message"
                      >
                        <X size={12} className={executionStatus.type === 'success' ? 'text-green-400' : 'text-red-400'} />
                      </button>
                    </div>
                  </div>
                )}

                {/* Request Name */}
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-300 mb-1">
                    Request Name
                  </label>
                  <input
                    type="text"
                    value={executionRequest.name}
                    onChange={(e) => updateExecutionRequest({ name: e.target.value })}
                    placeholder="Enter request name..."
                    className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                  />
                </div>

                {/* URL and Method with Send Button */}
                <div className="flex gap-3 items-end">
                  <div className="w-32">
                    <label className="block text-sm font-medium text-gray-300 mb-1">
                      Method
                    </label>
                    <select
                      value={executionRequest.method}
                      onChange={(e) => updateExecutionRequest({ method: e.target.value })}
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:border-blue-500"
                    >
                      <option value="GET">GET</option>
                      <option value="POST">POST</option>
                      <option value="PUT">PUT</option>
                      <option value="PATCH">PATCH</option>
                      <option value="DELETE">DELETE</option>
                    </select>
                  </div>
                  <div className="flex-1">
                    <label className="block text-sm font-medium text-gray-300 mb-1">
                      URL
                    </label>
                    <input
                      type="text"
                      value={executionRequest.url}
                      onChange={(e) => updateExecutionRequest({ url: e.target.value })}
                      placeholder="Enter API endpoint URL..."
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                    />
                  </div>
                  <button
                    onClick={executeRequest}
                    disabled={executionRequest.loading || !executionRequest.url}
                    className="px-4 py-2 bg-green-600 hover:bg-green-700 disabled:opacity-50 text-white rounded transition-colors flex items-center space-x-2 h-10"
                    title={executionRequest.loading ? "Sending request..." : "Send API request"}
                  >
                    {executionRequest.loading ? (
                      <RefreshCw size={16} className="animate-spin" />
                    ) : (
                      <Send size={16} />
                    )}
                    <span>{executionRequest.loading ? "Sending..." : "Send"}</span>
                  </button>
                </div>

                {/* Request Configuration Tabs */}
                <div className="bg-gray-800 rounded-lg">
                  {/* Tab Navigation */}
                  <div className="flex border-b border-gray-600 rounded-t-lg bg-gray-700">
                    {[
                      { id: 'params', label: 'Params' },
                      { id: 'auth', label: 'Authorization' },
                      { id: 'headers', label: 'Headers' },
                      { id: 'body', label: 'Body' },
                      { id: 'fetch', label: 'Fetch Options' },
                      { id: 'cookies', label: 'Cookies' }
                    ].map((tab) => (
                      <button
                        key={tab.id}
                        onClick={() => setActiveRequestTab(tab.id as any)}
                        className={`px-4 py-2 text-sm font-medium transition-colors ${
                          activeRequestTab === tab.id
                            ? 'text-blue-400 border-b-2 border-blue-400 bg-gray-800'
                            : 'text-gray-300 hover:text-white hover:bg-gray-600'
                        }`}
                      >
                        {tab.label}
                      </button>
                    ))}
                  </div>

                  {/* Tab Content */}
                  <div className="p-4">
                    {/* Params Tab */}
                    {activeRequestTab === 'params' && (
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <h4 className="text-sm font-medium text-gray-300">Query Parameters</h4>
                          <button
                            onClick={() => {
                              const newParams = { ...executionRequest.params!, '': '' };
                              updateExecutionRequest({ params: newParams });
                            }}
                            className="p-1 bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors"
                            title="Add parameter"
                          >
                            <Plus size={14} />
                          </button>
                        </div>
                        {Object.entries(executionRequest.params || {}).map(([key, value], index) => (
                          <div key={index} className="grid grid-cols-2 gap-2">
                            <input
                              type="text"
                              value={key}
                              onChange={(e) => {
                                const newParams = { ...executionRequest.params };
                                delete newParams[key];
                                newParams[e.target.value] = value;
                                updateExecutionRequest({ params: newParams });
                              }}
                              placeholder="Parameter name"
                              className="px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                            />
                            <div className="flex space-x-2">
                              <input
                                type="text"
                                value={value}
                                onChange={(e) => {
                                  const newParams = { ...executionRequest.params };
                                  newParams[key] = e.target.value;
                                  updateExecutionRequest({ params: newParams });
                                }}
                                placeholder="Parameter value"
                                className="flex-1 px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                              />
                              <button
                                onClick={() => {
                                  const newParams = { ...executionRequest.params };
                                  delete newParams[key];
                                  updateExecutionRequest({ params: newParams });
                                }}
                                className="p-2 text-red-400 hover:text-red-300 transition-colors"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          </div>
                        ))}
                        {Object.keys(executionRequest.params || {}).length === 0 && (
                          <p className="text-gray-500 text-sm text-center py-4">No query parameters added</p>
                        )}
                      </div>
                    )}

                    {/* Authorization Tab */}
                    {activeRequestTab === 'auth' && (
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-300 mb-2">Auth Type</label>
                          <select
                            value={executionRequest.auth?.type || 'none'}
                            onChange={(e) => updateAuth({ type: e.target.value as any })}
                            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:border-blue-500"
                          >
                            <option value="none">No Auth</option>
                            <option value="bearer">Bearer Token</option>
                            <option value="basic">Basic Auth</option>
                            <option value="api-key">API Key</option>
                          </select>
                        </div>

                        {executionRequest.auth?.type === 'bearer' && (
                          <div>
                            <label className="block text-sm font-medium text-gray-300 mb-1">Bearer Token</label>
                            <input
                              type="text"
                              value={executionRequest.auth.token || ''}
                              onChange={(e) => updateAuth({ token: e.target.value })}
                              placeholder="Enter bearer token..."
                              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                            />
                          </div>
                        )}

                        {executionRequest.auth?.type === 'basic' && (
                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="block text-sm font-medium text-gray-300 mb-1">Username</label>
                              <input
                                type="text"
                                value={executionRequest.auth.username || ''}
                                onChange={(e) => updateAuth({ username: e.target.value })}
                                placeholder="Username"
                                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-300 mb-1">Password</label>
                              <input
                                type="password"
                                value={executionRequest.auth.password || ''}
                                onChange={(e) => updateAuth({ password: e.target.value })}
                                placeholder="Password"
                                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                              />
                            </div>
                          </div>
                        )}

                        {executionRequest.auth?.type === 'api-key' && (
                          <div className="space-y-3">
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className="block text-sm font-medium text-gray-300 mb-1">Key</label>
                                <input
                                  type="text"
                                  value={executionRequest.auth.key || ''}
                                  onChange={(e) => updateAuth({ key: e.target.value })}
                                  placeholder="API key name"
                                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                                />
                              </div>
                              <div>
                                <label className="block text-sm font-medium text-gray-300 mb-1">Value</label>
                                <input
                                  type="text"
                                  value={executionRequest.auth.value || ''}
                                  onChange={(e) => updateAuth({ value: e.target.value })}
                                  placeholder="API key value"
                                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                                />
                              </div>
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-300 mb-1">Add to</label>
                              <select
                                value={executionRequest.auth.addTo || 'header'}
                                onChange={(e) => updateAuth({ addTo: e.target.value as any })}
                                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:border-blue-500"
                              >
                                <option value="header">Header</option>
                                <option value="query">Query Params</option>
                              </select>
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Headers Tab */}
                    {activeRequestTab === 'headers' && (
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <h4 className="text-sm font-medium text-gray-300">Request Headers</h4>
                          <button
                            onClick={() => {
                              const newHeaders = { ...executionRequest.headers, '': '' };
                              updateExecutionRequest({ headers: newHeaders });
                            }}
                            className="p-1 bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors"
                            title="Add header"
                          >
                            <Plus size={14} />
                          </button>
                        </div>
                        {Object.entries(executionRequest.headers).map(([key, value], index) => (
                          <div key={index} className="grid grid-cols-2 gap-2">
                            <input
                              type="text"
                              value={key}
                              onChange={(e) => {
                                const newHeaders = { ...executionRequest.headers };
                                delete newHeaders[key];
                                newHeaders[e.target.value] = value;
                                updateExecutionRequest({ headers: newHeaders });
                              }}
                              placeholder="Header name"
                              className="px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                            />
                            <div className="flex space-x-2">
                              <input
                                type="text"
                                value={value}
                                onChange={(e) => {
                                  const newHeaders = { ...executionRequest.headers };
                                  newHeaders[key] = e.target.value;
                                  updateExecutionRequest({ headers: newHeaders });
                                }}
                                placeholder="Header value"
                                className="flex-1 px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                              />
                              <button
                                onClick={() => {
                                  const newHeaders = { ...executionRequest.headers };
                                  delete newHeaders[key];
                                  updateExecutionRequest({ headers: newHeaders });
                                }}
                                className="p-2 text-red-400 hover:text-red-300 transition-colors"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Body Tab */}
                    {activeRequestTab === 'body' && (
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-300 mb-2">Body Type</label>
                          <select
                            value={executionRequest.bodyType || 'none'}
                            onChange={(e) => updateExecutionRequest({ bodyType: e.target.value as any })}
                            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:border-blue-500"
                          >
                            <option value="none">None</option>
                            <option value="raw">Raw</option>
                            <option value="form-data">Form-data</option>
                            <option value="x-www-form-urlencoded">x-www-form-urlencoded</option>
                          </select>
                        </div>

                        {executionRequest.bodyType === 'raw' && (
                          <div>
                            <label className="block text-sm font-medium text-gray-300 mb-1">Raw Body</label>
                            <textarea
                              value={executionRequest.body}
                              onChange={(e) => updateExecutionRequest({ body: e.target.value })}
                              placeholder="Enter raw body content (JSON, XML, text, etc.)"
                              rows={6}
                              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500 font-mono text-sm"
                            />
                          </div>
                        )}

                        {executionRequest.bodyType === 'form-data' && (
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <h4 className="text-sm font-medium text-gray-300">Form Data</h4>
                              <button
                                onClick={() => {
                                  const newFormData = [...(executionRequest.formData || []), { key: '', value: '', type: 'text' as const }];
                                  updateExecutionRequest({ formData: newFormData });
                                }}
                                className="p-1 bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors"
                                title="Add form field"
                              >
                                <Plus size={14} />
                              </button>
                            </div>
                            {(executionRequest.formData || []).map((field, index) => (
                              <div key={index} className="grid grid-cols-12 gap-2">
                                <input
                                  type="text"
                                  value={field.key}
                                  onChange={(e) => {
                                    const newFormData = [...(executionRequest.formData || [])];
                                    newFormData[index] = { ...field, key: e.target.value };
                                    updateExecutionRequest({ formData: newFormData });
                                  }}
                                  placeholder="Key"
                                  className="col-span-4 px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                                />
                                <input
                                  type="text"
                                  value={field.value}
                                  onChange={(e) => {
                                    const newFormData = [...(executionRequest.formData || [])];
                                    newFormData[index] = { ...field, value: e.target.value };
                                    updateExecutionRequest({ formData: newFormData });
                                  }}
                                  placeholder="Value"
                                  className="col-span-5 px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                                />
                                <select
                                  value={field.type}
                                  onChange={(e) => {
                                    const newFormData = [...(executionRequest.formData || [])];
                                    newFormData[index] = { ...field, type: e.target.value as any };
                                    updateExecutionRequest({ formData: newFormData });
                                  }}
                                  className="col-span-2 px-2 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:border-blue-500"
                                >
                                  <option value="text">Text</option>
                                  <option value="file">File</option>
                                </select>
                                <button
                                  onClick={() => {
                                    const newFormData = executionRequest.formData?.filter((_, i) => i !== index) || [];
                                    updateExecutionRequest({ formData: newFormData });
                                  }}
                                  className="col-span-1 p-2 text-red-400 hover:text-red-300 transition-colors"
                                >
                                  <Trash2 size={14} />
                                </button>
                              </div>
                            ))}
                          </div>
                        )}

                        {executionRequest.bodyType === 'x-www-form-urlencoded' && (
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <h4 className="text-sm font-medium text-gray-300">URL Encoded Data</h4>
                              <button
                                onClick={() => {
                                  const newData = { ...executionRequest.urlEncodedData, '': '' };
                                  updateExecutionRequest({ urlEncodedData: newData });
                                }}
                                className="p-1 bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors"
                                title="Add field"
                              >
                                <Plus size={14} />
                              </button>
                            </div>
                            {Object.entries(executionRequest.urlEncodedData || {}).map(([key, value], index) => (
                              <div key={index} className="grid grid-cols-2 gap-2">
                                <input
                                  type="text"
                                  value={key}
                                  onChange={(e) => {
                                    const newData = { ...executionRequest.urlEncodedData };
                                    delete newData[key];
                                    newData[e.target.value] = value;
                                    updateExecutionRequest({ urlEncodedData: newData });
                                  }}
                                  placeholder="Key"
                                  className="px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                                />
                                <div className="flex space-x-2">
                                  <input
                                    type="text"
                                    value={value}
                                    onChange={(e) => {
                                      const newData = { ...executionRequest.urlEncodedData };
                                      newData[key] = e.target.value;
                                      updateExecutionRequest({ urlEncodedData: newData });
                                    }}
                                    placeholder="Value"
                                    className="flex-1 px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                                  />
                                  <button
                                    onClick={() => {
                                      const newData = { ...executionRequest.urlEncodedData };
                                      delete newData[key];
                                      updateExecutionRequest({ urlEncodedData: newData });
                                    }}
                                    className="p-2 text-red-400 hover:text-red-300 transition-colors"
                                  >
                                    <Trash2 size={14} />
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Fetch Options Tab */}
                    {activeRequestTab === 'fetch' && (
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-300 mb-1">CORS Mode</label>
                          <select
                            value={executionRequest.fetchOptions?.mode || 'cors'}
                            onChange={(e) => updateExecutionRequest({ 
                              fetchOptions: { ...executionRequest.fetchOptions, mode: e.target.value as any } 
                            })}
                            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:border-blue-500"
                          >
                            <option value="cors">CORS</option>
                            <option value="no-cors">No CORS</option>
                            <option value="same-origin">Same Origin</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-300 mb-1">Credentials</label>
                          <select
                            value={executionRequest.fetchOptions?.credentials || 'include'}
                            onChange={(e) => updateExecutionRequest({ 
                              fetchOptions: { ...executionRequest.fetchOptions, credentials: e.target.value as any } 
                            })}
                            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:border-blue-500"
                          >
                            <option value="include">Include</option>
                            <option value="same-origin">Same Origin</option>
                            <option value="omit">Omit</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-300 mb-1">Cache Mode</label>
                          <select
                            value={executionRequest.fetchOptions?.cache || 'default'}
                            onChange={(e) => updateExecutionRequest({ 
                              fetchOptions: { ...executionRequest.fetchOptions, cache: e.target.value as any } 
                            })}
                            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:border-blue-500"
                          >
                            <option value="default">Default</option>
                            <option value="no-cache">No Cache</option>
                            <option value="reload">Reload</option>
                            <option value="force-cache">Force Cache</option>
                            <option value="only-if-cached">Only If Cached</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-300 mb-1">Redirect Mode</label>
                          <select
                            value={executionRequest.fetchOptions?.redirect || 'follow'}
                            onChange={(e) => updateExecutionRequest({ 
                              fetchOptions: { ...executionRequest.fetchOptions, redirect: e.target.value as any } 
                            })}
                            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:border-blue-500"
                          >
                            <option value="follow">Follow</option>
                            <option value="manual">Manual</option>
                            <option value="error">Error</option>
                          </select>
                        </div>
                      </div>
                    )}

                    {/* Cookies Tab */}
                    {activeRequestTab === 'cookies' && (
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <h4 className="text-sm font-medium text-gray-300">Cookies</h4>
                          <button
                            onClick={() => {
                              const newCookies = { ...executionRequest.cookies, '': '' };
                              updateExecutionRequest({ cookies: newCookies });
                            }}
                            className="p-1 bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors"
                            title="Add cookie"
                          >
                            <Plus size={14} />
                          </button>
                        </div>
                        {Object.entries(executionRequest.cookies || {}).map(([key, value], index) => (
                          <div key={index} className="grid grid-cols-2 gap-2">
                            <input
                              type="text"
                              value={key}
                              onChange={(e) => {
                                const newCookies = { ...executionRequest.cookies };
                                delete newCookies[key];
                                newCookies[e.target.value] = value;
                                updateExecutionRequest({ cookies: newCookies });
                              }}
                              placeholder="Cookie name"
                              className="px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                            />
                            <div className="flex space-x-2">
                              <input
                                type="text"
                                value={value}
                                onChange={(e) => {
                                  const newCookies = { ...executionRequest.cookies };
                                  newCookies[key] = e.target.value;
                                  updateExecutionRequest({ cookies: newCookies });
                                }}
                                placeholder="Cookie value"
                                className="flex-1 px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                              />
                              <button
                                onClick={() => {
                                  const newCookies = { ...executionRequest.cookies };
                                  delete newCookies[key];
                                  updateExecutionRequest({ cookies: newCookies });
                                }}
                                className="p-2 text-red-400 hover:text-red-300 transition-colors"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          </div>
                        ))}
                        {Object.keys(executionRequest.cookies || {}).length === 0 && (
                          <p className="text-gray-500 text-sm text-center py-4">No cookies added</p>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Response */}
                {executionRequest.response && (
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="block text-sm font-medium text-gray-300">
                        Response
                      </label>
                      <div className="flex items-center space-x-2">
                        <span className={`font-mono text-sm ${getStatusColor(executionRequest.response.status)}`}>
                          {executionRequest.response.status} {executionRequest.response.statusText}
                        </span>
                        <span className="text-xs text-gray-400">
                          {executionRequest.response.duration}ms
                        </span>
                      </div>
                    </div>
                    <div className="bg-gray-400 border border-gray-500 rounded shadow-lg">
                      {/* Response Headers */}
                      <div className="p-3 bg-gray-400 border-b border-gray-500">
                        <div className="flex items-center justify-between mb-1">
                          <button
                            onClick={toggleResponseHeaders}
                            className="flex items-center gap-1 font-semibold text-gray-800 bg-emerald-100 px-2 py-1 rounded text-xs hover:bg-emerald-200 transition-colors"
                          >
                            {responseHeadersCollapsed ? (
                              <ChevronRight size={12} />
                            ) : (
                              <ChevronDown size={12} />
                            )}
                            Response Headers
                          </button>
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => console.log('Response Headers:', executionRequest.response!.headers)}
                              className="p-1 text-gray-700 hover:text-green-600 transition-colors"
                              title="View headers hierarchy"
                            >
                              <Eye size={12} />
                            </button>
                            <button
                              onClick={() => copyToClipboard(Object.entries(executionRequest.response!.headers).map(([key, value]) => `${key}: ${value}`).join('\n'))}
                              className="p-1 text-gray-700 hover:text-blue-600 transition-colors"
                              title="Copy headers"
                            >
                              <Copy size={12} />
                            </button>
                          </div>
                        </div>
                        {!responseHeadersCollapsed && (
                          <pre className="text-xs text-gray-800 whitespace-pre-wrap bg-gray-200 border border-gray-300 p-2 rounded-md font-mono">
                            {Object.entries(executionRequest.response.headers).map(([key, value]) => `${key}: ${value}`).join('\n')}
                          </pre>
                        )}
                      </div>
                      
                      {/* Response Body */}
                      <div className="p-3 bg-gray-400">
                        <div className="flex items-center justify-between mb-2">
                          <div className="font-semibold text-gray-800 bg-amber-100 px-2 py-1 rounded text-xs">Response Body:</div>
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => {
                                try {
                                  const parsedData = typeof executionRequest.response!.body === 'string' 
                                    ? JSON.parse(executionRequest.response!.body) 
                                    : executionRequest.response!.body;
                                  console.log('Response Body JSON:', parsedData);
                                } catch {
                                  console.log('Response Body:', executionRequest.response!.body);
                                }
                              }}
                              className="p-1 text-gray-700 hover:text-emerald-600 transition-colors"
                              title="View JSON hierarchy"
                            >
                              <Eye size={12} />
                            </button>
                            <button
                              onClick={() => copyToClipboard(formatJsonData(executionRequest.response!.body))}
                              className="p-1 text-gray-700 hover:text-blue-600 transition-colors"
                              title="Copy response body"
                            >
                              <Copy size={12} />
                            </button>
                          </div>
                        </div>
                        <pre className="bg-gray-200 border border-gray-300 p-3 rounded-md text-gray-800 whitespace-pre-wrap break-all max-h-40 overflow-auto text-xs shadow-sm font-mono">
                          {formatJsonData(executionRequest.response.body)}
                        </pre>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center text-gray-400">
                <Send size={48} className="mx-auto mb-3 opacity-50" />
                <p className="text-lg">Select a request to execute</p>
                <p className="text-sm mt-1">Click on a request from the expanded collections to load it for execution</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Create New Collection Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-gray-800 rounded-lg p-6 w-96 border border-gray-700">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-white">Create New Collection</h3>
              <button
                onClick={cancelCreateCollection}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <X size={20} />
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Collection Name *
                </label>
                <input
                  type="text"
                  value={newCollectionName}
                  onChange={(e) => setNewCollectionName(e.target.value)}
                  placeholder="Enter collection name..."
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                  autoFocus
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Description (optional)
                </label>
                <textarea
                  value={newCollectionDescription}
                  onChange={(e) => setNewCollectionDescription(e.target.value)}
                  placeholder="Enter collection description..."
                  rows={3}
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>
            
            <div className="flex space-x-3 mt-6">
              <button
                onClick={createNewCollection}
                disabled={!newCollectionName.trim()}
                className="p-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed rounded text-white transition-colors"
                title="Create Collection"
              >
                <Plus size={16} />
              </button>
              <button
                onClick={cancelCreateCollection}
                className="p-2 bg-gray-600 hover:bg-gray-700 rounded text-white transition-colors"
                title="Cancel"
              >
                <X size={16} />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
