import { useState, useEffect } from 'react';
import { NetworkTab } from './components/NetworkTab';
import { JourneyTab } from './components/JourneyTab';
import { ApiTesterTab } from './components/ApiTesterTab';
import { ErrorContextTab } from './components/ErrorContextTab';
import { ApiCollectionsTab } from './components/ApiCollectionsTab';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Activity, AlertTriangle, Menu, X, Map, FlaskConical, Package, Upload, HardDrive } from 'lucide-react';

type Tab = 'api' | 'assets' | 'journey' | 'api-tester' | 'error-context' | 'api-collections';

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('api');
  const [currentTabId, setCurrentTabId] = useState<number | null>(null);
  const [isDevToolsPanel, setIsDevToolsPanel] = useState(false);
  const [isBurgerMenuOpen, setIsBurgerMenuOpen] = useState(false);
  const [showStorageModal, setShowStorageModal] = useState(false);
  // Tab-specific state for displayed network calls
  const [displayedNetworkCallsByTab, setDisplayedNetworkCallsByTab] = useState<Record<number, any[]>>({});
  // State for imported requests from API collections
  const [importedRequest, setImportedRequest] = useState<{
    url: string;
    method: string;
    headers: Array<{ key: string; value: string }>;
    body?: string;
    name?: string;
  } | null>(null);

  useEffect(() => {
    // Detect if running in DevTools panel
    setIsDevToolsPanel(window.location.pathname.includes('panel.html') || window.parent !== window);
    
    // Get current tab ID
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        setCurrentTabId(tabs[0].id!);
      }
    });

    // Global error handler for extension UI
    const handleError = (event: ErrorEvent) => {
      console.error('Global error in extension UI:', event.error);
      // Prevent the error from crashing the entire extension
      event.preventDefault();
    };

    const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
      console.error('Unhandled promise rejection in extension UI:', event.reason);
      // Prevent the rejection from crashing the extension
      event.preventDefault();
    };

    // Handle keyboard events for burger menu
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && isBurgerMenuOpen) {
        setIsBurgerMenuOpen(false);
      }
    };

    window.addEventListener('error', handleError);
    window.addEventListener('unhandledrejection', handleUnhandledRejection);
    document.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('error', handleError);
      window.removeEventListener('unhandledrejection', handleUnhandledRejection);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isBurgerMenuOpen]);

  // Helper to get/set calls for current tab
  const displayedNetworkCalls = currentTabId ? (displayedNetworkCallsByTab[currentTabId] || []) : [];
  const setDisplayedCalls: React.Dispatch<React.SetStateAction<any[]>> = (value) => {
    if (currentTabId == null) return;
    setDisplayedNetworkCallsByTab(prev => {
      const prevCalls = prev[currentTabId] || [];
      const nextCalls = typeof value === 'function' ? (value as (prev: any[]) => any[])(prevCalls) : value;
      return { ...prev, [currentTabId]: nextCalls };
    });
  };

  // Refresh network data for API Tester tab
  const refreshApiTesterData = async () => {
    if (!currentTabId) return;
    
    try {
      const response = await chrome.runtime.sendMessage({
        type: 'GET_NETWORK_DATA',
        tabId: currentTabId
      });
      const networkRequests = response.networkRequests || [];
      
      // Update the displayed calls for this tab
      setDisplayedNetworkCallsByTab(prev => ({
        ...prev,
        [currentTabId]: networkRequests
      }));
    } catch (error) {
      console.error('Failed to refresh API tester data:', error);
    }
  };

  // Handle imported request from API Collections tab
  const handleImportedRequest = (request: {
    url: string;
    method: string;
    headers: Array<{ key: string; value: string }>;
    body?: string;
    name?: string;
  }) => {
    setImportedRequest(request);
    setActiveTab('api-tester'); // Switch to API Tester tab
    // Clear the imported request after a short delay to allow the effect to run
    setTimeout(() => setImportedRequest(null), 100);
  };

  // Storage management functions
  const getStorageInfo = () => {
    try {
      const keys = ['dev-insights-api-collections', 'dev-insights-network-calls', 'dev-insights-user-data'];
      let totalSize = 0;
      const details: any[] = [];
      
      keys.forEach(key => {
        const data = localStorage.getItem(key) || '{}';
        const sizeInBytes = new Blob([data]).size;
        const sizeInMB = (sizeInBytes / (1024 * 1024)).toFixed(2);
        totalSize += sizeInBytes;
        
        details.push({
          key: key.replace('dev-insights-', ''),
          sizeInMB,
          data: data !== '{}' ? JSON.parse(data) : null
        });
      });
      
      const totalSizeInMB = (totalSize / (1024 * 1024)).toFixed(2);
      const maxSizeInMB = 10; // Approximate localStorage limit
      const usagePercentage = ((totalSize / (maxSizeInMB * 1024 * 1024)) * 100);
      
      return {
        totalSizeInMB,
        maxSizeInMB,
        usagePercentage: Math.min(usagePercentage, 100),
        details
      };
    } catch (error) {
      return { 
        totalSizeInMB: '0', 
        maxSizeInMB: 10, 
        usagePercentage: 0, 
        details: [] 
      };
    }
  };

  const clearStorageData = (key: string) => {
    try {
      localStorage.removeItem(`dev-insights-${key}`);
      alert(`${key} data cleared successfully`);
    } catch (error) {
      alert(`Failed to clear ${key} data`);
    }
  };

  const clearAllStorageData = () => {
    if (confirm('Are you sure you want to clear all Developer Insights data? This action cannot be undone.')) {
      try {
        const keys = ['dev-insights-api-collections', 'dev-insights-network-calls', 'dev-insights-user-data'];
        keys.forEach(key => localStorage.removeItem(key));
        alert('All Developer Insights data cleared successfully');
      } catch (error) {
        alert('Failed to clear storage data');
      }
    }
  };

  const tabs = [
    { id: 'api' as Tab, label: 'API', icon: Activity },
    { id: 'assets' as Tab, label: 'Assets', icon: Package },
    { id: 'api-tester' as Tab, label: 'API Tester', icon: FlaskConical },
    { id: 'api-collections' as Tab, label: 'API Collections', icon: Upload },
    { id: 'journey' as Tab, label: 'Journey', icon: Map },
    { id: 'error-context' as Tab, label: 'Page Insights', icon: AlertTriangle },
  ];

  return (
    <div className={`bg-gray-900 text-white flex flex-col relative ${isDevToolsPanel ? 'h-full w-full' : 'w-[780px] h-[595px]'}`}>
      
      {/* Header with Tabs */}
      <div className="bg-gray-800 border-b border-gray-700 p-2 flex items-center justify-between">
        <div className="flex-shrink-0">
          <h1 className="text-base font-semibold text-blue-400">Developer Insights</h1>
          <p className="text-xs text-gray-400 mt-0.5">Web development debugging tools</p>
        </div>
        
        {/* Tab Navigation */}
        <div className="flex items-center space-x-1 mx-4 flex-1 justify-center">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-1 px-3 py-1.5 text-xs font-medium rounded-md transition-all duration-200 ${
                  activeTab === tab.id
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-gray-300 hover:text-white hover:bg-gray-700'
                }`}
                title={tab.label}
              >
                <Icon size={14} />
                <span className="hidden sm:inline">{tab.label}</span>
              </button>
            );
          })}
        </div>
        
        {/* Burger Menu (kept as fallback) */}
        <div className="relative flex-shrink-0">
          <button
            onClick={() => setIsBurgerMenuOpen(!isBurgerMenuOpen)}
            className="p-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors focus:outline-none"
            title="Open navigation menu"
          >
            {isBurgerMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
          
          {/* Dropdown Menu */}
          {isBurgerMenuOpen && (
            <>
              {/* Backdrop */}
              <div 
                className="fixed inset-0 z-30" 
                onClick={() => setIsBurgerMenuOpen(false)}
              />
              
              {/* Menu */}
              <div className="absolute right-0 top-full mt-1 bg-gray-800 border border-gray-600 rounded-lg shadow-xl z-40 min-w-[200px] animate-in slide-in-from-top-2 duration-200">
                {tabs.map((tab, index) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => {
                        setActiveTab(tab.id);
                        setIsBurgerMenuOpen(false);
                      }}
                      className={`w-full flex items-center space-x-3 px-4 py-3 text-sm font-medium transition-all duration-200 ${
                        index === 0 ? 'rounded-t-lg' : ''
                      } ${
                        index === tabs.length - 1 ? 'rounded-b-lg' : ''
                      } ${
                        activeTab === tab.id
                          ? 'bg-blue-600 text-white shadow-md'
                          : 'text-gray-300 hover:text-white hover:bg-gray-700'
                      }`}
                    >
                      <Icon size={16} />
                      <span>{tab.label}</span>
                      {activeTab === tab.id && (
                        <div className="ml-auto w-2 h-2 bg-blue-400 rounded-full animate-pulse" />
                      )}
                    </button>
                  );
                })}
                
                {/* Storage Management Option */}
                <div className="border-t border-gray-600 mt-1 pt-1">
                  <button
                    onClick={() => {
                      setShowStorageModal(true);
                      setIsBurgerMenuOpen(false);
                    }}
                    className="w-full flex items-center space-x-3 px-4 py-3 text-sm font-medium text-gray-300 hover:text-white hover:bg-gray-700 transition-all duration-200 rounded-b-lg"
                  >
                    <HardDrive size={16} />
                    <span>Storage Management</span>
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-hidden">
        <div className="h-full overflow-y-auto">
          {activeTab === 'api' && <NetworkTab tabId={currentTabId} type="api" displayedCalls={displayedNetworkCalls} setDisplayedCalls={setDisplayedCalls} />}
          {activeTab === 'assets' && <NetworkTab tabId={currentTabId} type="assets" displayedCalls={displayedNetworkCalls} setDisplayedCalls={setDisplayedCalls} />}
          {activeTab === 'api-tester' && <ApiTesterTab displayedCalls={displayedNetworkCalls} onRefresh={refreshApiTesterData} importedRequest={importedRequest} />}
          {activeTab === 'api-collections' && <ApiCollectionsTab onSendToApiTester={handleImportedRequest} />}
          {activeTab === 'journey' && <JourneyTab />}
          {activeTab === 'error-context' && (
            <ErrorBoundary>
              <ErrorContextTab tabId={currentTabId} />
            </ErrorBoundary>
          )}
        </div>
      </div>
      
      {/* Storage Management Modal */}
      {showStorageModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-gray-800 rounded-lg p-6 w-[600px] border border-gray-700 max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-white flex items-center">
                <HardDrive size={18} className="mr-2" />
                Storage Management
              </h3>
              <button
                onClick={() => setShowStorageModal(false)}
                className="p-1 hover:bg-gray-700 rounded transition-colors"
              >
                <X size={16} className="text-gray-400" />
              </button>
            </div>

            {(() => {
              const storageInfo = getStorageInfo();
              return (
                <>
                  {/* Storage Usage Overview */}
                  <div className="bg-gray-700 p-4 rounded mb-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-gray-300">Total Storage Used</span>
                      <span className="text-sm text-white font-medium">{storageInfo.totalSizeInMB}MB / {storageInfo.maxSizeInMB}MB</span>
                    </div>
                    
                    <div className="w-full bg-gray-600 rounded-full h-3 mb-2">
                      <div 
                        className={`h-3 rounded-full transition-all ${
                          storageInfo.usagePercentage > 80 ? 'bg-red-500' :
                          storageInfo.usagePercentage > 60 ? 'bg-yellow-500' : 'bg-green-500'
                        }`}
                        style={{ width: `${Math.min(storageInfo.usagePercentage, 100)}%` }}
                      />
                    </div>
                    
                    <div className="text-center">
                      <span className="text-sm text-gray-400">
                        {storageInfo.usagePercentage.toFixed(1)}% used
                      </span>
                    </div>
                    
                    {storageInfo.usagePercentage > 80 && (
                      <p className="text-sm text-red-400 mt-2">
                        ⚠️ Storage almost full - consider clearing some data
                      </p>
                    )}
                  </div>

                  {/* Storage Details by Category */}
                  <div className="space-y-3 mb-6">
                    <h4 className="text-md font-medium text-white">Storage Details</h4>
                    {storageInfo.details.map((detail: any, index: number) => (
                      <div key={index} className="bg-gray-700 p-3 rounded flex items-center justify-between">
                        <div>
                          <div className="text-sm font-medium text-white capitalize">
                            {detail.key.replace('-', ' ')}
                          </div>
                          <div className="text-xs text-gray-400">
                            {detail.sizeInMB}MB
                          </div>
                        </div>
                        <button
                          onClick={() => clearStorageData(detail.key)}
                          disabled={!detail.data}
                          className="px-3 py-1 bg-red-600 hover:bg-red-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white text-xs rounded transition-colors"
                          title={detail.data ? `Clear ${detail.key} data` : 'No data to clear'}
                        >
                          Clear
                        </button>
                      </div>
                    ))}
                  </div>

                  {/* Clear All Button */}
                  <div className="border-t border-gray-600 pt-4">
                    <button
                      onClick={clearAllStorageData}
                      className="w-full flex items-center justify-center space-x-2 p-3 bg-red-600 hover:bg-red-700 text-white rounded transition-colors"
                      title="Clear all Developer Insights data"
                    >
                      <HardDrive size={16} />
                      <span>Clear All Data</span>
                    </button>
                  </div>
                </>
              );
            })()}
          </div>
        </div>
      )}
    </div>
  );
}

export default App;