# API Testing Troubleshooting Guide

## Enhanced API Testing Features

The API Tester has been improved with better error handling and diagnostics to help identify why some API calls might not be returning responses.

### New Features Added:

1. **30-second timeout protection** - Prevents requests from hanging indefinitely
2. **Enhanced error messages** - Detailed explanations of common issues
3. **Better CORS handling** - Includes credentials and improved headers
4. **Comprehensive logging** - Check browser console for detailed request/response info
5. **Response type detection** - Better handling of JSON vs text responses

### Common Issues and Solutions:

#### 1. CORS (Cross-Origin Resource Sharing) Errors
**Symptoms:** "Network Error - CORS or connectivity issue"
**Solutions:**
- The API server needs to include proper CORS headers
- Try adding `Access-Control-Allow-Origin: *` to your server's response headers
- Some APIs only work from their own domain context

#### 2. Authentication Issues
**Symptoms:** 401/403 errors or empty responses
**Solutions:**
- Ensure Authorization headers are correctly formatted
- Check if the API requires specific authentication tokens
- Try copying headers from working requests in the Network tab

#### 3. Request Timeout
**Symptoms:** "Request Timeout" error after 30 seconds
**Solutions:**
- Check if the API endpoint is responding
- Verify the URL is correct and accessible
- Some APIs may be slower - this is expected behavior

#### 4. Invalid JSON Response
**Symptoms:** Response shows but seems malformed
**Solutions:**
- The API might be returning HTML error pages instead of JSON
- Check the response headers in the detailed view
- Some APIs return different content types based on Accept headers

### Debugging Steps:

1. **Check Browser Console:**
   - Open Developer Tools (F12)
   - Look for detailed request/response logs starting with `[req_...]`
   - Review the full request and response details

2. **Compare with Network Tab:**
   - Check if the same request works in the Network tab
   - Copy working request headers to the API Tester

3. **Test with Simple Requests:**
   - Start with GET requests without authentication
   - Gradually add headers and body content
   - Test with public APIs first (like JSONPlaceholder)

4. **Verify API Endpoint:**
   - Ensure the URL is accessible from your browser
   - Check if the API requires specific user agents or referrers
   - Some APIs block requests from extensions

### Request Configuration Tips:

- **Content-Type**: Set to `application/json` for JSON APIs
- **Accept**: Set to `application/json` to request JSON responses
- **Authorization**: Use `Bearer <token>` format for JWT tokens
- **Cache Control**: Extension automatically adds cache-busting headers

### Testing Examples:

#### Public API Test (should work):
```
URL: https://jsonplaceholder.typicode.com/posts/1
Method: GET
Headers: {
  "Accept": "application/json"
}
```

#### Authenticated API Test:
```
URL: https://api.example.com/data
Method: GET
Headers: {
  "Authorization": "Bearer your-token-here",
  "Content-Type": "application/json",
  "Accept": "application/json"
}
```

If you're still experiencing issues, the enhanced error messages will provide more specific guidance about what might be causing the problem.
