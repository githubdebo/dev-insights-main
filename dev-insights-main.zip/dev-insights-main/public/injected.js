// Injected script to capture network requests and error context
(function() {
  'use strict';

  // Error Context Capture
  function captureErrorContext(type, error, additionalData = {}) {
    try {
      const errorData = {
        type: type,
        message: error.message || error.toString(),
        stack: error.stack,
        url: error.filename || error.url || window.location.href,
        lineNumber: error.lineno,
        columnNumber: error.colno,
        source: error.source,
        timestamp: Date.now(),
        userAgent: navigator.userAgent,
        pageUrl: window.location.href,
        environmentInfo: {
          viewport: `${window.innerWidth}x${window.innerHeight}`,
          cookiesEnabled: navigator.cookieEnabled,
          onlineStatus: navigator.onLine,
          referrer: document.referrer
        },
        ...additionalData
      };

      window.postMessage({
        type: 'ERROR_CONTEXT',
        data: errorData
      }, '*');
    } catch (e) {
      console.error('Failed to capture error context:', e);
    }
  }

  // Capture JavaScript errors
  window.addEventListener('error', (event) => {
    captureErrorContext('javascript', event.error || {
      message: event.message,
      filename: event.filename,
      lineno: event.lineno,
      colno: event.colno
    });
  });

  // Capture unhandled promise rejections
  window.addEventListener('unhandledrejection', (event) => {
    const error = event.reason instanceof Error ? event.reason : new Error(event.reason);
    captureErrorContext('unhandled-promise', error);
  });

  // Capture console errors
  const originalConsole = {
    error: console.error,
    warn: console.warn,
    log: console.log,
    info: console.info,
    debug: console.debug
  };

  // Override console.error to capture errors
  console.error = function(...args) {
    // Call original console.error first
    originalConsole.error.apply(console, args);
    
    // Capture as error context
    const message = args.map(arg => 
      typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg)
    ).join(' ');
    
    captureErrorContext('console-error', {
      message: `Console Error: ${message}`,
      stack: new Error().stack
    });
  };

  // Override console.warn to capture warnings (optional)
  console.warn = function(...args) {
    // Call original console.warn first
    originalConsole.warn.apply(console, args);
    
    // Capture as error context if it looks like an error
    const message = args.map(arg => 
      typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg)
    ).join(' ');
    
    // Only capture warnings that contain error-like keywords
    if (message.toLowerCase().includes('error') || 
        message.toLowerCase().includes('failed') || 
        message.toLowerCase().includes('exception')) {
      captureErrorContext('console-warning', {
        message: `Console Warning: ${message}`,
        stack: new Error().stack
      });
    }
  };

  // Override XMLHttpRequest
  const originalXHR = window.XMLHttpRequest;
  function XMLHttpRequestProxy() {
    const xhr = new originalXHR();
    const originalOpen = xhr.open;
    const originalSend = xhr.send;
    const originalSetRequestHeader = xhr.setRequestHeader;
    
    let requestHeaders = {};

    xhr.open = function(...args) {
      this._method = args[0];
      this._url = args[1];
      // Resolve relative URLs to absolute URLs
      this._resolvedUrl = this._url.startsWith('http') ? this._url : new URL(this._url, window.location.origin).href;
      requestHeaders = {}; // Reset headers for new request
      return originalOpen.apply(this, args);
    };

    xhr.setRequestHeader = function(name, value) {
      requestHeaders[name] = value;
      return originalSetRequestHeader.apply(this, arguments);
    };

    xhr.send = function(...args) {
      const startTime = Date.now();
      const requestBody = args[0];
      const originalOnReadyStateChange = this.onreadystatechange;
      const originalOnError = this.onerror;
      
      // Capture network errors
      this.onerror = function(event) {
        captureErrorContext('network', new Error(`Network request failed: ${this._method} ${this._resolvedUrl}`), {
          networkDetails: {
            method: this._method,
            status: this.status,
            statusText: this.statusText,
            responseText: this.responseText || ''
          }
        });
        if (originalOnError) {
          return originalOnError.apply(this, arguments);
        }
      };
      
      this.onreadystatechange = function() {
        if (this.readyState === 4) {
          let responseBody = this.responseText;
          
          // Capture HTTP error status codes as errors
          if (this.status >= 400) {
            captureErrorContext('network', new Error(`HTTP ${this.status}: ${this.statusText} - ${this._method} ${this._resolvedUrl}`), {
              networkDetails: {
                method: this._method,
                status: this.status,
                statusText: this.statusText,
                responseText: responseBody || ''
              }
            });
          }
          
          window.postMessage({
            type: 'NETWORK_REQUEST',
            data: {
              method: this._method,
              url: this._resolvedUrl, // Use resolved URL
              status: this.status,
              statusText: this.statusText,
              duration: Date.now() - startTime,
              timestamp: startTime,
              requestBody: requestBody,
              responseBody: responseBody,
              requestHeaders: requestHeaders
            }
          }, '*');
        }
        if (originalOnReadyStateChange) {
          return originalOnReadyStateChange.apply(this, arguments);
        }
      };
      return originalSend.apply(this, args);
    };

    return xhr;
  }

  // Override fetch
  const originalFetch = window.fetch;
  window.fetch = function(...args) {
    const startTime = Date.now();
    const url = typeof args[0] === 'string' ? args[0] : args[0]?.url;
    // Resolve relative URLs to absolute URLs
    const resolvedUrl = url.startsWith('http') ? url : new URL(url, window.location.origin).href;
    const method = args[1]?.method || 'GET';
    const requestBody = args[1]?.body;
    
    // Extract headers from fetch options
    const requestHeaders = {};
    if (args[1]?.headers) {
      if (args[1].headers instanceof Headers) {
        for (let [key, value] of args[1].headers.entries()) {
          requestHeaders[key] = value;
        }
      } else if (typeof args[1].headers === 'object') {
        Object.assign(requestHeaders, args[1].headers);
      }
    }
    
    return originalFetch.apply(this, args).then(async response => {
      let cloned = response.clone();
      let responseBody;
      try {
        responseBody = await cloned.text();
      } catch (e) {
        responseBody = '';
      }
      
      // Capture HTTP error status codes as errors
      if (response.status >= 400) {
        captureErrorContext('network', new Error(`HTTP ${response.status}: ${response.statusText} - ${method} ${resolvedUrl}`), {
          networkDetails: {
            method: method,
            status: response.status,
            statusText: response.statusText,
            responseText: responseBody || ''
          }
        });
      }
      
      window.postMessage({
        type: 'NETWORK_REQUEST',
        data: {
          method: method,
          url: resolvedUrl, // Use resolved URL
          status: response.status,
          statusText: response.statusText,
          duration: Date.now() - startTime,
          timestamp: startTime,
          requestBody: requestBody,
          responseBody: responseBody,
          requestHeaders: requestHeaders
        }
      }, '*');
      return response;
    }).catch(error => {
      // Capture network errors
      captureErrorContext('network', new Error(`Network request failed: ${method} ${resolvedUrl} - ${error.message}`), {
        networkDetails: {
          method: method,
          status: 0,
          statusText: error.message,
          responseText: ''
        }
      });
      
      window.postMessage({
        type: 'NETWORK_REQUEST',
        data: {
          method: method,
          url: resolvedUrl,
          status: 0,
          statusText: error.message,
          duration: Date.now() - startTime,
          timestamp: startTime,
          requestBody: requestBody,
          responseBody: '',
          requestHeaders: requestHeaders
        }
      }, '*');
      throw error;
    });
  };

  window.XMLHttpRequest = XMLHttpRequestProxy;

  // User journey tracking with enhanced context
  function recordJourney(type, value, element = null) {
    window.postMessage({ type: 'DEV_INSIGHTS_JOURNEY', data: {
      type,
      value,
      element,
      timestamp: Date.now()
    } }, '*');
  }

  // Track navigation (URL changes) - enhanced tracking for better sequence
  let lastRecordedUrl = window.location.href;
  let urlCheckInterval = null;
  
  function recordUrlChange(source = 'unknown') {
    const currentUrl = window.location.href;
    
    // Patterns to ignore (automatic system navigation)
    const ignoredPatterns = [
      '/auth/',
      '/login',
      '/logout',
      'guestlogin',
      'redirect',
      'sso',
      'signin'
    ];
    
    // Check if this is an ignored URL
    const isIgnoredUrl = ignoredPatterns.some(pattern => currentUrl.toLowerCase().includes(pattern));
    
    // Check if it's just a root navigation (like going to home page)
    const isRootNavigation = currentUrl.endsWith('/') && currentUrl.split('/').length <= 4;
    
    // Only record if URL actually changed, is meaningful, and not too long
    if (currentUrl !== lastRecordedUrl && 
        !isIgnoredUrl && 
        !isRootNavigation &&
        currentUrl.length < 200) {
      
      recordJourney('url', currentUrl, JSON.stringify({ source, previousUrl: lastRecordedUrl }));
      lastRecordedUrl = currentUrl;
      console.log('URL change recorded:', { from: lastRecordedUrl, to: currentUrl, source });
    }
  }
  
  // Initial URL recording
  recordUrlChange('initial');
  
  // Listen for various navigation events
  window.addEventListener('popstate', () => {
    setTimeout(() => recordUrlChange('popstate'), 10);
  });
  
  // Listen for hashchange events (important for SPA navigation)
  window.addEventListener('hashchange', () => {
    setTimeout(() => recordUrlChange('hashchange'), 10);
  });
  
  // Use MutationObserver to detect URL changes from single-page applications
  let lastUrl = window.location.href;
  new MutationObserver(() => {
    const currentUrl = window.location.href;
    if (currentUrl !== lastUrl) {
      lastUrl = currentUrl;
      setTimeout(() => recordUrlChange('spa-navigation'), 50);
    }
  }).observe(document, { subtree: true, childList: true });
  
  // Periodically check for URL changes (fallback for missed changes)
  urlCheckInterval = setInterval(() => {
    if (window.location.href !== lastRecordedUrl) {
      recordUrlChange('periodic-check');
    }
  }, 500);
  
  // Override history methods to catch programmatic navigation
  const originalPushState = history.pushState;
  const originalReplaceState = history.replaceState;
  
  history.pushState = function(...args) {
    const result = originalPushState.apply(this, args);
    setTimeout(() => recordUrlChange('pushState'), 10);
    return result;
  };
  
  history.replaceState = function(...args) {
    const result = originalReplaceState.apply(this, args);
    setTimeout(() => recordUrlChange('replaceState'), 10);
    return result;
  };
  
  // Also track on focus in case user navigates via browser controls
  window.addEventListener('focus', () => {
    setTimeout(() => recordUrlChange('focus'), 50);
  });

  // Track clicks with detailed element info and improved sequencing
  document.addEventListener('click', (e) => {
    let target = e.target;
    if (target instanceof HTMLElement) {
      // Only track meaningful clicks - buttons, links, and interactive elements
      let elementType = target.tagName.toLowerCase();
      let desc = '';
      
      // Get meaningful text content
      let text = target.innerText || target.textContent || target.value || target.placeholder || target.title || target.alt;
      if (text) {
        text = text.trim().substring(0, 60);
      }
      
      // Check if this click will likely cause navigation
      let willNavigate = false;
      let navigationUrl = null;
      
      if (elementType === 'a' && target.href) {
        willNavigate = true;
        navigationUrl = target.href;
      } else if (target.onclick && target.onclick.toString().includes('location')) {
        willNavigate = true;
      }
      
      // Only track clicks on meaningful interactive elements
      if (elementType === 'button') {
        desc = text ? `Clicked button: "${text}"` : 'Clicked button';
      } else if (elementType === 'a') {
        desc = text ? `Clicked link: "${text}"` : 'Clicked link';
        if (navigationUrl) {
          desc += ` (leads to: ${navigationUrl})`;
        }
      } else if (elementType === 'input' && (target.type === 'button' || target.type === 'submit')) {
        desc = text ? `Clicked ${target.type}: "${text}"` : `Clicked ${target.type}`;
      } else if (elementType === 'select') {
        desc = 'Selected from dropdown';
      } else if (target.onclick || target.getAttribute('onclick') || target.classList.contains('clickable') || target.role === 'button') {
        // Only if it has click handlers or appears to be clickable
        if (text && text.length > 0 && text.length < 100) {
          desc = `Clicked: "${text}"`;
        } else {
          return; // Skip non-meaningful clicks
        }
      } else {
        return; // Skip non-interactive elements
      }
      
      // Skip if description is empty or too generic
      if (!desc || desc.includes('undefined') || desc.includes('null')) {
        return;
      }
      
      let elementInfo = {
        tag: elementType,
        text: text || null,
        href: target.href || null,
        type: target.type || null,
        willNavigate: willNavigate,
        navigationUrl: navigationUrl
      };
      
      // Record the click immediately
      recordJourney('click', desc, JSON.stringify(elementInfo));
      
      // If this might cause navigation, record the current URL state
      if (willNavigate && navigationUrl) {
        // Add a slight delay to capture navigation after the click
        setTimeout(() => {
          recordUrlChange('click-navigation');
        }, 50);
      }
    }
  }, true);

  // Track input interactions - only when meaningful content is entered
  document.addEventListener('input', (e) => {
    let target = e.target;
    if (target instanceof HTMLElement && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
      // Only track if there's actual meaningful input
      const value = target.value.trim();
      if (value.length < 3) return; // Skip short inputs
      
      let desc = '';
      const inputType = target.type || 'text';
      const label = target.placeholder || target.name || target.getAttribute('aria-label') || 'field';
      
      if (target.tagName === 'TEXTAREA') {
        desc = `Entered text in ${label}`;
      } else {
        switch (inputType.toLowerCase()) {
          case 'email':
            desc = `Entered email in ${label}`;
            break;
          case 'password':
            desc = `Entered password in ${label}`;
            break;
          case 'search':
            desc = `Searched in ${label}`;
            break;
          case 'tel':
            desc = `Entered phone number in ${label}`;
            break;
          case 'number':
            desc = `Entered number in ${label}`;
            break;
          default:
            desc = `Entered text in ${label}`;
        }
      }
      
      recordJourney('input', desc, JSON.stringify({
        type: inputType,
        placeholder: target.placeholder || null
      }));
    }
  }, true);

  // Track focus events - only for form fields
  document.addEventListener('focus', (e) => {
    let target = e.target;
    if (target instanceof HTMLElement && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT')) {
      const label = target.placeholder || target.name || target.getAttribute('aria-label') || 'field';
      let desc = `Focused on ${label}`;
      recordJourney('focus', desc);
    }
  }, true);

  // Skip scroll tracking as it's not useful for error reproduction
})();