// Background script for Developer Insights Extension
class DevInsightsBackground {
  constructor() {
    this.networkRequests = new Map();
    this.injectedRequests = new Map(); // Separate storage for injected requests
    this.errorContext = new Map(); // Store error context by tab ID
    this.setupEventListeners();
  }

  setupEventListeners() {
    // Listen for debugger events
    chrome.debugger.onEvent.addListener((source, method, params) => {
      if (method === 'Network.responseReceived' || method === 'Network.requestWillBeSent') {
        this.handleNetworkEvent(source.tabId, method, params);
      }
    });

    // Listen for tab updates to attach debugger
    chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
      if (changeInfo.status === 'loading' && tab.url && !tab.url.startsWith('chrome://')) {
        this.attachDebugger(tabId);
      }
    });

    // Listen for messages from content script and popup
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.type === 'ERROR_CONTEXT') {
        // Store error context
        const tabId = sender.tab?.id || request.tabId || 'global';
        const key = `${tabId}`;
        if (!this.errorContext.has(key)) {
          this.errorContext.set(key, []);
        }
        const errors = this.errorContext.get(key);
        const id = `${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
        errors.push({ ...request.data, id, timestamp: Date.now() });
        // Keep only last 50 errors per tab
        if (errors.length > 50) {
          errors.splice(0, errors.length - 50);
        }
        this.errorContext.set(key, errors);
        return;
      }
      
      if (request.type === 'INJECTED_NETWORK_REQUEST') {
        // Store injected network request (API call) - these have complete data
        const tabId = sender.tab?.id || (request.data && request.data.tabId) || 'injected';
        const key = `${tabId}`;
        if (!this.injectedRequests.has(key)) {
          this.injectedRequests.set(key, []);
        }
        const requests = this.injectedRequests.get(key);
        // Add a unique id for injected requests
        const id = `${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
        requests.push({ ...request.data, id });
        if (requests.length > 100) {
          requests.splice(0, requests.length - 100);
        }
        this.injectedRequests.set(key, requests);
        return;
      }
      
      if (request.type === 'JOURNEY_EVENT') {
        const tabId = sender.tab?.id || 'global';
        const key = `devInsightsJourney_${tabId}`;
        chrome.storage.local.get([key], (result) => {
          const steps = result[key] || [];
          
          // Add timestamp if not already present
          const eventData = {
            ...request.data,
            timestamp: request.data.timestamp || Date.now()
          };
          
          steps.push(eventData);
          
          // Keep only last 100 steps to prevent storage issues
          if (steps.length > 100) {
            steps.splice(0, steps.length - 100);
          }
          
          // Sort by timestamp to ensure proper ordering
          steps.sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));
          
          chrome.storage.local.set({ [key]: steps }, () => {
            if (chrome.runtime.lastError) {
              console.warn('Failed to save journey step:', chrome.runtime.lastError);
            }
          });
        });
        return;
      }

      if (request.type === 'GET_JOURNEY') {
        const tabId = request.tabId || 'global';
        const key = `devInsightsJourney_${tabId}`;
        chrome.storage.local.get([key], (result) => {
          sendResponse({ steps: result[key] || [] });
        });
        return true; // async response
      }

      if (request.type === 'CLEAR_JOURNEY') {
        const tabId = request.tabId || 'global';
        const key = `devInsightsJourney_${tabId}`;
        chrome.storage.local.set({ [key]: [] }, () => {
          sendResponse({ success: true });
        });
        return true; // async response
      }

      this.handleMessage(request, sender, sendResponse);
      return true; // Keep message channel open for async response
    });
  }

  async attachDebugger(tabId) {
    try {
      await chrome.debugger.attach({ tabId }, '1.0');
      await chrome.debugger.sendCommand({ tabId }, 'Network.enable');
      await chrome.debugger.sendCommand({ tabId }, 'Runtime.enable');
    } catch (error) {
      console.log('Could not attach debugger:', error);
    }
  }

  handleNetworkEvent(tabId, method, params) {
    const key = `${tabId}`;
    if (!this.networkRequests.has(key)) {
      this.networkRequests.set(key, []);
    }

    const requests = this.networkRequests.get(key);
    
    if (method === 'Network.requestWillBeSent') {
      const request = {
        id: params.requestId,
        method: params.request.method,
        url: params.request.url,
        timestamp: params.timestamp,
        status: 'pending',
        type: params.type || 'unknown'
      };
      requests.push(request);
    } else if (method === 'Network.responseReceived') {
      const existingRequest = requests.find(req => req.id === params.requestId);
      if (existingRequest) {
        existingRequest.status = params.response.status;
        existingRequest.statusText = params.response.statusText;
        existingRequest.responseTimestamp = params.timestamp;
        existingRequest.duration = (params.timestamp - existingRequest.timestamp) * 1000;
      }
    }

    // Keep only last 100 requests per tab
    if (requests.length > 100) {
      requests.splice(0, requests.length - 100);
    }

    this.networkRequests.set(key, requests);
  }

  async handleMessage(request, sender, sendResponse) {
    switch (request.type) {
      case 'GET_ERROR_CONTEXT':
        const errorTabId = request.tabId;
        const errors = this.errorContext.get(`${errorTabId}`) || [];
        sendResponse({ errors });
        break;

      case 'CLEAR_ERROR_CONTEXT':
        const clearTabId = request.tabId;
        this.errorContext.set(`${clearTabId}`, []);
        sendResponse({ success: true });
        break;

      case 'GET_NETWORK_DATA':
        const tabId = request.tabId;
        const debuggerRequests = this.networkRequests.get(`${tabId}`) || [];
        const injectedRequests = this.injectedRequests.get(`${tabId}`) || [];
        
        // Merge and deduplicate, prioritizing injected requests (they have complete data)
        const mergedRequests = [...injectedRequests];
        
        // Add debugger requests that don't have a matching injected request
        debuggerRequests.forEach(debuggerReq => {
          const hasMatchingInjected = injectedRequests.some(injectedReq => {
            // Match by URL and method and similar timestamp (within 1 second)
            return injectedReq.url === debuggerReq.url && 
                   injectedReq.method === debuggerReq.method &&
                   Math.abs((injectedReq.timestamp || 0) - (debuggerReq.timestamp || 0)) < 1;
          });
          
          if (!hasMatchingInjected) {
            mergedRequests.push(debuggerReq);
          }
        });
        
        // Sort by timestamp (newest first)
        mergedRequests.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
        
        sendResponse({ networkRequests: mergedRequests });
        break;

      case 'GET_COOKIES':
        if (request.url) {
          chrome.cookies.getAll({ url: request.url }, (cookies) => {
            sendResponse({ cookies });
          });
          return true; // async
        } else {
          sendResponse({ cookies: [] });
        }
        break;

      case 'CLEAR_NETWORK_DATA':
        if (request.tabId) {
          this.networkRequests.set(`${request.tabId}`, []);
          this.injectedRequests.set(`${request.tabId}`, []);
        }
        sendResponse({ success: true });
        break;

      case 'CONSOLE_LOG':
        // Store console logs in chrome.storage.local
        let logTabId = sender.tab?.id;
        if (!logTabId && request.tabId) logTabId = request.tabId;
        if (!logTabId) logTabId = 'global';
        const logs = await this.getStoredData('consoleLogs', []);
        logs.push({
          ...request.data,
          timestamp: Date.now(),
          tabId: logTabId
        });
        // Keep only last 100 logs
        if (logs.length > 100) {
          logs.splice(0, logs.length - 100);
        }
        await chrome.storage.local.set({ consoleLogs: logs });
        break;

      case 'GET_CONSOLE_LOGS':
      case 'GET_CONSOLE_LOGS':
        const consoleLogs = await this.getStoredData('consoleLogs', []);
        const filteredLogs = consoleLogs.filter(log => log.tabId === request.tabId);
        sendResponse({ consoleLogs: filteredLogs });
        break;

      case 'CLEAR_CONSOLE_LOGS':
        await chrome.storage.local.set({ consoleLogs: [] });
        sendResponse({ success: true });
        break;
    }
  }

  async getStoredData(key, defaultValue) {
    const result = await chrome.storage.local.get([key]);
    return result[key] || defaultValue;
  }
}

// Initialize background script
new DevInsightsBackground();