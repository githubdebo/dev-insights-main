import { useState, useEffect } from 'react';
import { NetworkTab } from './components/NetworkTab';
import { JourneyTab } from './components/JourneyTab';
import { ApiTesterTab } from './components/ApiTesterTab';
import { ErrorContextTab } from './components/ErrorContextTab';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Activity, ChevronUp, ChevronDown, Send, AlertTriangle } from 'lucide-react';

type Tab = 'api' | 'assets' | 'journey' | 'api-tester' | 'error-context';

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('api');
  const [currentTabId, setCurrentTabId] = useState<number | null>(null);
  const [headerVisible, setHeaderVisible] = useState(true);
  const [isDevToolsPanel, setIsDevToolsPanel] = useState(false);
  // Tab-specific state for displayed network calls
  const [displayedNetworkCallsByTab, setDisplayedNetworkCallsByTab] = useState<Record<number, any[]>>({});

  useEffect(() => {
    // Detect if running in DevTools panel
    setIsDevToolsPanel(window.location.pathname.includes('panel.html') || window.parent !== window);
    
    // Get current tab ID
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        setCurrentTabId(tabs[0].id!);
      }
    });

    // Global error handler for extension UI
    const handleError = (event: ErrorEvent) => {
      console.error('Global error in extension UI:', event.error);
      // Prevent the error from crashing the entire extension
      event.preventDefault();
    };

    const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
      console.error('Unhandled promise rejection in extension UI:', event.reason);
      // Prevent the rejection from crashing the extension
      event.preventDefault();
    };

    window.addEventListener('error', handleError);
    window.addEventListener('unhandledrejection', handleUnhandledRejection);

    return () => {
      window.removeEventListener('error', handleError);
      window.removeEventListener('unhandledrejection', handleUnhandledRejection);
    };
  }, []);

  // Helper to get/set calls for current tab
  const displayedNetworkCalls = currentTabId ? (displayedNetworkCallsByTab[currentTabId] || []) : [];
  const setDisplayedCalls: React.Dispatch<React.SetStateAction<any[]>> = (value) => {
    if (currentTabId == null) return;
    setDisplayedNetworkCallsByTab(prev => {
      const prevCalls = prev[currentTabId] || [];
      const nextCalls = typeof value === 'function' ? (value as (prev: any[]) => any[])(prevCalls) : value;
      return { ...prev, [currentTabId]: nextCalls };
    });
  };

  // Refresh network data for API Tester tab
  const refreshApiTesterData = async () => {
    if (!currentTabId) return;
    
    try {
      const response = await chrome.runtime.sendMessage({
        type: 'GET_NETWORK_DATA',
        tabId: currentTabId
      });
      const networkRequests = response.networkRequests || [];
      
      // Update the displayed calls for this tab
      setDisplayedNetworkCallsByTab(prev => ({
        ...prev,
        [currentTabId]: networkRequests
      }));
    } catch (error) {
      console.error('Failed to refresh API tester data:', error);
    }
  };

  const tabs = [
    { id: 'api' as Tab, label: 'API', icon: Activity },
    { id: 'assets' as Tab, label: 'Assets', icon: Activity },
    { id: 'api-tester' as Tab, label: 'API Tester', icon: Send },
    { id: 'journey' as Tab, label: 'Journey', icon: Activity },
    { id: 'error-context' as Tab, label: 'Error Context', icon: AlertTriangle },
  ];

  return (
    <div className={`bg-gray-900 text-white flex flex-col relative ${isDevToolsPanel ? 'h-full w-full' : 'w-[780px] h-[595px]'}`}>
      {/* Header Toggle Button */}
      <button
        className="absolute top-1 right-2 z-20 bg-gray-700 rounded-full p-1 hover:bg-gray-600 focus:outline-none"
        onClick={() => setHeaderVisible(v => !v)}
        title={headerVisible ? 'Hide header' : 'Show header'}
        style={{ lineHeight: 0 }}
      >
        {headerVisible ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
      </button>

      {/* Header */}
      {headerVisible && (
        <div className="bg-gray-800 border-b border-gray-700 p-2">
          <h1 className="text-base font-semibold text-blue-400">Developer Insights</h1>
          <p className="text-xs text-gray-400 mt-0.5">Web development debugging tools</p>
        </div>
      )}

      {/* Tab Navigation */}
      {headerVisible ? (
        <div className="bg-gray-800 border-b border-gray-700">
          <div className="flex">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 px-4 py-2 text-sm font-medium transition-colors duration-200 ${
                    activeTab === tab.id
                      ? 'bg-blue-600 text-white border-b-2 border-blue-400'
                      : 'text-gray-300 hover:text-white hover:bg-gray-700'
                  }`}
                >
                  <Icon size={16} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-center bg-gray-800 border-b border-gray-700 py-1">
          <span className="bg-blue-700 text-white text-xs font-semibold rounded px-3 py-1">
            {tabs.find(t => t.id === activeTab)?.label}
          </span>
        </div>
      )}

      {/* Tab Content */}
      <div className="flex-1 overflow-hidden">
        <div className="h-full overflow-y-auto">
          {activeTab === 'api' && <NetworkTab tabId={currentTabId} type="api" displayedCalls={displayedNetworkCalls} setDisplayedCalls={setDisplayedCalls} />}
          {activeTab === 'assets' && <NetworkTab tabId={currentTabId} type="assets" displayedCalls={displayedNetworkCalls} setDisplayedCalls={setDisplayedCalls} />}
          {activeTab === 'api-tester' && <ApiTesterTab displayedCalls={displayedNetworkCalls} onRefresh={refreshApiTesterData} />}
          {activeTab === 'journey' && <JourneyTab />}
          {activeTab === 'error-context' && (
            <ErrorBoundary>
              <ErrorContextTab tabId={currentTabId} />
            </ErrorBoundary>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;