import React, { useEffect, useState } from 'react';

// Simple step/flow node for the journey
interface JourneyStep {
  type: 'url' | 'click';
  value: string;
  timestamp: number;
}

export const JourneyTab: React.FC = () => {
  const [steps, setSteps] = useState<JourneyStep[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Get current tab ID and fetch journey steps for this tab
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabId = tabs[0]?.id || 'global';
      try {
        chrome.runtime.sendMessage({ type: 'GET_JOURNEY', tabId }, (resp) => {
          if (chrome.runtime.lastError) {
            setError('Unable to load journey data. Extension context may be invalid or reloaded.');
            return;
          }
          if (resp && resp.steps) {
            // Sort steps by timestamp ascending
            setSteps([...resp.steps].sort((a, b) => a.timestamp - b.timestamp));
          } else setError('No journey data found for this tab.');
        });
      } catch (e) {
        setError('Unable to load journey data. Extension context may be invalid or reloaded.');
      }
    });
  }, []);

  // Add a refresh handler
  const handleRefresh = () => {
    setError(null);
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabId = tabs[0]?.id || 'global';
      try {
        chrome.runtime.sendMessage({ type: 'GET_JOURNEY', tabId }, (resp) => {
          if (chrome.runtime.lastError) {
            setError('Unable to load journey data. Extension context may be invalid or reloaded.');
            return;
          }
          if (resp && resp.steps) {
            // Sort steps by timestamp ascending
            setSteps([...resp.steps].sort((a, b) => a.timestamp - b.timestamp));
          } else setError('No journey data found for this tab.');
        });
      } catch (e) {
        setError('Unable to load journey data. Extension context may be invalid or reloaded.');
      }
    });
  };

  return (
    <div className="h-full flex flex-col p-4">
      <h2 className="text-lg font-semibold mb-2 flex items-center">User Journey
        <button
          className="ml-4 px-2 py-1 text-xs bg-blue-700 hover:bg-blue-800 rounded text-white"
          onClick={handleRefresh}
        >
          Refresh
        </button>
      </h2>
      <p className="text-sm text-gray-400 mb-4">Shows the sequence of URLs visited and clicks performed in this tab.</p>
      {error ? (
        <div className="text-red-400 text-sm mb-4">{error}</div>
      ) : steps.length === 0 ? (
        <div className="text-gray-400 text-sm mb-4">No journey data found for this tab yet.</div>
      ) : (
        // List representation
        <div className="mb-6">
          <h3 className="text-base font-semibold mb-2">Step List</h3>
          <ol className="list-decimal ml-6">
            {steps.map((step, i) => (
              <li key={i} className="mb-1">
                <span className="font-mono text-xs text-gray-400">{new Date(step.timestamp).toLocaleTimeString()} </span>
                {step.type === 'url' ? (
                  <span className="text-blue-400">Visited: </span>
                ) : (
                  <span className="text-green-400">Clicked: </span>
                )}
                <span className="break-all">{step.value}</span>
              </li>
            ))}
          </ol>
        </div>
      )}
    </div>
  );
};
