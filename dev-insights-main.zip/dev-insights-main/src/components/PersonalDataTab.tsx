import React, { useMemo, useState } from 'react';
import { ShieldAlert, Trash2 } from 'lucide-react';

// Patterns for personal/sensitive data
const patterns = [
  { label: 'Email', regex: /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g },
  { label: 'Bearer Token', regex: /Bearer [A-Za-z0-9\-_.]+/g },
  { label: 'JWT', regex: /eyJ[a-zA-Z0-9\-_]+\.[a-zA-Z0-9\-_]+\.[a-zA-Z0-9\-_]+/g },
  { label: 'API Key', regex: /api[_-]?key["':=\s]+[A-Za-z0-9\-_]+/gi },
  { label: 'ID (UUID)', regex: /[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}/g },
  { label: 'Session ID', regex: /sess[_-]?id["':=\s]+[A-Za-z0-9\-_]+/gi },
];

function extractMatches(str: unknown) {
  const found: { label: string; value: string }[] = [];
  if (typeof str !== 'string') return found;
  for (const { label, regex } of patterns) {
    try {
      const matches = str.match(regex);
      if (matches) {
        for (const value of matches) {
          found.push({ label, value });
        }
      }
    } catch (e) {}
  }
  return found;
}

export const PersonalDataTab = ({ displayedCalls, cookies = [], onClear }: {
  displayedCalls: any[],
  cookies?: { name: string, value: string }[],
  onClear?: () => void
}) => {
  // Filter state
  const [filter, setFilter] = useState('');

  // Scan network calls
  const networkFindings = useMemo(() => {
    const findings: { label: string; value: string; url: string; type: string }[] = [];
    for (const call of displayedCalls) {
      const bodies = [call.requestBody, call.responseBody].filter(Boolean).map(b => typeof b === 'string' ? b : JSON.stringify(b));
      for (const body of bodies) {
        for (const { label, value } of extractMatches(body)) {
          findings.push({ label, value, url: call.url, type: call.method });
        }
      }
      // Also scan URL
      for (const { label, value } of extractMatches(call.url)) {
        findings.push({ label, value, url: call.url, type: call.method });
      }
    }
    return findings;
  }, [displayedCalls]);

  // Scan cookies
  const cookieFindings = useMemo(() => {
    const findings: { label: string; value: string; key: string }[] = [];
    for (const { name, value } of cookies) {
      for (const { label, value: v } of extractMatches(value)) {
        findings.push({ label, value: v, key: name });
      }
    }
    return findings;
  }, [cookies]);

  // Scan storage
  const storageFindings: { label: string; value: string; key: string }[] = [];
  
  // Separate localStorage and sessionStorage findings (empty since we removed storage)
  const localStorageFindings: { label: string; value: string; key: string }[] = [];
  const sessionStorageFindings: { label: string; value: string; key: string }[] = [];

  // Track if storage access failed due to CSP
  const [storageError, setStorageError] = React.useState<string | null>(null);
  React.useEffect(() => {
    // Listen for CSP error message from content script (if you want to wire it in the future)
    window.addEventListener('dev-insights-storage-error', (e: any) => {
      setStorageError(e.detail || 'Unable to access localStorage/sessionStorage due to site security policy (CSP).');
    });
    return () => window.removeEventListener('dev-insights-storage-error', () => {});
  }, []);

  // Filtered cookie findings
  const filteredCookieFindings = useMemo(() => {
    if (!filter) return cookieFindings;
    return cookieFindings.filter(f =>
      f.label.toLowerCase().includes(filter.toLowerCase()) ||
      f.value.toLowerCase().includes(filter.toLowerCase()) ||
      f.key.toLowerCase().includes(filter.toLowerCase())
    );
  }, [cookieFindings, filter]);

  // Filtered localStorage findings
  const filteredLocalStorageFindings = useMemo(() => {
    if (!filter) return localStorageFindings;
    return localStorageFindings.filter(f =>
      f.label.toLowerCase().includes(filter.toLowerCase()) ||
      f.value.toLowerCase().includes(filter.toLowerCase()) ||
      f.key.toLowerCase().includes(filter.toLowerCase())
    );
  }, [localStorageFindings, filter]);

  // Filtered sessionStorage findings
  const filteredSessionStorageFindings = useMemo(() => {
    if (!filter) return sessionStorageFindings;
    return sessionStorageFindings.filter(f =>
      f.label.toLowerCase().includes(filter.toLowerCase()) ||
      f.value.toLowerCase().includes(filter.toLowerCase()) ||
      f.key.toLowerCase().includes(filter.toLowerCase())
    );
  }, [sessionStorageFindings, filter]);

  return (
    <div className="h-full flex flex-col p-4">
      <div className="flex items-center mb-4 justify-between">
        <div className="flex items-center">
          <ShieldAlert className="text-yellow-400 mr-2" />
          <h2 className="text-lg font-semibold">Personal Data Map</h2>
        </div>
        <button
          className="flex items-center space-x-1 px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white text-xs rounded transition-colors"
          onClick={onClear}
        >
          <Trash2 size={14} />
          <span>Clear Personal Data</span>
        </button>
      </div>
      <p className="text-sm text-gray-400 mb-4">Shows emails, tokens, IDs, and other sensitive data found in network traffic, cookies, and storage.</p>
      <div className="flex-1 overflow-y-auto">
        <input
          type="text"
          placeholder="Filter personal data by key, value, or type..."
          value={filter}
          onChange={e => setFilter(e.target.value)}
          className="w-full mb-3 px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
        />
        <h3 className="text-base font-semibold mt-4 mb-1">Cookies</h3>
        {filteredCookieFindings.length === 0 ? <div className="text-gray-500 text-sm mb-2">No personal data found in cookies.</div> : (
          <table className="w-full text-xs mb-4">
            <thead>
              <tr className="text-gray-400">
                <th className="text-left">Type</th>
                <th className="text-left">Value</th>
                <th className="text-left">Cookie Name</th>
              </tr>
            </thead>
            <tbody>
              {filteredCookieFindings.map((f, i) => (
                <tr key={i} className="border-b border-gray-700">
                  <td>{f.label}</td>
                  <td className="break-all text-yellow-300">{f.value}</td>
                  <td>{f.key}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        <h3 className="text-base font-semibold mt-4 mb-1">Storage</h3>
        {storageError ? (
          <div className="text-red-400 text-sm mb-2">{storageError}</div>
        ) : (
          <>
            <h4 className="text-sm font-semibold mt-2 mb-1 text-blue-300">localStorage</h4>
            {filteredLocalStorageFindings.length === 0 ? <div className="text-gray-500 text-sm mb-2">No personal data found in localStorage.</div> : (
              <table className="w-full text-xs mb-4">
                <thead>
                  <tr className="text-gray-400">
                    <th className="text-left">Type</th>
                    <th className="text-left">Value</th>
                    <th className="text-left">Key</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredLocalStorageFindings.map((f, i) => (
                    <tr key={i} className="border-b border-gray-700">
                      <td>{f.label}</td>
                      <td className="break-all text-yellow-300">{f.value}</td>
                      <td>{f.key.replace('local:', '')}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
            <h4 className="text-sm font-semibold mt-2 mb-1 text-blue-300">sessionStorage</h4>
            {filteredSessionStorageFindings.length === 0 ? <div className="text-gray-500 text-sm mb-2">No personal data found in sessionStorage.</div> : (
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-gray-400">
                    <th className="text-left">Type</th>
                    <th className="text-left">Value</th>
                    <th className="text-left">Key</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredSessionStorageFindings.map((f, i) => (
                    <tr key={i} className="border-b border-gray-700">
                      <td>{f.label}</td>
                      <td className="break-all text-yellow-300">{f.value}</td>
                      <td>{f.key.replace('session:', '')}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </>
        )}
      </div>
    </div>
  );
};
