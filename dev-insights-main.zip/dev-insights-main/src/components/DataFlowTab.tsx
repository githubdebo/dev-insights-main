import React, { useEffect, useState } from 'react';
import { GitBranch, MousePointer, Edit3, Send, Clock, RefreshCw } from 'lucide-react';

// Data flow event types
interface DataFlowEvent {
  id: string;
  type: 'form_submission' | 'click_interaction' | 'input_change';
  timestamp: number;
  element: string;
  data?: any;
  action?: string;
  method?: string;
  text?: string;
  href?: string;
  inputType?: string;
  hasValue?: boolean;
}

// Network request interface for correlation
interface NetworkRequest {
  id: string;
  method: string;
  url: string;
  timestamp: number;
  duration?: number;
  status: number | string;
}

interface DataFlowTabProps {
  tabId: number | null;
}

export const DataFlowTab: React.FC<DataFlowTabProps> = ({ tabId }) => {
  const [networkRequests, setNetworkRequests] = useState<NetworkRequest[]>([]);
  const [correlatedFlows, setCorrelatedFlows] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedFlow, setSelectedFlow] = useState<string | null>(null);

  // Load data flow events
  const loadDataFlowEvents = async () => {
    if (!tabId) return;
    
    setIsLoading(true);
    try {
      // Get data flow events via content script message passing
      const flowResponse = await new Promise<any>((resolve, reject) => {
        try {
          chrome.tabs.sendMessage(tabId, { type: 'GET_DATA_FLOW' }, (response) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else {
              resolve(response);
            }
          });
        } catch (error) {
          reject(error);
        }
      });
      
      // Get network requests for correlation
      const networkResponse = await chrome.runtime.sendMessage({
        type: 'GET_NETWORK_DATA',
        tabId: tabId
      });

      const flows = flowResponse?.flows || [];
      const requests = networkResponse?.networkRequests || [];
      
      console.log('Loaded data flow events:', flows.length, 'flows and', requests.length, 'requests');
      
      setNetworkRequests(requests);
      
      // Correlate flows with network requests
      correlateFlowsWithRequests(flows, requests);
      
    } catch (error) {
      console.error('Failed to load data flow events:', error);
      // Set empty data to show the UI
      setNetworkRequests([]);
      setCorrelatedFlows([]);
    } finally {
      setIsLoading(false);
    }
  };

  // Correlate user interactions with network requests
  const correlateFlowsWithRequests = (flows: DataFlowEvent[], requests: NetworkRequest[]) => {
    const correlations = [];
    const timeWindow = 5000; // 5 seconds correlation window

    for (const flow of flows) {
      const relatedRequests = requests.filter(req => 
        Math.abs(req.timestamp - flow.timestamp) <= timeWindow &&
        req.timestamp >= flow.timestamp // Request must come after or at the same time as interaction
      );

      if (relatedRequests.length > 0) {
        correlations.push({
          id: flow.id,
          interaction: flow,
          requests: relatedRequests.sort((a, b) => a.timestamp - b.timestamp),
          correlation: 'likely'
        });
      } else {
        correlations.push({
          id: flow.id,
          interaction: flow,
          requests: [],
          correlation: 'none'
        });
      }
    }

    setCorrelatedFlows(correlations);
  };

  useEffect(() => {
    loadDataFlowEvents();
    // Refresh every 3 seconds
    const interval = setInterval(loadDataFlowEvents, 3000);
    return () => clearInterval(interval);
  }, [tabId]);

  const getEventIcon = (type: string) => {
    switch (type) {
      case 'form_submission': return <Send size={16} className="text-green-400" />;
      case 'click_interaction': return <MousePointer size={16} className="text-blue-400" />;
      case 'input_change': return <Edit3 size={16} className="text-yellow-400" />;
      default: return <GitBranch size={16} className="text-gray-400" />;
    }
  };

  const getEventLabel = (type: string) => {
    switch (type) {
      case 'form_submission': return 'Form Submit';
      case 'click_interaction': return 'Click';
      case 'input_change': return 'Input Change';
      default: return 'Unknown';
    }
  };

  const getStatusColor = (status: number | string) => {
    const statusNum = typeof status === 'string' ? parseInt(status) : status;
    if (statusNum >= 200 && statusNum < 300) return 'text-green-400';
    if (statusNum >= 300 && statusNum < 400) return 'text-yellow-400';
    if (statusNum >= 400) return 'text-red-400';
    return 'text-gray-400';
  };

  const formatTimestamp = (timestamp: number) => {
    return new Date(timestamp).toLocaleTimeString();
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 bg-gray-800 border-b border-gray-700">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold text-blue-400 flex items-center space-x-2">
            <GitBranch size={20} />
            <span>Data Flow Visualization</span>
          </h2>
          <div className="flex space-x-2">
            <button
              onClick={loadDataFlowEvents}
              disabled={isLoading}
              className="flex items-center space-x-1 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm rounded transition-colors"
            >
              <RefreshCw size={14} className={isLoading ? 'animate-spin' : ''} />
              <span>Refresh</span>
            </button>
            <button
              onClick={() => {
                // Test button to inject a data flow event for testing
                if (tabId) {
                  try {
                    chrome.tabs.sendMessage(tabId, { 
                      type: 'INJECT_TEST_EVENT',
                      data: {
                        type: 'click_interaction',
                        timestamp: Date.now(),
                        element: 'button.test',
                        text: 'Test Button Click',
                        href: null
                      }
                    });
                    setTimeout(loadDataFlowEvents, 100);
                  } catch (error) {
                    console.log('Could not inject test event:', error);
                  }
                }
              }}
              className="flex items-center space-x-1 px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white text-sm rounded transition-colors"
            >
              <span>Test Event</span>
            </button>
          </div>
        </div>
        
        <div className="text-sm text-gray-400">
          {correlatedFlows.length} user interactions • {networkRequests.length} network requests
        </div>
        
        <div className="text-xs text-gray-500 mt-2">
          This view shows user interactions and their correlated network requests to help visualize data flow patterns.
          {correlatedFlows.length === 0 && (
            <span className="block mt-1 text-yellow-500">
              💡 Tip: Try clicking buttons, submitting forms, or typing in input fields to see data flow events.
            </span>
          )}
        </div>
      </div>

      {/* Flow List */}
      <div className="flex-1 overflow-y-auto">
        {correlatedFlows.length === 0 ? (
          <div className="flex items-center justify-center h-full text-gray-400">
            <div className="text-center">
              <GitBranch size={48} className="mx-auto mb-4 opacity-50" />
              <p>No data flow events captured yet</p>
              <p className="text-sm mt-1">Interact with the page to see data flow patterns</p>
            </div>
          </div>
        ) : (
          <div className="divide-y divide-gray-700">
            {correlatedFlows.map((flow) => (
              <div key={flow.id} className="p-4">
                {/* Interaction Event */}
                <div 
                  className={`mb-3 p-3 rounded border cursor-pointer transition-colors ${
                    selectedFlow === flow.id ? 'bg-gray-800 border-blue-500' : 'bg-gray-900 border-gray-600 hover:border-gray-500'
                  }`}
                  onClick={() => setSelectedFlow(selectedFlow === flow.id ? null : flow.id)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      {getEventIcon(flow.interaction.type)}
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <span className="text-sm font-medium text-white">
                            {getEventLabel(flow.interaction.type)}
                          </span>
                          <span className="text-xs text-gray-400">
                            {formatTimestamp(flow.interaction.timestamp)}
                          </span>
                        </div>
                        <div className="text-xs text-gray-300 mb-1">
                          Element: <code className="bg-gray-700 px-1 rounded">{flow.interaction.element}</code>
                        </div>
                        {flow.interaction.text && (
                          <div className="text-xs text-gray-400">
                            Text: "{flow.interaction.text.substring(0, 50)}{flow.interaction.text.length > 50 ? '...' : ''}"
                          </div>
                        )}
                        {flow.interaction.action && (
                          <div className="text-xs text-gray-400">
                            Action: {flow.interaction.action} ({flow.interaction.method})
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {flow.requests.length > 0 && (
                        <span className="px-2 py-1 bg-green-900 text-green-300 text-xs rounded">
                          {flow.requests.length} request{flow.requests.length > 1 ? 's' : ''}
                        </span>
                      )}
                      {flow.requests.length === 0 && (
                        <span className="px-2 py-1 bg-gray-700 text-gray-400 text-xs rounded">
                          No requests
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Correlated Network Requests */}
                {selectedFlow === flow.id && flow.requests.length > 0 && (
                  <div className="ml-6 space-y-2">
                    <div className="text-xs font-medium text-gray-400 mb-2">
                      → Correlated Network Requests:
                    </div>
                    {flow.requests.map((request: NetworkRequest) => (
                      <div key={request.id} className="bg-gray-800 p-2 rounded text-sm border-l-2 border-blue-500">
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center space-x-2">
                            <span className="font-mono text-xs font-semibold text-blue-400">
                              {request.method}
                            </span>
                            <span className={`font-mono text-xs ${getStatusColor(request.status)}`}>
                              {request.status}
                            </span>
                            {request.duration && (
                              <span className="text-xs text-gray-400">
                                {request.duration.toFixed(0)}ms
                              </span>
                            )}
                          </div>
                          <div className="flex items-center space-x-1">
                            <Clock size={12} className="text-gray-400" />
                            <span className="text-xs text-gray-400">
                              +{((request.timestamp - flow.interaction.timestamp) / 1000).toFixed(1)}s
                            </span>
                          </div>
                        </div>
                        <div className="text-xs text-gray-300 break-all">
                          {request.url}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
