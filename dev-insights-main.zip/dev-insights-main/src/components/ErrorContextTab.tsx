import { useState, useEffect } from 'react';
import { AlertTriangle, Copy, Download, FileText, RefreshCw, Trash2 } from 'lucide-react';

interface ErrorContext {
  id: string;
  type: 'javascript' | 'network' | 'unhandled-promise' | 'console-error' | 'console-warning';
  message: string;
  stack?: string;
  url?: string;
  lineNumber?: number;
  columnNumber?: number;
  source?: string;
  timestamp: number;
  userAgent: string;
  pageUrl: string;
  networkDetails?: {
    method: string;
    status: number;
    statusText: string;
    responseText: string;
  };
  // Enhanced debugging context
  userJourney?: JourneyStep[];
  networkContext?: NetworkRequest[];
  reproductionSteps?: string[];
  environmentInfo?: {
    viewport: string;
    cookiesEnabled: boolean;
    onlineStatus: boolean;
    referrer: string;
  };
}

interface JourneyStep {
  type: 'click' | 'url' | 'input' | 'scroll' | 'focus';
  value: string;
  timestamp: number;
  element?: string;
}

interface NetworkRequest {
  method: string;
  url: string;
  status: number;
  statusText: string;
  duration: number;
  timestamp: number;
  requestBody?: string;
  responseBody?: string;
}

interface ErrorContextTabProps {
  tabId: number | null;
}

export function ErrorContextTab({ tabId }: ErrorContextTabProps) {
  const [errors, setErrors] = useState<ErrorContext[]>([]);
  const [selectedError, setSelectedError] = useState<ErrorContext | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Check if chrome APIs are available
  const isChromeApiAvailable = typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage;

  useEffect(() => {
    loadErrors();
    const interval = setInterval(loadErrors, 2000); // Refresh every 2 seconds
    return () => clearInterval(interval);
  }, [tabId]);

  const loadErrors = async () => {
    if (!tabId || !isChromeApiAvailable) return;
    
    try {
      const response = await chrome.runtime.sendMessage({
        type: 'GET_ERROR_CONTEXT',
        tabId: tabId
      });
      
      if (response && response.errors) {
        // Get shared journey and network data once
        let allJourneySteps: JourneyStep[] = [];
        let allNetworkRequests: NetworkRequest[] = [];
        
        try {
          const journeyResponse = await chrome.runtime.sendMessage({
            type: 'GET_JOURNEY',
            tabId: tabId
          }).catch(() => ({ steps: [] }));
          
          const networkResponse = await chrome.runtime.sendMessage({
            type: 'GET_NETWORK_DATA',
            tabId: tabId
          }).catch(() => ({ networkRequests: [] }));
          
          allJourneySteps = journeyResponse?.steps || [];
          allNetworkRequests = networkResponse?.networkRequests || [];
        } catch (error) {
          console.warn('Failed to get journey or network data:', error);
        }

        // Enhance errors with context isolated to each error's timestamp
        const enhancedErrors = response.errors.map((error: ErrorContext) => {
          try {
            // Filter journey steps to only include those BEFORE this error occurred
            const errorTimestamp = error.timestamp || Date.now();
            const relevantJourneySteps = allJourneySteps.filter(step => {
              const stepTimestamp = step.timestamp || 0;
              return stepTimestamp > 0 && stepTimestamp < errorTimestamp;
            }).slice(-20); // Last 20 actions before this error
            
            // Filter network requests to only include those BEFORE this error occurred
            const relevantNetworkRequests = allNetworkRequests.filter(request => {
              const requestTimestamp = request.timestamp || 0;
              return requestTimestamp > 0 && requestTimestamp < errorTimestamp;
            }).slice(-10); // Last 10 requests before this error
            
            return {
              ...error,
              userJourney: relevantJourneySteps,
              networkContext: relevantNetworkRequests,
              reproductionSteps: generateReproductionSteps(error, relevantJourneySteps)
            };
          } catch (enhanceError) {
            console.warn('Failed to enhance error context:', enhanceError);
            // Return error with minimal enhancement
            return {
              ...error,
              userJourney: [],
              networkContext: [],
              reproductionSteps: generateReproductionSteps(error, [])
            };
          }
        });
        
        setErrors(enhancedErrors);
      }
    } catch (error) {
      console.error('Failed to load error context:', error);
      // Set empty array on failure to prevent infinite loading
      setErrors([]);
    }
  };

  const generateReproductionSteps = (error: ErrorContext, journey: JourneyStep[]): string[] => {
    const steps: string[] = [];
    let stepNumber = 1;
    
    // Add initial page load
    steps.push(`${stepNumber}. Open browser and navigate to: ${error.pageUrl}`);
    stepNumber++;
    
    // Sort journey by timestamp to ensure correct sequence
    const sortedJourney = [...journey].sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));
    
    // Filter and process journey steps in chronological order
    const meaningfulSteps: string[] = [];
    let lastMeaningfulUrl = error.pageUrl;
    
    // Patterns to ignore (automatic redirects/system navigation)
    const ignoredPatterns = [
      '/auth/',
      '/login',
      '/logout',
      'guest',
      'redirect',
      'sso'
    ];
    
    sortedJourney.forEach((step, index) => {
      let shouldAdd = false;
      let stepText = '';
      
      switch (step.type) {
        case 'url':
          // Skip automatic auth/system redirects and very similar URLs
          const isIgnoredUrl = ignoredPatterns.some(pattern => step.value.toLowerCase().includes(pattern));
          const isRootNavigation = step.value.endsWith('/') && step.value.split('/').length <= 4;
          const isSameBasePath = lastMeaningfulUrl && step.value.includes(lastMeaningfulUrl.split('/').slice(0, 5).join('/'));
          
          if (!isIgnoredUrl && !isRootNavigation && !isSameBasePath && 
              step.value !== lastMeaningfulUrl && 
              !step.value.includes('#') && 
              step.value.length < 150) {
            
            try {
              const url = new URL(step.value);
              const pathParts = url.pathname.split('/').filter(part => part.length > 0);
              
              // Show navigation change with more context
              if (pathParts.length >= 1) {
                const shortPath = url.pathname + (url.search ? url.search : '');
                stepText = `Navigate to: ${shortPath}`;
                
                // Check if previous step was a click that might have caused this navigation
                if (index > 0 && sortedJourney[index - 1].type === 'click') {
                  const timeDiff = (step.timestamp || 0) - (sortedJourney[index - 1].timestamp || 0);
                  if (timeDiff < 2000) { // Within 2 seconds
                    stepText += ` (from previous click)`;
                  }
                }
                
                lastMeaningfulUrl = step.value;
                shouldAdd = true;
              }
            } catch (e) {
              // Invalid URL, skip
            }
          }
          break;
        case 'click':
          // Only add clicks on buttons and links
          if (step.value.includes('Clicked button:') || step.value.includes('Clicked link:') || step.value.includes('Clicked:')) {
            stepText = step.value;
            shouldAdd = true;
          }
          break;
        case 'input':
          // Only add meaningful input events
          if (step.value.includes('Entered') && !step.value.includes('undefined')) {
            stepText = step.value;
            shouldAdd = true;
          }
          break;
        // Skip focus and scroll events
      }
      
      // Avoid duplicates but preserve sequence
      if (shouldAdd && stepText && !meaningfulSteps.some(existing => existing === stepText)) {
        meaningfulSteps.push(stepText);
      }
    });
    
    // Add meaningful steps with proper numbering (maintaining chronological order)
    meaningfulSteps.forEach((stepText) => {
      steps.push(`${stepNumber}. ${stepText}`);
      stepNumber++;
    });
    
    // Add error occurrence
    steps.push(`${stepNumber}. Error occurred: ${error.message}`);
    
    return steps;
  };

  const clearErrors = async () => {
    if (!tabId || !isChromeApiAvailable) return;
    
    try {
      // Clear errors
      await chrome.runtime.sendMessage({
        type: 'CLEAR_ERROR_CONTEXT',
        tabId: tabId
      });
      
      // Also clear journey history to prevent bleed into future errors
      await chrome.runtime.sendMessage({
        type: 'CLEAR_JOURNEY',
        tabId: tabId
      });
      
      // Clear network data as well
      await chrome.runtime.sendMessage({
        type: 'CLEAR_NETWORK_DATA',
        tabId: tabId
      });
      
      setErrors([]);
      setSelectedError(null);
    } catch (error) {
      console.error('Failed to clear errors:', error);
    }
  };

  const refreshErrors = async () => {
    setIsLoading(true);
    await loadErrors();
    setIsLoading(false);
  };

  const triggerTestError = () => {
    // Trigger a test JavaScript error on the web page being debugged
    if (!tabId || !isChromeApiAvailable) {
      alert('Cannot trigger test error: No active tab or Chrome APIs unavailable');
      return;
    }

    try {
      // Send a message to the content script to trigger an error on the page
      chrome.tabs.sendMessage(tabId, { 
        type: 'TRIGGER_TEST_ERROR' 
      }, (response) => {
        if (chrome.runtime.lastError) {
          console.warn('Failed to send test error message to page:', chrome.runtime.lastError.message);
          // Fallback: trigger error in extension context
          setTimeout(() => {
            throw new Error('Test error for debugging - This is a controlled test error generated by the Developer Insights extension');
          }, 100);
        } else if (response?.success) {
          console.log('Test error triggered on web page');
        }
      });
    } catch (error) {
      console.warn('Test error trigger failed:', error);
    }
  };

  const copyToClipboard = async (error: ErrorContext) => {
    const errorText = formatErrorForCopy(error);
    try {
      await navigator.clipboard.writeText(errorText);
      // You might want to show a toast notification here
    } catch (err) {
      console.error('Failed to copy to clipboard:', err);
    }
  };

  const formatErrorForCopy = (error: ErrorContext): string => {
    let text = `ERROR DEBUGGING REPORT\n`;
    text += `========================\n\n`;
    
    text += `Error Type: ${error.type.toUpperCase()}\n`;
    text += `Message: ${error.message}\n`;
    text += `Page URL: ${error.pageUrl}\n`;
    text += `Timestamp: ${new Date(error.timestamp).toLocaleString()}\n`;
    text += `User Agent: ${error.userAgent}\n\n`;
    
    if (error.url) {
      text += `Source URL: ${error.url}\n`;
    }
    
    if (error.lineNumber) {
      text += `Line: ${error.lineNumber}`;
      if (error.columnNumber) {
        text += `, Column: ${error.columnNumber}`;
      }
      text += '\n';
    }
    
    // Environment Info
    if (error.environmentInfo) {
      text += `\nENVIRONMENT INFO:\n`;
      text += `Viewport: ${error.environmentInfo.viewport}\n`;
      text += `Cookies Enabled: ${error.environmentInfo.cookiesEnabled}\n`;
      text += `Online Status: ${error.environmentInfo.onlineStatus}\n`;
      text += `Referrer: ${error.environmentInfo.referrer}\n`;
    }
    
    // Reproduction Steps
    if (error.reproductionSteps && error.reproductionSteps.length > 0) {
      text += `\nREPRODUCTION STEPS:\n`;
      error.reproductionSteps.forEach(step => {
        text += `${step}\n`;
      });
    }
    
    // User Journey
    if (error.userJourney && error.userJourney.length > 0) {
      text += `\nUSER JOURNEY (Last 20 actions):\n`;
      error.userJourney.forEach((step, index) => {
        const timeAgo = Math.round((error.timestamp - step.timestamp) / 1000);
        text += `${index + 1}. [${timeAgo}s ago] ${step.type.toUpperCase()}: ${step.value}\n`;
      });
    }
    
    // Network Context
    if (error.networkContext && error.networkContext.length > 0) {
      text += `\nNETWORK CONTEXT (Recent API requests):\n`;
      error.networkContext.forEach((req, index) => {
        const timeAgo = Math.round((error.timestamp - req.timestamp) / 1000);
        text += `${index + 1}. [${timeAgo}s ago] ${req.method} ${req.url} - ${req.status} ${req.statusText} (${req.duration}ms)\n`;
      });
    }
    
    if (error.stack) {
      text += `\nSTACK TRACE:\n${error.stack}\n`;
    }
    
    if (error.networkDetails) {
      text += `\nNETWORK ERROR DETAILS:\n`;
      text += `Method: ${error.networkDetails.method}\n`;
      text += `Status: ${error.networkDetails.status} ${error.networkDetails.statusText}\n`;
      if (error.networkDetails.responseText) {
        text += `Response: ${error.networkDetails.responseText}\n`;
      }
    }
    
    return text;
  };

  const exportToJson = () => {
    try {
      const dataStr = JSON.stringify(errors, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(dataBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `error-context-${new Date().toISOString().split('T')[0]}.json`;
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Failed to export JSON:', error);
      alert('Failed to export JSON file. Please try again.');
    }
  };

  const exportToWord = () => {
    try {
      let htmlContent = `
      <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
            .header { background-color: #f8f9fa; padding: 20px; border-left: 4px solid #dc3545; margin-bottom: 30px; }
            .error-item { border: 1px solid #ddd; margin-bottom: 30px; padding: 20px; border-radius: 8px; page-break-inside: avoid; }
            .error-header { font-weight: bold; color: #dc3545; margin-bottom: 15px; font-size: 18px; }
            .section { margin-bottom: 20px; }
            .section-title { font-weight: bold; color: #333; margin-bottom: 10px; font-size: 14px; text-transform: uppercase; }
            .field { margin-bottom: 8px; }
            .field-label { font-weight: bold; display: inline-block; width: 120px; }
            .field-value { font-family: monospace; background-color: #f8f9fa; padding: 2px 4px; }
            .stack-trace { background-color: #f8f9fa; padding: 15px; font-family: monospace; font-size: 11px; white-space: pre-wrap; border-radius: 5px; margin-top: 10px; }
            .steps-list { background-color: #f8f9fa; padding: 15px; border-radius: 5px; }
            .steps-list ol { margin: 0; padding-left: 20px; }
            .steps-list li { margin-bottom: 5px; }
            .journey-item { background-color: #fff3cd; padding: 8px; margin-bottom: 5px; border-radius: 3px; font-size: 12px; }
            .network-item { background-color: #d1ecf1; padding: 8px; margin-bottom: 5px; border-radius: 3px; font-size: 12px; }
            table { width: 100%; border-collapse: collapse; margin-top: 10px; }
            th, td { border: 1px solid #ddd; padding: 12px; text-align: left; vertical-align: top; }
            th { background-color: #f8f9fa; font-weight: bold; }
            .url-cell { word-break: break-all; max-width: 300px; }
            .summary-stats { background-color: #e8f5e8; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Comprehensive Error Debugging Report</h1>
            <p><strong>Generated on:</strong> ${new Date().toLocaleString()}</p>
            <p><strong>Total Errors:</strong> ${errors.length}</p>
            <div class="summary-stats">
              <strong>Summary:</strong> This report contains complete debugging context including user journey, network requests, and auto-generated reproduction steps for effective bug resolution.
            </div>
          </div>
    `;

    errors.forEach((error, index) => {
      htmlContent += `
        <div class="error-item">
          <div class="error-header">Error #${index + 1} - ${error.type.toUpperCase()}</div>
          
          <div class="section">
            <div class="section-title">Basic Information</div>
            <table>
              <tr><th>Field</th><th>Value</th></tr>
              <tr><td>Message</td><td>${error.message}</td></tr>
              <tr><td>Page URL</td><td class="url-cell">${error.pageUrl}</td></tr>
              <tr><td>Timestamp</td><td>${new Date(error.timestamp).toLocaleString()}</td></tr>
              <tr><td>User Agent</td><td class="url-cell">${error.userAgent}</td></tr>
      `;
      
      if (error.url) {
        htmlContent += `<tr><td>Source URL</td><td class="url-cell">${error.url}</td></tr>`;
      }
      
      if (error.lineNumber) {
        htmlContent += `<tr><td>Line</td><td>${error.lineNumber}</td></tr>`;
      }
      
      if (error.columnNumber) {
        htmlContent += `<tr><td>Column</td><td>${error.columnNumber}</td></tr>`;
      }
      
      htmlContent += `</table></div>`;
      
      // Environment Info
      if (error.environmentInfo) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Environment Context</div>
            <table>
              <tr><td>Viewport</td><td>${error.environmentInfo.viewport}</td></tr>
              <tr><td>Cookies Enabled</td><td>${error.environmentInfo.cookiesEnabled}</td></tr>
              <tr><td>Online Status</td><td>${error.environmentInfo.onlineStatus}</td></tr>
              <tr><td>Referrer</td><td class="url-cell">${error.environmentInfo.referrer}</td></tr>
            </table>
          </div>
        `;
      }
      
      // Reproduction Steps
      if (error.reproductionSteps && error.reproductionSteps.length > 0) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Auto-Generated Reproduction Steps</div>
            <div class="steps-list">
              <ol>
        `;
        error.reproductionSteps.forEach(step => {
          htmlContent += `<li>${step}</li>`;
        });
        htmlContent += `
              </ol>
            </div>
          </div>
        `;
      }
      
      // User Journey
      if (error.userJourney && error.userJourney.length > 0) {
        htmlContent += `
          <div class="section">
            <div class="section-title">User Journey (Last ${error.userJourney.length} Actions)</div>
        `;
        error.userJourney.forEach((step, stepIndex) => {
          const timeAgo = Math.round((error.timestamp - step.timestamp) / 1000);
          htmlContent += `
            <div class="journey-item">
              <strong>${stepIndex + 1}.</strong> [${timeAgo}s ago] <strong>${step.type.toUpperCase()}:</strong> ${step.value}
              ${step.element ? `<br><em>Element: ${step.element}</em>` : ''}
            </div>
          `;
        });
        htmlContent += `</div>`;
      }
      
      // Network Context
      if (error.networkContext && error.networkContext.length > 0) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Network Context (Recent API Requests)</div>
        `;
        error.networkContext.forEach((req, reqIndex) => {
          const timeAgo = Math.round((error.timestamp - req.timestamp) / 1000);
          htmlContent += `
            <div class="network-item">
              <strong>${reqIndex + 1}.</strong> [${timeAgo}s ago] <strong>${req.method}</strong> ${req.url}<br>
              <em>Status: ${req.status} ${req.statusText} (${req.duration}ms)</em>
            </div>
          `;
        });
        htmlContent += `</div>`;
      }
      
      // Stack Trace
      if (error.stack) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Stack Trace</div>
            <div class="stack-trace">${error.stack}</div>
          </div>
        `;
      }
      
      // Network Error Details
      if (error.networkDetails) {
        htmlContent += `
          <div class="section">
            <div class="section-title">Network Error Details</div>
            <table>
              <tr><td>Method</td><td>${error.networkDetails.method}</td></tr>
              <tr><td>Status</td><td>${error.networkDetails.status} ${error.networkDetails.statusText}</td></tr>
        `;
        if (error.networkDetails.responseText) {
          htmlContent += `<tr><td>Response</td><td class="url-cell">${error.networkDetails.responseText}</td></tr>`;
        }
        htmlContent += `</table></div>`;
      }
      
      htmlContent += `</div>`;
    });

    htmlContent += `
        </body>
      </html>
    `;

    const blob = new Blob([htmlContent], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `comprehensive-error-report-${new Date().toISOString().split('T')[0]}.doc`;
    link.click();
    URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Failed to export Word document:', error);
      alert('Failed to export Word document. Please try again.');
    }
  };

  const formatTimestamp = (timestamp: number) => {
    return new Date(timestamp).toLocaleString();
  };

  const getErrorTypeColor = (type: string) => {
    switch (type) {
      case 'javascript': return 'text-red-400';
      case 'network': return 'text-orange-400';
      case 'unhandled-promise': return 'text-yellow-400';
      case 'console-error': return 'text-red-500';
      case 'console-warning': return 'text-yellow-500';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="p-4 h-full flex flex-col bg-gray-900 text-white">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <AlertTriangle className="text-red-400" size={20} />
          <h2 className="text-lg font-semibold">Error Context</h2>
          <span className="bg-red-900 text-red-200 px-2 py-1 rounded text-sm">
            {errors.length} errors
          </span>
        </div>
        
        <div className="flex space-x-2">
          <button
            onClick={refreshErrors}
            disabled={isLoading}
            className="flex items-center space-x-1 px-3 py-1 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-800 rounded text-sm"
          >
            <RefreshCw size={14} className={isLoading ? 'animate-spin' : ''} />
            <span>Refresh</span>
          </button>
          
          <button
            onClick={(e) => {
              e.preventDefault();
              try {
                triggerTestError();
              } catch (error) {
                console.error('Error in test error button:', error);
              }
            }}
            className="flex items-center space-x-1 px-3 py-1 bg-yellow-600 hover:bg-yellow-700 rounded text-sm"
          >
            <AlertTriangle size={14} />
            <span>Test Error</span>
          </button>
          
          <button
            onClick={clearErrors}
            className="flex items-center space-x-1 px-3 py-1 bg-red-600 hover:bg-red-700 rounded text-sm"
          >
            <Trash2 size={14} />
            <span>Clear</span>
          </button>
          
          {errors.length > 0 && (
            <>
              <button
                onClick={exportToJson}
                className="flex items-center space-x-1 px-3 py-1 bg-green-600 hover:bg-green-700 rounded text-sm"
              >
                <Download size={14} />
                <span>JSON</span>
              </button>
              
              <button
                onClick={exportToWord}
                className="flex items-center space-x-1 px-3 py-1 bg-purple-600 hover:bg-purple-700 rounded text-sm"
              >
                <FileText size={14} />
                <span>Word</span>
              </button>
            </>
          )}
        </div>
      </div>

      {!isChromeApiAvailable ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center text-gray-400">
            <AlertTriangle size={48} className="mx-auto mb-4 opacity-50" />
            <p className="text-lg">Chrome Extension APIs Not Available</p>
            <p className="text-sm mt-2">Please reload this extension or use it within a Chrome extension context</p>
          </div>
        </div>
      ) : errors.length === 0 ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center text-gray-400">
            <AlertTriangle size={48} className="mx-auto mb-4 opacity-50" />
            <p className="text-lg">No errors captured yet</p>
            <p className="text-sm mt-2">JavaScript errors, console errors, and network failures will appear here when they occur on the page</p>
            <p className="text-xs mt-4 bg-gray-800 p-3 rounded max-w-md">
              <strong>Tip:</strong> Use the "Test Error" button above to generate a sample console error, 
              or open the browser console and run <code className="bg-gray-700 px-1 rounded">console.error('test')</code> to see it captured with full debugging context.
            </p>
          </div>
        </div>
      ) : (
        <div className="flex-1 flex overflow-hidden">
          {/* Error List */}
          <div className="w-1/2 border-r border-gray-700 pr-4">
            <div className="space-y-2 h-full overflow-y-auto">
              {errors.map((error) => (
                <div
                  key={error.id}
                  onClick={() => setSelectedError(error)}
                  className={`p-3 border border-gray-700 rounded cursor-pointer transition-colors ${
                    selectedError?.id === error.id ? 'bg-gray-700 border-blue-500' : 'hover:bg-gray-800'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <div className={`font-medium text-sm ${getErrorTypeColor(error.type)}`}>
                        {error.type.toUpperCase()}
                      </div>
                      <div className="text-white text-sm mt-1 truncate">
                        {error.message}
                      </div>
                      <div className="text-gray-400 text-xs mt-1">
                        {formatTimestamp(error.timestamp)}
                      </div>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        copyToClipboard(error);
                      }}
                      className="ml-2 p-1 hover:bg-gray-600 rounded"
                      title="Copy to clipboard"
                    >
                      <Copy size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Error Details */}
          <div className="w-1/2 pl-4">
            {selectedError ? (
              <div className="h-full overflow-y-auto">
                <div className="space-y-4">
                  <div>
                    <h3 className={`font-semibold text-lg ${getErrorTypeColor(selectedError.type)}`}>
                      {selectedError.type.toUpperCase()} Error
                    </h3>
                  </div>

                  <div className="space-y-3 text-sm">
                    <div>
                      <span className="font-medium text-gray-300">Message:</span>
                      <div className="mt-1 p-2 bg-gray-800 rounded font-mono text-red-300">
                        {selectedError.message}
                      </div>
                    </div>

                    <div>
                      <span className="font-medium text-gray-300">Page URL:</span>
                      <div className="mt-1 p-2 bg-gray-800 rounded font-mono text-blue-300 break-all">
                        {selectedError.pageUrl}
                      </div>
                    </div>

                    <div>
                      <span className="font-medium text-gray-300">Timestamp:</span>
                      <div className="mt-1 p-2 bg-gray-800 rounded">
                        {formatTimestamp(selectedError.timestamp)}
                      </div>
                    </div>

                    {selectedError.url && (
                      <div>
                        <span className="font-medium text-gray-300">Source URL:</span>
                        <div className="mt-1 p-2 bg-gray-800 rounded font-mono text-blue-300 break-all">
                          {selectedError.url}
                        </div>
                      </div>
                    )}

                    {selectedError.lineNumber && (
                      <div>
                        <span className="font-medium text-gray-300">Location:</span>
                        <div className="mt-1 p-2 bg-gray-800 rounded">
                          Line {selectedError.lineNumber}
                          {selectedError.columnNumber && `, Column ${selectedError.columnNumber}`}
                        </div>
                      </div>
                    )}

                    {selectedError.networkDetails && (
                      <div>
                        <span className="font-medium text-gray-300">Network Details:</span>
                        <div className="mt-1 p-2 bg-gray-800 rounded space-y-1">
                          <div><span className="font-medium">Method:</span> {selectedError.networkDetails.method}</div>
                          <div><span className="font-medium">Status:</span> {selectedError.networkDetails.status} {selectedError.networkDetails.statusText}</div>
                          {selectedError.networkDetails.responseText && (
                            <div>
                              <span className="font-medium">Response:</span>
                              <div className="mt-1 p-2 bg-gray-900 rounded font-mono text-xs max-h-32 overflow-y-auto">
                                {selectedError.networkDetails.responseText}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {selectedError.reproductionSteps && selectedError.reproductionSteps.length > 0 && (
                      <div>
                        <span className="font-medium text-gray-300">Reproduction Steps:</span>
                        <div className="mt-1 p-3 bg-gray-800 rounded">
                          <ol className="list-decimal list-inside space-y-1">
                            {selectedError.reproductionSteps.map((step, index) => (
                              <li key={index} className="text-xs text-green-300">{step}</li>
                            ))}
                          </ol>
                        </div>
                      </div>
                    )}

                    {selectedError.userJourney && selectedError.userJourney.length > 0 && (
                      <div>
                        <span className="font-medium text-gray-300">User Journey (Last {selectedError.userJourney.length} actions):</span>
                        <div className="mt-1 p-2 bg-gray-800 rounded max-h-48 overflow-y-auto">
                          {selectedError.userJourney.map((step, index) => {
                            const timeAgo = Math.round((selectedError.timestamp - step.timestamp) / 1000);
                            return (
                              <div key={index} className="text-xs mb-2 p-2 bg-yellow-900 bg-opacity-30 rounded">
                                <span className="text-yellow-300 font-medium">{index + 1}. [{timeAgo}s ago]</span>
                                <span className="text-white ml-2">{step.type.toUpperCase()}: {step.value}</span>
                                {step.element && <div className="text-gray-400 ml-6 text-xs">Element: {step.element}</div>}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {selectedError.networkContext && selectedError.networkContext.length > 0 && (
                      <div>
                        <span className="font-medium text-gray-300">Network Context (Recent requests):</span>
                        <div className="mt-1 p-2 bg-gray-800 rounded max-h-48 overflow-y-auto">
                          {selectedError.networkContext.map((req, index) => {
                            const timeAgo = Math.round((selectedError.timestamp - req.timestamp) / 1000);
                            const statusColor = req.status >= 400 ? 'text-red-300' : req.status >= 300 ? 'text-yellow-300' : 'text-green-300';
                            return (
                              <div key={index} className="text-xs mb-2 p-2 bg-blue-900 bg-opacity-30 rounded">
                                <div className="flex justify-between items-start">
                                  <span className="text-blue-300 font-medium">{index + 1}. [{timeAgo}s ago]</span>
                                  <span className={`text-xs ${statusColor}`}>{req.status} {req.statusText}</span>
                                </div>
                                <div className="text-white mt-1">{req.method} {req.url}</div>
                                <div className="text-gray-400 text-xs">Duration: {req.duration}ms</div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {selectedError.environmentInfo && (
                      <div>
                        <span className="font-medium text-gray-300">Environment Info:</span>
                        <div className="mt-1 p-2 bg-gray-800 rounded space-y-1 text-xs">
                          <div><span className="font-medium">Viewport:</span> {selectedError.environmentInfo.viewport}</div>
                          <div><span className="font-medium">Cookies:</span> {selectedError.environmentInfo.cookiesEnabled ? 'Enabled' : 'Disabled'}</div>
                          <div><span className="font-medium">Online:</span> {selectedError.environmentInfo.onlineStatus ? 'Yes' : 'No'}</div>
                          <div><span className="font-medium">Referrer:</span> {selectedError.environmentInfo.referrer || 'None'}</div>
                        </div>
                      </div>
                    )}

                    {selectedError.stack && (
                      <div>
                        <span className="font-medium text-gray-300">Stack Trace:</span>
                        <div className="mt-1 p-2 bg-gray-800 rounded font-mono text-xs whitespace-pre-wrap max-h-64 overflow-y-auto">
                          {selectedError.stack}
                        </div>
                      </div>
                    )}

                    <div>
                      <span className="font-medium text-gray-300">User Agent:</span>
                      <div className="mt-1 p-2 bg-gray-800 rounded text-xs break-all">
                        {selectedError.userAgent}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="h-full flex items-center justify-center text-gray-400">
                <div className="text-center">
                  <AlertTriangle size={32} className="mx-auto mb-2 opacity-50" />
                  <p>Select an error to view details</p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
