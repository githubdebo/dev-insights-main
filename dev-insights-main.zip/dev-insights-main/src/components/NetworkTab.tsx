import React, { useState, useEffect } from 'react';
import { RefreshCw, Download, Trash2, Clock, AlertCircle, CheckCircle, Activity } from 'lucide-react';

interface NetworkRequest {
  id: string;
  method: string;
  url: string;
  status: number | string;
  statusText?: string;
  timestamp: number;
  duration?: number;
  type?: string;
  requestBody?: any;
  responseBody?: any;
  requestHeaders?: Record<string, string>;
}

interface NetworkTabProps {
  tabId: number | null;
  type: 'api' | 'assets';
  displayedCalls: NetworkRequest[];
  setDisplayedCalls: React.Dispatch<React.SetStateAction<NetworkRequest[]>>;
}

// Helper to determine if a request is an API call
const isApiRequest = (url: string) => {
  // Heuristic: treat as API if URL contains '/api' or ends with common API extensions
  return /\/api\b|\.json$|\/v\d+\//i.test(url) || /application\/json|api\./i.test(url);
};

// Categorize request performance based on duration
const getPerformanceInfo = (duration?: number) => {
  if (!duration || duration === 0) return { category: 'unknown', color: 'text-gray-400', icon: null, label: 'Unknown' };
  
  if (duration < 200) {
    return { category: 'fast', color: 'text-green-400', icon: '⚡', label: 'Fast' };
  } else if (duration < 1000) {
    return { category: 'normal', color: 'text-blue-400', icon: '⏱️', label: 'Normal' };
  } else if (duration < 3000) {
    return { category: 'slow', color: 'text-yellow-400', icon: '⚠️', label: 'Slow' };
  } else {
    return { category: 'very-slow', color: 'text-red-400', icon: '🐌', label: 'Very Slow' };
  }
};

// Format URL for display in the UI
const formatUrlForDisplay = (url: string): { displayUrl: string; fullUrl: string } => {
  try {
    const urlObj = new URL(url);
    const currentOrigin = window.location.origin;
    
    // If it's the same origin, show just the path and query
    if (urlObj.origin === currentOrigin) {
      return {
        displayUrl: urlObj.pathname + urlObj.search + urlObj.hash,
        fullUrl: url
      };
    }
    
    // If it's cross-origin, show the full URL but highlight the path
    return {
      displayUrl: url,
      fullUrl: url
    };
  } catch (error) {
    // If URL parsing fails, return as-is
    return {
      displayUrl: url,
      fullUrl: url
    };
  }
};

export const NetworkTab: React.FC<NetworkTabProps> = ({ tabId, type, displayedCalls, setDisplayedCalls }) => {
  const [requests, setRequests] = useState<NetworkRequest[]>([]);
  const [filter, setFilter] = useState('');
  const [performanceFilter, setPerformanceFilter] = useState('all');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState<NetworkRequest | null>(null);

  const loadNetworkData = async () => {
    if (!tabId) return;
    
    setIsLoading(true);
    try {
      const response = await chrome.runtime.sendMessage({
        type: 'GET_NETWORK_DATA',
        tabId: tabId
      });
      setRequests(response.networkRequests || []);
    } catch (error) {
      console.error('Failed to load network data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const clearNetworkData = async () => {
    if (!tabId) return;
    try {
      await chrome.runtime.sendMessage({
        type: 'CLEAR_NETWORK_DATA',
        tabId: tabId
      });
      setRequests([]);
      setDisplayedCalls([]); // Also clear the persistent displayed calls for this tab
    } catch (error) {
      console.error('Failed to clear network data:', error);
    }
  };

  useEffect(() => {
    loadNetworkData();
    const interval = setInterval(loadNetworkData, 2000); // Refresh every 2 seconds
    return () => clearInterval(interval);
  }, [tabId]);

  // Deduplicate and merge logic (as before)
  function dedupeRequests(requests: NetworkRequest[]) {
    const seen = new Set();
    return requests.filter(req => {
      const key = `${req.method}|${req.url}|${Math.round(req.timestamp)}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }
  function mergeRequests(requests: NetworkRequest[]) {
    const map = new Map();
    for (const req of requests) {
      const key = `${req.method}|${req.url}|${Math.round(req.timestamp)}`;
      if (!map.has(key)) {
        map.set(key, req);
      } else {
        const existing = map.get(key);
        const hasExistingBody = existing.requestBody || existing.responseBody;
        const hasNewBody = req.requestBody || req.responseBody;
        if (hasNewBody && !hasExistingBody) {
          map.set(key, { ...existing, ...req });
        } else if (hasNewBody && hasExistingBody) {
          const existingLen = (existing.responseBody?.length || 0) + (existing.requestBody?.length || 0);
          const newLen = (req.responseBody?.length || 0) + (req.requestBody?.length || 0);
          if (newLen > existingLen) {
            map.set(key, { ...existing, ...req });
          }
        }
      }
    }
    return Array.from(map.values());
  }

  // Update persistent displayedCalls (from props)
  useEffect(() => {
    let processedRequests = mergeRequests(dedupeRequests(requests));
    if (type === 'api') {
      processedRequests = processedRequests.filter(req => req.requestBody || req.responseBody);
    }
    // Add new calls to persistent list, never remove
    const existingKeys = new Set(displayedCalls.map(req => `${req.method}|${req.url}|${Math.round(req.timestamp)}`));
    const newCalls = processedRequests.filter(req => !existingKeys.has(`${req.method}|${req.url}|${Math.round(req.timestamp)}`));
    if (newCalls.length > 0) {
      setDisplayedCalls(prev => [...prev, ...newCalls]);
    }
    // eslint-disable-next-line
  }, [requests, type]);

  // Filtering for display
  const filteredRequests = displayedCalls.filter(req => {
    const url = req.url || '';
    const method = req.method || '';
    const matchesFilter = url.toLowerCase().includes(filter.toLowerCase()) ||
      method.toLowerCase().includes(filter.toLowerCase());
    
    // Performance filtering
    const perfInfo = getPerformanceInfo(req.duration);
    const matchesPerformance = performanceFilter === 'all' || perfInfo.category === performanceFilter;
    
    const matchesType = type === 'api' ? isApiRequest(url) : !isApiRequest(url);
    
    return matchesFilter && matchesPerformance && matchesType;
  });

  const getStatusColor = (status: number | string) => {
    const statusNum = typeof status === 'string' ? parseInt(status) : status;
    if (statusNum >= 200 && statusNum < 300) return 'text-green-400';
    if (statusNum >= 300 && statusNum < 400) return 'text-yellow-400';
    if (statusNum >= 400) return 'text-red-400';
    return 'text-gray-400';
  };

  const getStatusIcon = (status: number | string) => {
    const statusNum = typeof status === 'string' ? parseInt(status) : status;
    if (statusNum >= 200 && statusNum < 300) return <CheckCircle size={14} className="text-green-400" />;
    if (statusNum >= 400) return <AlertCircle size={14} className="text-red-400" />;
    return <Clock size={14} className="text-gray-400" />;
  };

  return (
    <div className="h-full flex flex-col">
      {/* Controls */}
      <div className="p-4 bg-gray-800 border-b border-gray-700">
        <div className="flex items-center justify-between mb-3">
          <div className="flex space-x-2">
            <button
              onClick={loadNetworkData}
              disabled={isLoading}
              className="flex items-center space-x-1 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm rounded transition-colors"
            >
              <RefreshCw size={14} className={isLoading ? 'animate-spin' : ''} />
              <span>Refresh</span>
            </button>
            <button
              onClick={clearNetworkData}
              className="flex items-center space-x-1 px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white text-sm rounded transition-colors"
            >
              <Trash2 size={14} />
              <span>Clear</span>
            </button>
            {type === 'api' && (
              <button
                onClick={() => {
                  const dataStr = JSON.stringify(filteredRequests, null, 2);
                  const dataBlob = new Blob([dataStr], { type: 'application/json' });
                  const url = URL.createObjectURL(dataBlob);
                  const link = document.createElement('a');
                  link.href = url;
                  link.download = `api-requests-${Date.now()}.json`;
                  link.click();
                  URL.revokeObjectURL(url);
                }}
                className="flex items-center space-x-1 px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white text-sm rounded transition-colors"
              >
                <Download size={14} />
                <span>Export API</span>
              </button>
            )}
            {type === 'assets' && (
              <button
                onClick={() => {
                  const dataStr = JSON.stringify(filteredRequests, null, 2);
                  const dataBlob = new Blob([dataStr], { type: 'application/json' });
                  const url = URL.createObjectURL(dataBlob);
                  const link = document.createElement('a');
                  link.href = url;
                  link.download = `asset-requests-${Date.now()}.json`;
                  link.click();
                  URL.revokeObjectURL(url);
                }}
                className="flex items-center space-x-1 px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white text-sm rounded transition-colors"
              >
                <Download size={14} />
                <span>Export Assets</span>
              </button>
            )}
          </div>
          <div className="text-sm text-gray-400">
            {filteredRequests.length} requests
          </div>
        </div>
        
        <div className="space-y-3">
          <input
            type="text"
            placeholder="Filter requests by URL or method..."
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
          />
          
          {/* Performance Filter and Summary */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <label className="text-sm font-medium text-gray-300">Performance:</label>
              <select
                value={performanceFilter}
                onChange={(e) => setPerformanceFilter(e.target.value)}
                className="px-3 py-1.5 bg-gray-700 border border-gray-600 rounded text-white text-sm focus:outline-none focus:border-blue-500"
              >
                <option value="all">All</option>
                <option value="fast">⚡ Fast (&lt;200ms)</option>
                <option value="normal">⏱️ Normal (200ms-1s)</option>
                <option value="slow">⚠️ Slow (1s-3s)</option>
                <option value="very-slow">🐌 Very Slow (&gt;3s)</option>
                <option value="unknown">❓ Unknown</option>
              </select>
            </div>
            
            {/* Performance Summary */}
            {displayedCalls.length > 0 && (
              <div className="flex items-center space-x-3 text-xs">
                {(() => {
                  const requestsWithDuration = displayedCalls.filter(req => 
                    type === 'api' ? isApiRequest(req.url) : !isApiRequest(req.url)
                  );
                  const fastCalls = requestsWithDuration.filter(req => {
                    const perfInfo = getPerformanceInfo(req.duration);
                    return perfInfo.category === 'fast';
                  }).length;
                  const normalCalls = requestsWithDuration.filter(req => {
                    const perfInfo = getPerformanceInfo(req.duration);
                    return perfInfo.category === 'normal';
                  }).length;
                  const slowCalls = requestsWithDuration.filter(req => {
                    const perfInfo = getPerformanceInfo(req.duration);
                    return perfInfo.category === 'slow';
                  }).length;
                  const verySlowCalls = requestsWithDuration.filter(req => {
                    const perfInfo = getPerformanceInfo(req.duration);
                    return perfInfo.category === 'very-slow';
                  }).length;
                  
                  return (
                    <>
                      {fastCalls > 0 && <span className="text-green-400" title="Fast (<200ms)">⚡ {fastCalls}</span>}
                      {normalCalls > 0 && <span className="text-blue-400" title="Normal (200ms-1s)">⏱️ {normalCalls}</span>}
                      {slowCalls > 0 && <span className="text-yellow-400" title="Slow (1s-3s)">⚠️ {slowCalls}</span>}
                      {verySlowCalls > 0 && <span className="text-red-400" title="Very Slow (>3s)">🐌 {verySlowCalls}</span>}
                    </>
                  );
                })()}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Request List */}
      <div className="flex-1 overflow-y-auto relative">
        {filteredRequests.length === 0 ? (
          <div className="flex items-center justify-center h-full text-gray-400">
            <div className="text-center">
              <Activity size={48} className="mx-auto mb-4 opacity-50" />
              <p>No network requests captured yet</p>
              <p className="text-sm mt-1">Navigate the page to see network activity</p>
            </div>
          </div>
        ) : (
          <div className="divide-y divide-gray-700">
            {filteredRequests.map((request, index) => (
              <React.Fragment key={`${request.id}-${index}`}>
                <div
                  className={`p-3 hover:bg-gray-800 transition-colors cursor-pointer ${selectedRequest?.id === request.id ? 'bg-gray-800' : ''}`}
                  onClick={() => setSelectedRequest(selectedRequest?.id === request.id ? null : request)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(request.status)}
                      <span className="font-mono text-sm font-semibold text-blue-400">
                        {request.method}
                      </span>
                      <span className={`font-mono text-sm ${getStatusColor(request.status)}`}>
                        {request.status}
                      </span>
                      {request.duration && (
                        <>
                          <span className="text-xs text-gray-400">
                            {request.duration.toFixed(0)}ms
                          </span>
                          {(() => {
                            const perfInfo = getPerformanceInfo(request.duration);
                            return perfInfo.icon ? (
                              <span 
                                className={`text-xs ${perfInfo.color}`} 
                                title={`${perfInfo.label} (${request.duration.toFixed(0)}ms)`}
                              >
                                {perfInfo.icon}
                              </span>
                            ) : null;
                          })()}
                        </>
                      )}
                      {type === 'assets' && request.responseBody && (
                        <span className="text-xs text-green-400 ml-2">
                          {typeof request.responseBody === 'string'
                            ? `${new Blob([request.responseBody]).size} bytes`
                            : `${JSON.stringify(request.responseBody).length} bytes`}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="text-sm text-gray-300 break-all" title={request.url}>
                    {formatUrlForDisplay(request.url).displayUrl}
                  </div>
                  {request.statusText && (
                    <div className="text-xs text-gray-400 mt-1">
                      {request.statusText}
                    </div>
                  )}
                </div>
                {type === 'api' && selectedRequest?.id === request.id && (
                  <div className="bg-gray-900 border-t border-b border-blue-900 p-4 text-sm shadow-inner">
                    <button
                      className="absolute right-8 mt-1 text-gray-400 hover:text-red-400 text-lg font-bold"
                      onClick={() => setSelectedRequest(null)}
                      aria-label="Close details"
                    >
                      ×
                    </button>
                    <div className="mb-2 pr-8">
                      <span className="font-semibold text-blue-400">{selectedRequest?.method}</span>
                      <span className="ml-2 text-gray-300 break-all">{selectedRequest?.url}</span>
                    </div>
                    <div className="mb-2">
                      <div className="font-semibold text-gray-400">Request Body:</div>
                      <pre className="bg-gray-800 p-2 rounded text-gray-200 whitespace-pre-wrap break-all max-h-24 overflow-auto">{
                        selectedRequest?.requestBody
                          ? (typeof selectedRequest.requestBody === 'string' ? selectedRequest.requestBody : JSON.stringify(selectedRequest.requestBody, null, 2))
                          : 'No request body'
                      }</pre>
                    </div>
                    <div className="mb-2">
                      <div className="font-semibold text-gray-400">Response:</div>
                      <pre className="bg-gray-800 p-2 rounded text-gray-200 whitespace-pre-wrap break-all max-h-24 overflow-auto">{
                        selectedRequest?.responseBody
                          ? (typeof selectedRequest.responseBody === 'string' ? selectedRequest.responseBody : JSON.stringify(selectedRequest.responseBody, null, 2))
                          : 'No response'
                      }</pre>
                    </div>
                  </div>
                )}
              </React.Fragment>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};