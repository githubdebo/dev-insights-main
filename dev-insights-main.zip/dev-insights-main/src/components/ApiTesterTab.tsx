import React, { useState, useEffect } from 'react';
import { Send, Copy, Download, RefreshCw, Plus, Trash2, ChevronDown, ChevronRight, RotateCcw } from 'lucide-react';

interface NetworkRequest {
  id: string;
  method: string;
  url: string;
  status: number | string;
  statusText?: string;
  timestamp: number;
  duration?: number;
  type?: string;
  requestBody?: any;
  responseBody?: any;
  requestHeaders?: Record<string, string>;
}

interface ApiTest {
  id: string;
  url: string;
  method: string;
  headers: Record<string, string>;
  body: string;
  response?: {
    status: number;
    statusText: string;
    headers: Record<string, string>;
    body: string;
    duration: number;
  };
  loading?: boolean;
}

interface ApiTesterTabProps {
  displayedCalls: NetworkRequest[];
  onRefresh?: () => void;
}

export const ApiTesterTab: React.FC<ApiTesterTabProps> = ({ displayedCalls, onRefresh }) => {
  const [apiCalls, setApiCalls] = useState<NetworkRequest[]>([]);
  const [apiTests, setApiTests] = useState<ApiTest[]>([]);
  const [expandedTest, setExpandedTest] = useState<string | null>(null);

  // Extract API calls from captured network calls
  useEffect(() => {
    const calls = displayedCalls
      .filter(call => call.url.toLowerCase().includes('api'))
      .filter((call, index, self) => 
        self.findIndex(c => c.url === call.url && c.method === call.method) === index
      ) // Remove duplicates based on URL and method
      .sort((a, b) => a.url.localeCompare(b.url));
    setApiCalls(calls);
  }, [displayedCalls]);

  // Create a new API test from a captured call
  const createNewTestFromCall = (call: NetworkRequest) => {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };

    // If the captured call has request headers, include them (especially Authorization)
    if (call.requestHeaders) {
      Object.entries(call.requestHeaders).forEach(([key, value]) => {
        // Include Authorization header (Bearer token) and other important headers
        if (key.toLowerCase() === 'authorization' || 
            key.toLowerCase() === 'x-api-key' ||
            key.toLowerCase() === 'user-agent' ||
            key.toLowerCase() === 'referer' ||
            key.toLowerCase().startsWith('x-')) {
          headers[key] = value;
        }
      });
    }

    const newTest: ApiTest = {
      id: Date.now().toString(),
      url: call.url,
      method: call.method,
      headers,
      body: call.requestBody ? 
        (typeof call.requestBody === 'string' ? call.requestBody : JSON.stringify(call.requestBody, null, 2)) : 
        ''
    };
    setApiTests(prev => [...prev, newTest]);
    setExpandedTest(newTest.id);
  };

  // Create a new blank API test
  const createNewTest = () => {
    const newTest: ApiTest = {
      id: Date.now().toString(),
      url: '',
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: ''
    };
    setApiTests(prev => [...prev, newTest]);
    setExpandedTest(newTest.id);
  };

  // Update an API test
  const updateTest = (id: string, updates: Partial<ApiTest>) => {
    setApiTests(prev => prev.map(test => 
      test.id === id ? { ...test, ...updates } : test
    ));
  };

  // Delete an API test
  const deleteTest = (id: string) => {
    setApiTests(prev => prev.filter(test => test.id !== id));
    if (expandedTest === id) {
      setExpandedTest(null);
    }
  };

  // Execute an API test
  const executeTest = async (test: ApiTest) => {
    updateTest(test.id, { loading: true });
    
    try {
      const startTime = Date.now();
      const headers: Record<string, string> = {};
      
      // Parse headers
      Object.entries(test.headers).forEach(([key, value]) => {
        if (key.trim() && value.trim()) {
          headers[key.trim()] = value.trim();
        }
      });

      const requestOptions: RequestInit = {
        method: test.method,
        headers,
        mode: 'cors'
      };

      // Add body for non-GET requests
      if (test.method !== 'GET' && test.body.trim()) {
        requestOptions.body = test.body;
      }

      const response = await fetch(test.url, requestOptions);
      const duration = Date.now() - startTime;
      
      // Get response headers
      const responseHeaders: Record<string, string> = {};
      response.headers.forEach((value, key) => {
        responseHeaders[key] = value;
      });

      // Get response body
      const contentType = response.headers.get('content-type') || '';
      let responseBody: string;
      
      if (contentType.includes('application/json')) {
        try {
          const jsonData = await response.json();
          responseBody = JSON.stringify(jsonData, null, 2);
        } catch {
          responseBody = await response.text();
        }
      } else {
        responseBody = await response.text();
      }

      updateTest(test.id, {
        loading: false,
        response: {
          status: response.status,
          statusText: response.statusText,
          headers: responseHeaders,
          body: responseBody,
          duration
        }
      });
    } catch (error) {
      updateTest(test.id, {
        loading: false,
        response: {
          status: 0,
          statusText: 'Network Error',
          headers: {},
          body: `Error: ${error instanceof Error ? error.message : 'Unknown error'}`,
          duration: 0
        }
      });
    }
  };

  // Copy response to clipboard
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  // Export test results
  const exportResults = () => {
    const dataStr = JSON.stringify(apiTests, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `api-tests-${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const getStatusColor = (status: number) => {
    if (status >= 200 && status < 300) return 'text-green-400';
    if (status >= 300 && status < 400) return 'text-yellow-400';
    if (status >= 400) return 'text-red-400';
    return 'text-gray-400';
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 bg-gray-800 border-b border-gray-700">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold text-blue-400">API Tester</h2>
          <div className="flex space-x-2">
            {onRefresh && (
              <button
                onClick={onRefresh}
                className="flex items-center space-x-1 px-3 py-1.5 bg-gray-600 hover:bg-gray-700 text-white text-sm rounded transition-colors"
                title="Refresh captured API calls"
              >
                <RotateCcw size={14} />
                <span>Refresh</span>
              </button>
            )}
            <button
              onClick={() => createNewTest()}
              className="flex items-center space-x-1 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded transition-colors"
            >
              <Plus size={14} />
              <span>New Test</span>
            </button>
            <button
              onClick={exportResults}
              className="flex items-center space-x-1 px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white text-sm rounded transition-colors"
            >
              <Download size={14} />
              <span>Export</span>
            </button>
          </div>
        </div>        {/* Captured API Calls Dropdown */}
        {apiCalls.length > 0 && (
          <div className="mb-3">
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Captured API Calls ({apiCalls.length})
            </label>
            <div className="flex space-x-2">
              <select
                value=""
                onChange={(e) => {
                  if (e.target.value) {
                    const selectedCall = apiCalls[parseInt(e.target.value)];
                    createNewTestFromCall(selectedCall);
                    e.target.value = ""; // Reset selection
                  }
                }}
                className="flex-1 px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:border-blue-500"
              >
                <option value="">Select an API call to test...</option>
                {apiCalls.map((call, index) => {
                  const hasAuth = call.requestHeaders && 
                    Object.keys(call.requestHeaders).some(key => 
                      key.toLowerCase() === 'authorization' || key.toLowerCase() === 'x-api-key'
                    );
                  return (
                    <option key={index} value={index}>
                      {call.method} - {call.url.length > 80 ? `${call.url.substring(0, 80)}...` : call.url}
                      {call.requestBody ? ' (with body)' : ''}
                      {hasAuth ? ' 🔐' : ''}
                    </option>
                  );
                })}
              </select>
            </div>
          </div>
        )}
      </div>

      {/* Test List */}
      <div className="flex-1 overflow-y-auto">
        {apiTests.length === 0 ? (
          <div className="flex items-center justify-center h-full text-gray-400">
            <div className="text-center">
              <Send size={48} className="mx-auto mb-4 opacity-50" />
              <p>No API tests created yet</p>
              <p className="text-sm mt-1">Create a test to start testing API endpoints</p>
            </div>
          </div>
        ) : (
          <div className="divide-y divide-gray-700">
            {apiTests.map((test) => (
              <div key={test.id} className="p-4">
                {/* Test Header */}
                <div className="flex items-center justify-between mb-3">
                  <button
                    onClick={() => setExpandedTest(expandedTest === test.id ? null : test.id)}
                    className="flex items-center space-x-2 text-left flex-1"
                  >
                    {expandedTest === test.id ? (
                      <ChevronDown size={16} className="text-gray-400" />
                    ) : (
                      <ChevronRight size={16} className="text-gray-400" />
                    )}
                    <span className="font-mono text-sm font-semibold text-blue-400">
                      {test.method}
                    </span>
                    <span className="text-sm text-gray-300 truncate">
                      {test.url || 'No URL set'}
                    </span>
                    {test.response && (
                      <span className={`font-mono text-sm ${getStatusColor(test.response.status)}`}>
                        {test.response.status}
                      </span>
                    )}
                  </button>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => executeTest(test)}
                      disabled={test.loading || !test.url}
                      className="flex items-center space-x-1 px-3 py-1.5 bg-green-600 hover:bg-green-700 disabled:opacity-50 text-white text-sm rounded transition-colors"
                    >
                      {test.loading ? (
                        <RefreshCw size={14} className="animate-spin" />
                      ) : (
                        <Send size={14} />
                      )}
                      <span>Send</span>
                    </button>
                    <button
                      onClick={() => deleteTest(test.id)}
                      className="p-1.5 text-red-400 hover:text-red-300 transition-colors"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>

                {/* Expanded Test Details */}
                {expandedTest === test.id && (
                  <div className="space-y-4 bg-gray-900 p-4 rounded border border-gray-700">
                    {/* URL and Method */}
                    <div className="grid grid-cols-4 gap-3">
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1">
                          Method
                        </label>
                        <select
                          value={test.method}
                          onChange={(e) => updateTest(test.id, { method: e.target.value })}
                          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:border-blue-500"
                        >
                          <option value="GET">GET</option>
                          <option value="POST">POST</option>
                          <option value="PUT">PUT</option>
                          <option value="PATCH">PATCH</option>
                          <option value="DELETE">DELETE</option>
                        </select>
                      </div>
                      <div className="col-span-3">
                        <label className="block text-sm font-medium text-gray-300 mb-1">
                          URL
                        </label>
                        <input
                          type="text"
                          value={test.url}
                          onChange={(e) => updateTest(test.id, { url: e.target.value })}
                          placeholder="Enter API endpoint URL..."
                          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                        />
                      </div>
                    </div>

                    {/* Headers */}
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Headers
                      </label>
                      <div className="space-y-2">
                        {Object.entries(test.headers).map(([key, value], index) => (
                          <div key={index} className="grid grid-cols-2 gap-2">
                            <input
                              type="text"
                              value={key}
                              onChange={(e) => {
                                const newHeaders = { ...test.headers };
                                delete newHeaders[key];
                                newHeaders[e.target.value] = value;
                                updateTest(test.id, { headers: newHeaders });
                              }}
                              placeholder="Header name"
                              className="px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                            />
                            <div className="flex space-x-2">
                              <input
                                type="text"
                                value={value}
                                onChange={(e) => {
                                  const newHeaders = { ...test.headers };
                                  newHeaders[key] = e.target.value;
                                  updateTest(test.id, { headers: newHeaders });
                                }}
                                placeholder="Header value"
                                className="flex-1 px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500"
                              />
                              <button
                                onClick={() => {
                                  const newHeaders = { ...test.headers };
                                  delete newHeaders[key];
                                  updateTest(test.id, { headers: newHeaders });
                                }}
                                className="p-2 text-red-400 hover:text-red-300 transition-colors"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          </div>
                        ))}
                        <button
                          onClick={() => {
                            const newHeaders = { ...test.headers, '': '' };
                            updateTest(test.id, { headers: newHeaders });
                          }}
                          className="flex items-center space-x-1 px-3 py-1.5 bg-gray-700 hover:bg-gray-600 text-white text-sm rounded transition-colors"
                        >
                          <Plus size={14} />
                          <span>Add Header</span>
                        </button>
                      </div>
                    </div>

                    {/* Request Body */}
                    {test.method !== 'GET' && (
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">
                          Request Body
                        </label>
                        <textarea
                          value={test.body}
                          onChange={(e) => updateTest(test.id, { body: e.target.value })}
                          placeholder="Enter request body (JSON, form data, etc.)"
                          rows={4}
                          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white placeholder-gray-400 focus:outline-none focus:border-blue-500 font-mono text-sm"
                        />
                      </div>
                    )}

                    {/* Response */}
                    {test.response && (
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <label className="block text-sm font-medium text-gray-300">
                            Response
                          </label>
                          <div className="flex items-center space-x-2">
                            <span className={`font-mono text-sm ${getStatusColor(test.response.status)}`}>
                              {test.response.status} {test.response.statusText}
                            </span>
                            <span className="text-xs text-gray-400">
                              {test.response.duration}ms
                            </span>
                            <button
                              onClick={() => copyToClipboard(test.response!.body)}
                              className="p-1 text-gray-400 hover:text-blue-400 transition-colors"
                              title="Copy response"
                            >
                              <Copy size={14} />
                            </button>
                          </div>
                        </div>
                        <div className="bg-gray-800 border border-gray-600 rounded">
                          <div className="p-3 border-b border-gray-600">
                            <div className="text-xs text-gray-400 mb-1">Response Headers:</div>
                            <pre className="text-xs text-gray-300 whitespace-pre-wrap">
                              {Object.entries(test.response.headers).map(([key, value]) => `${key}: ${value}`).join('\n')}
                            </pre>
                          </div>
                          <div className="p-3">
                            <div className="text-xs text-gray-400 mb-1">Response Body:</div>
                            <pre className="text-sm text-gray-200 whitespace-pre-wrap break-all max-h-40 overflow-auto">
                              {test.response.body}
                            </pre>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
